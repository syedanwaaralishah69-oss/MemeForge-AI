package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.TemplateRepository
import com.example.data.remote.GeminiService
import com.example.ui.components.MemeExporter
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("MemeForge AI", appName)
    }

    @Test
    fun `test templates repository contains templates`() {
        assertTrue(TemplateRepository.templates.isNotEmpty())
        val coolCat = TemplateRepository.templates.firstOrNull { it.id == "cool_cat" }
        assertNotNull(coolCat)
    }

    @Test
    fun `test creative humor generator produces caption`() {
        val result = GeminiService.getCreativeEngineCaption(
            style = "Funny",
            language = "English",
            customPrompt = ""
        )
        assertNotNull(result)
        assertTrue(result.topText.isNotBlank())
        assertTrue(result.bottomText.isNotBlank())
    }

    @Test
    fun `test context aware captions generation with modifiers`() = runBlocking {
        val captions = GeminiService.generateContextAwareCaptions(
            bitmap = null,
            topic = "Exam stress",
            style = "School",
            language = "Roman Urdu",
            modifier = "Funnier",
            customInstruction = ""
        )
        assertTrue(captions.isNotEmpty())
    }

    @Test
    fun `test AI story mode generation`() = runBlocking {
        val story = GeminiService.generateAiStory(
            topic = "Ek Pakistani student ka school mein funny incident",
            language = "Roman Urdu"
        )
        assertNotNull(story)
        assertTrue(story.scenes.isNotEmpty())
        assertEquals(4, story.scenes.size)
        assertTrue(story.scenes.first().voiceoverScript.isNotBlank())
    }

    @Test
    fun `test meme exporter renders bitmap`() {
        val bmp = MemeExporter.renderMemeToBitmap(
            baseBitmap = null,
            topText = "TOP TEST",
            bottomText = "BOTTOM TEST",
            targetWidth = 400,
            targetHeight = 400
        )
        assertNotNull(bmp)
        assertEquals(400, bmp.width)
        assertEquals(400, bmp.height)
    }
}
