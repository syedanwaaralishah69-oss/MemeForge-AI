package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "creations")
data class MemeCreation(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val type: String, // "MEME", "CAPTION", "PHOTO_VIDEO", "VOICE"
    val imageUri: String? = null,
    val topText: String? = null,
    val bottomText: String? = null,
    val fullCaption: String? = null,
    val style: String? = null,
    val language: String? = null,
    val aspectRatio: String = "1:1",
    val filterName: String = "Normal",
    val timestamp: Long = System.currentTimeMillis()
)
