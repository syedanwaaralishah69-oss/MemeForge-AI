package com.example.data.local

import com.example.data.model.MemeCreation
import kotlinx.coroutines.flow.Flow

class CreationRepository(private val creationDao: CreationDao) {
    val allCreations: Flow<List<MemeCreation>> = creationDao.getAllCreations()

    fun getCreationsByType(type: String): Flow<List<MemeCreation>> =
        creationDao.getCreationsByType(type)

    suspend fun getCreationById(id: Long): MemeCreation? =
        creationDao.getCreationById(id)

    suspend fun insertCreation(creation: MemeCreation): Long =
        creationDao.insertCreation(creation)

    suspend fun updateCreation(creation: MemeCreation) =
        creationDao.updateCreation(creation)

    suspend fun deleteCreation(id: Long) =
        creationDao.deleteCreationById(id)
}
