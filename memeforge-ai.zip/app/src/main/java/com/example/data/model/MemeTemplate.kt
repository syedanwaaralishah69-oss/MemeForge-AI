package com.example.data.model

data class MemeTemplate(
    val id: String,
    val title: String,
    val category: String, // "Meme", "Funny Reel", "Story", "Quote", "Birthday", "Friendship", "Love", "School", "Pakistani/Desi comedy", "Reaction"
    val drawableRes: Int? = null,
    val defaultTopText: String = "",
    val defaultBottomText: String = "",
    val sampleCaption: String = "",
    val description: String = "",
    val recommendedAspect: AspectRatioPreset = AspectRatioPreset.INSTA_FB_POST,
    val defaultMusicTrack: String = "Viral Phonk Beat"
)

data class StickerItem(
    val id: String,
    val emoji: String,
    val xPercent: Float = 0.5f,
    val yPercent: Float = 0.5f,
    val sizeSp: Float = 42f,
    val rotation: Float = 0f,
    val isAnimated: Boolean = false
)

enum class TextAnimationType(val label: String) {
    NONE("None"),
    PULSE("Pulse"),
    SHAKE("Shake"),
    BOUNCE("Bounce"),
    POP_IN("Pop-In"),
    GLOW("Glow")
}

enum class PlacementMode(val label: String) {
    AUTO("AI Automatic"),
    TOP_BOTTOM("Top & Bottom"),
    TOP_ONLY("Top Only"),
    BOTTOM_ONLY("Bottom Only"),
    CENTER_CARD("Center Card"),
    FLOATING_HEADER("Floating Header")
}

data class TextLayerItem(
    val id: String,
    val text: String,
    val isTop: Boolean = true,
    val yPercent: Float = 0.1f,
    val fontSizeSp: Float = 28f,
    val fontName: String = "Impact",
    val textColorHex: String = "#FFFFFF",
    val strokeColorHex: String = "#000000",
    val hasStroke: Boolean = true,
    val hasShadow: Boolean = true,
    val shadowColorHex: String = "#000000",
    val shadowRadius: Float = 6f,
    val alignment: String = "Center", // "Left", "Center", "Right"
    val animationType: TextAnimationType = TextAnimationType.NONE
)

enum class AspectRatioPreset(val label: String, val ratioWidth: Float, val ratioHeight: Float, val badge: String) {
    TIKTOK_REELS_SHORTS("YouTube Shorts", 9f, 16f, "9:16"),
    INSTAGRAM_REELS("Instagram Reels", 9f, 16f, "9:16"),
    TIKTOK("TikTok", 9f, 16f, "9:16"),
    FACEBOOK_REELS("Facebook Reels", 9f, 16f, "9:16"),
    WHATSAPP_STATUS("WhatsApp Status", 9f, 16f, "9:16"),
    INSTA_FB_POST("Instagram/Facebook Post", 1f, 1f, "1:1"),
    YT_THUMBNAIL("YouTube Thumbnail", 16f, 9f, "16:9"),
    PORTRAIT_POST("Instagram Portrait", 4f, 5f, "4:5")
}

data class FilterPreset(
    val name: String,
    val brightness: Float = 0f,
    val contrast: Float = 1f,
    val isGrayscale: Boolean = false,
    val isSepia: Boolean = false,
    val isVintage: Boolean = false,
    val isInvert: Boolean = false,
    val blurRadius: Float = 0f
)

enum class MotionEffectType(val label: String) {
    KEN_BURNS("Ken Burns Zoom"),
    PAN("Pan"),
    ZOOM_IN_OUT("Zoom In/Out"),
    FADE("Fade"),
    SLIDE("Slide"),
    SHAKE("Shake"),
    BOUNCE("Bounce")
}

data class StoryScene(
    val sceneNumber: Int,
    val title: String,
    val caption: String,
    val voiceoverScript: String,
    val durationSeconds: Int = 5,
    val visualDescription: String = "",
    val imageUri: String? = null
)

data class AiStory(
    val id: String,
    val topic: String,
    val title: String,
    val synopsis: String,
    val language: String,
    val scenes: List<StoryScene>
)

enum class AutoCreateStage(val title: String, val description: String) {
    PHOTO("Photo Input", "Image loaded & optimized"),
    AI_ANALYSIS("AI Vision Analysis", "Gemini analyzing scene & humor context"),
    JOKE("Humor & Joke Engine", "Creating contextual viral punchlines"),
    MEME("Meme Synthesis", "Automatic layout & text placement"),
    ANIMATION("Motion & Effects", "Adding dynamic transitions & kinetic scale"),
    VOICEOVER("AI Voiceover", "Synthesizing voiceover narrative"),
    SUBTITLES("Subtitles & Hooks", "Generating auto-captions & hashtags"),
    VIDEO_PREVIEW("Final Preview", "Ready to preview, export & share")
}

// --- STEP 3 MODELS ---

enum class VoiceOption(val label: String, val pitch: Float, val speed: Float) {
    MALE("Male", 0.85f, 1.0f),
    FEMALE("Female", 1.2f, 1.05f),
    ENERGETIC("Energetic", 1.15f, 1.25f),
    FUNNY("Funny", 1.35f, 1.2f),
    CALM("Calm", 0.95f, 0.9f),
    STORYTELLING("Storytelling", 0.8f, 0.92f)
}

data class SubtitleWord(
    val word: String,
    val startSec: Float,
    val endSec: Float
)

data class SubtitleItem(
    val id: String,
    val text: String,
    val startSec: Float,
    val endSec: Float,
    val words: List<SubtitleWord> = emptyList()
)

enum class SubtitleStyle(val label: String, val fontColorHex: String, val highlightColorHex: String, val bgColorHex: String) {
    HORMOZI_YELLOW("Viral Yellow", "#FFFF00", "#FF0055", "#000000"),
    NEON_PUNCH("Neon Cyan", "#00FFFF", "#FF00FF", "#110D28"),
    CLEAN_WHITE("Minimal White", "#FFFFFF", "#00FF66", "#00000088"),
    BOXED_BADGE("Badge Box", "#FFFFFF", "#FFEB3B", "#673AB7")
}

enum class AudioCategory(val label: String) {
    FUNNY("Funny"),
    SUSPENSE("Suspense"),
    EMOTIONAL("Emotional"),
    HAPPY("Happy"),
    CINEMATIC("Cinematic"),
    GAMING("Gaming"),
    DESI("Desi")
}

data class AudioTrackItem(
    val id: String,
    val name: String,
    val category: AudioCategory,
    val durationSec: Int,
    val isSfx: Boolean = false,
    val audioTag: String = ""
)

enum class TimelineTrackType(val label: String, val badgeColorHex: String) {
    VIDEO("Video", "#EC4899"),
    IMAGES("Images", "#8B5CF6"),
    TEXT("Text", "#06B6D4"),
    VOICE("Voice", "#F59E0B"),
    MUSIC("Music", "#10B981"),
    SFX("Sound Effects", "#EF4444"),
    SUBTITLES("Subtitles", "#FACC15")
}

data class TimelineClip(
    val id: String,
    val trackType: TimelineTrackType,
    val label: String,
    val startSec: Float,
    val durationSec: Float,
    val volume: Float = 1.0f,
    val speed: Float = 1.0f
)
