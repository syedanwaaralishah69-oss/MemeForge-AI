package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.MemeCreation
import kotlinx.coroutines.flow.Flow

@Dao
interface CreationDao {
    @Query("SELECT * FROM creations ORDER BY timestamp DESC")
    fun getAllCreations(): Flow<List<MemeCreation>>

    @Query("SELECT * FROM creations WHERE type = :type ORDER BY timestamp DESC")
    fun getCreationsByType(type: String): Flow<List<MemeCreation>>

    @Query("SELECT * FROM creations WHERE id = :id")
    suspend fun getCreationById(id: Long): MemeCreation?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCreation(creation: MemeCreation): Long

    @Update
    suspend fun updateCreation(creation: MemeCreation)

    @Query("DELETE FROM creations WHERE id = :id")
    suspend fun deleteCreationById(id: Long)

    @Query("DELETE FROM creations")
    suspend fun clearAllCreations()
}
