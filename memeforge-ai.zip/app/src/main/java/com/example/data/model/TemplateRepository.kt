package com.example.data.model

import com.example.R

object TemplateRepository {
    val templates = listOf(
        MemeTemplate(
            id = "cool_cat",
            title = "Cool Boss Cat",
            category = "Meme",
            drawableRes = R.drawable.template_cool_cat,
            defaultTopText = "ENTERED THE ROOM LIKE",
            defaultBottomText = "I OWN THE ENTIRE BUILDING",
            sampleCaption = "Swag level: infinite sunglasses indoors 😎",
            description = "Iconic stylish cat meme for confident and savage moments",
            recommendedAspect = AspectRatioPreset.INSTA_FB_POST,
            defaultMusicTrack = "Viral Phonk Beat"
        ),
        MemeTemplate(
            id = "funny_reel_chaos",
            title = "Morning Alarm Reel",
            category = "Funny Reel",
            drawableRes = R.drawable.template_shocked_dog,
            defaultTopText = "MY ALARM AT 6:00 AM",
            defaultBottomText = "ME WAKING UP AT 1:30 PM",
            sampleCaption = "The shortest 5 minutes in human history 😴⏱️",
            description = "High energy animated reel template for sleep and morning fails",
            recommendedAspect = AspectRatioPreset.TIKTOK_REELS_SHORTS,
            defaultMusicTrack = "Comedy Tiptoe"
        ),
        MemeTemplate(
            id = "desi_fan",
            title = "Disappointed Pakistani Fan",
            category = "Pakistani/Desi comedy",
            drawableRes = null,
            defaultTopText = "ME WATCHING MY PLANS COLLAPSE",
            defaultBottomText = "IN THE FIRST 5 MINUTES OF MONDAY",
            sampleCaption = "The universal posture of utter disappointment 🤦‍♂️",
            description = "Classic hands-on-hips disappointed reaction for Pakistani cricket & life",
            recommendedAspect = AspectRatioPreset.INSTA_FB_POST,
            defaultMusicTrack = "Desi Dhol Funk"
        ),
        MemeTemplate(
            id = "story_backbencher",
            title = "The Backbencher Saga",
            category = "Story",
            drawableRes = null,
            defaultTopText = "WHEN THE TEACHER ASKS FOR VOLUNTEERS",
            defaultBottomText = "INSTANT EYE CONTACT WITH THE FLOOR",
            sampleCaption = "A multi-scene survival story in exam season 📚",
            description = "Storytelling template for students and classroom adventures",
            recommendedAspect = AspectRatioPreset.TIKTOK_REELS_SHORTS,
            defaultMusicTrack = "Lo-fi Meme Chill"
        ),
        MemeTemplate(
            id = "quote_deep_thoughts",
            title = "Philosophical Chai",
            category = "Quote",
            drawableRes = null,
            defaultTopText = "“PEOPLE COME AND GO”",
            defaultBottomText = "BUT CHAI IS ETERNAL ☕",
            sampleCaption = "Deep motivation powered by hot tea and existential peace ✨",
            description = "Inspirational aesthetic quote format with modern card layout",
            recommendedAspect = AspectRatioPreset.PORTRAIT_POST,
            defaultMusicTrack = "Synthwave Arcade"
        ),
        MemeTemplate(
            id = "birthday_bashing",
            title = "Happy Birthday Legend",
            category = "Birthday",
            drawableRes = null,
            defaultTopText = "HAPPY BIRTHDAY BRO!",
            defaultBottomText = "ANOTHER YEAR OLDER, STILL ZERO MATURITY 🎂🎉",
            sampleCaption = "Birthday roasting template for best friends and siblings",
            recommendedAspect = AspectRatioPreset.INSTA_FB_POST,
            defaultMusicTrack = "Happy Ukulele Beat"
        ),
        MemeTemplate(
            id = "friendship_bill",
            title = "The Restaurant Bill Split",
            category = "Friendship",
            drawableRes = null,
            defaultTopText = "BEST FRIEND: 'BHAI MAIN TREAT DOONGA'",
            defaultBottomText = "AT THE COUNTER: 'BHAI MERA WALLET GHAR REH GAYA' 💀",
            sampleCaption = "Peak friendship scam moments at payment counter 💸",
            description = "Hilarious bro friendship template",
            recommendedAspect = AspectRatioPreset.TIKTOK_REELS_SHORTS,
            defaultMusicTrack = "Desi Dhol Funk"
        ),
        MemeTemplate(
            id = "love_single_life",
            title = "Romantic Expectations",
            category = "Love",
            drawableRes = null,
            defaultTopText = "EVERYONE ON VALENTINE'S DAY",
            defaultBottomText = "ME IN BED WITH 10 PACKETS OF SNACKS ❤️🍿",
            sampleCaption = "Romantic comedy template for proud singles",
            recommendedAspect = AspectRatioPreset.INSTA_FB_POST,
            defaultMusicTrack = "Romantic Acoustic Guitar"
        ),
        MemeTemplate(
            id = "school_exam_hall",
            title = "The Hall of Doom",
            category = "School",
            drawableRes = null,
            defaultTopText = "TEACHER: 'QUESTION PAPER IS VERY EASY'",
            defaultBottomText = "QUESTION 1: 'CALCULATE THE MASS OF THE SUN USING A PENCIL' 📝",
            sampleCaption = "Student exam trauma format",
            recommendedAspect = AspectRatioPreset.TIKTOK_REELS_SHORTS,
            defaultMusicTrack = "Suspense Drone"
        ),
        MemeTemplate(
            id = "reaction_shocked",
            title = "Shocked Shiba Reaction",
            category = "Reaction",
            drawableRes = R.drawable.template_shocked_dog,
            defaultTopText = "WHEN YOU CHECK YOUR BANK ACCOUNT",
            defaultBottomText = "AFTER A WEEKEND OF 'TREATING MYSELF'",
            sampleCaption = "Financial devastation in 4K resolution 😭💸",
            description = "Expressive shocked face for unexpected disasters",
            recommendedAspect = AspectRatioPreset.INSTA_FB_POST,
            defaultMusicTrack = "Comedy Tiptoe"
        )
    )
}

object AudioLibraryRepository {
    val tracks = listOf(
        AudioTrackItem("m1", "Viral Phonk Beat", AudioCategory.FUNNY, 15),
        AudioTrackItem("m2", "Comedy Tiptoe", AudioCategory.FUNNY, 12),
        AudioTrackItem("m3", "Cartoon Whistle Bounce", AudioCategory.FUNNY, 8, isSfx = true, audioTag = "BOUNCE"),
        AudioTrackItem("m4", "Suspense Drone", AudioCategory.SUSPENSE, 20),
        AudioTrackItem("m5", "Dramatic Heartbeat", AudioCategory.SUSPENSE, 10, isSfx = true, audioTag = "HEARTBEAT"),
        AudioTrackItem("m6", "Sad Violin Solitude", AudioCategory.EMOTIONAL, 18),
        AudioTrackItem("m7", "Piano Memories", AudioCategory.EMOTIONAL, 25),
        AudioTrackItem("m8", "Happy Ukulele Beat", AudioCategory.HAPPY, 15),
        AudioTrackItem("m9", "Sunny Morning Whistle", AudioCategory.HAPPY, 14),
        AudioTrackItem("m10", "Epic Cinematic Brass", AudioCategory.CINEMATIC, 30),
        AudioTrackItem("m11", "Hollywood Boom Riser", AudioCategory.CINEMATIC, 8, isSfx = true, audioTag = "RISER"),
        AudioTrackItem("m12", "8-Bit Retro Level Up", AudioCategory.GAMING, 10),
        AudioTrackItem("m13", "Arcade Game Over", AudioCategory.GAMING, 5, isSfx = true, audioTag = "GAMEOVER"),
        AudioTrackItem("m14", "Desi Dhol Funk", AudioCategory.DESI, 22),
        AudioTrackItem("m15", "Bhangra Energy Drop", AudioCategory.DESI, 18),
        AudioTrackItem("m16", "Sitar Chill Lounge", AudioCategory.DESI, 24)
    )
}
