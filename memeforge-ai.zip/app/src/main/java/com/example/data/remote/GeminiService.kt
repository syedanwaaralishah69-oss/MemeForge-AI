package com.example.data.remote

import android.graphics.Bitmap
import android.util.Base64
import android.util.Log
import com.example.BuildConfig
import com.example.data.model.AiStory
import com.example.data.model.StoryScene
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.UUID
import java.util.concurrent.TimeUnit
import kotlin.random.Random

data class GeneratedMemeResult(
    val topText: String,
    val bottomText: String,
    val punchline: String,
    val style: String,
    val language: String,
    val isAiGenerated: Boolean = true
)

object GeminiService {
    private const val TAG = "GeminiService"
    private const val MODEL_NAME = "gemini-3.5-flash"
    private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models/"

    private val client = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    fun isApiKeyConfigured(): Boolean {
        val key = BuildConfig.GEMINI_API_KEY
        return key.isNotBlank() && key != "MY_GEMINI_API_KEY"
    }

    suspend fun generateMemeCaption(
        bitmap: Bitmap?,
        style: String,
        language: String,
        customPrompt: String = ""
    ): GeneratedMemeResult = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        val hasValidKey = apiKey.isNotBlank() && apiKey != "MY_GEMINI_API_KEY"

        if (!hasValidKey) {
            Log.w(TAG, "Gemini API key is not configured in Secrets. Using offline creative engine.")
            return@withContext getCreativeEngineCaption(style, language, customPrompt)
        }

        try {
            val systemPrompt = """
                You are MemeForge AI, an elite viral meme creator and humor specialist.
                Analyze the provided image and generate a top-tier, laugh-out-loud funny meme caption tailored to the scene and parameters.
                Style/Tone: $style
                Target Language: $language
                ${if (customPrompt.isNotBlank()) "User context/guidance: $customPrompt" else ""}

                Format your response strictly as valid JSON with three keys:
                {
                   "topText": "Short catchy setup (uppercase, max 7 words)",
                   "bottomText": "Hilarious punchline (uppercase, max 10 words)",
                   "punchline": "Alternative viral one-liner caption for social media reels/status"
                }
                Do not include markdown blocks or other text outside the JSON.
            """.trimIndent()

            val contentsArray = JSONArray()
            val contentObj = JSONObject()
            val partsArray = JSONArray()

            // Text instruction part
            val textPart = JSONObject()
            textPart.put("text", systemPrompt)
            partsArray.put(textPart)

            // Image part if available
            if (bitmap != null) {
                val base64Image = bitmapToBase64(bitmap)
                val inlineDataObj = JSONObject()
                inlineDataObj.put("mimeType", "image/jpeg")
                inlineDataObj.put("data", base64Image)

                val imagePart = JSONObject()
                imagePart.put("inlineData", inlineDataObj)
                partsArray.put(imagePart)
            }

            contentObj.put("parts", partsArray)
            contentsArray.put(contentObj)

            val requestJson = JSONObject()
            requestJson.put("contents", contentsArray)

            val generationConfig = JSONObject()
            generationConfig.put("temperature", 0.9)
            requestJson.put("generationConfig", generationConfig)

            val url = "$BASE_URL$MODEL_NAME:generateContent?key=$apiKey"
            val body = requestJson.toString().toRequestBody("application/json".toMediaType())
            val request = Request.Builder()
                .url(url)
                .post(body)
                .build()

            val response = client.newCall(request).execute()
            val responseBody = response.body?.string() ?: ""

            if (!response.isSuccessful) {
                Log.e(TAG, "Gemini API failed: code=${response.code}, body=$responseBody")
                return@withContext getCreativeEngineCaption(style, language, customPrompt)
            }

            val jsonResponse = JSONObject(responseBody)
            val candidates = jsonResponse.optJSONArray("candidates")
            val firstCandidate = candidates?.optJSONObject(0)
            val content = firstCandidate?.optJSONObject("content")
            val parts = content?.optJSONArray("parts")
            val text = parts?.optJSONObject(0)?.optString("text") ?: ""

            parseMemeJson(text, style, language)
        } catch (e: Exception) {
            Log.e(TAG, "Error in Gemini call: ${e.message}", e)
            getCreativeEngineCaption(style, language, customPrompt)
        }
    }

    // Context-Aware Caption Generator with Modifiers
    suspend fun generateContextAwareCaptions(
        bitmap: Bitmap?,
        topic: String,
        style: String,
        language: String,
        modifier: String = "Standard",
        customInstruction: String = ""
    ): List<String> = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        val hasValidKey = apiKey.isNotBlank() && apiKey != "MY_GEMINI_API_KEY"

        if (!hasValidKey) {
            return@withContext getOfflineContextCaptions(topic, style, language, modifier)
        }

        try {
            val modifierPrompt = when (modifier) {
                "Shorter" -> "Make each caption extremely punchy, short and impactful (under 7 words)."
                "Funnier" -> "Make the humor savage, self-deprecating, and outrageously funny."
                "More Desi" -> "Infuse heavy relatable South Asian/Pakistani cultural references, street slang, chai/biryani/rishta tropes."
                else -> ""
            }

            val prompt = """
                You are MemeForge AI. Analyze the image (if provided) and topic to generate 4 viral social media captions.
                Topic: ${if (topic.isBlank()) "Image scene and mood" else topic}
                Style/Tone: $style
                Language: $language
                ${if (modifierPrompt.isNotBlank()) "Constraint: $modifierPrompt" else ""}
                ${if (customInstruction.isNotBlank()) "Additional instruction: $customInstruction" else ""}

                Include matching hashtags (#viral, #memes, etc.) and expressive emojis.
                Return ONLY a JSON array of strings: ["caption 1", "caption 2", "caption 3", "caption 4"]
            """.trimIndent()

            val contentsArray = JSONArray()
            val contentObj = JSONObject()
            val partsArray = JSONArray()

            partsArray.put(JSONObject().put("text", prompt))

            if (bitmap != null) {
                val base64Image = bitmapToBase64(bitmap)
                val inlineDataObj = JSONObject()
                    .put("mimeType", "image/jpeg")
                    .put("data", base64Image)
                partsArray.put(JSONObject().put("inlineData", inlineDataObj))
            }

            contentObj.put("parts", partsArray)
            contentsArray.put(contentObj)

            val requestJson = JSONObject()
                .put("contents", contentsArray)
                .put("generationConfig", JSONObject().put("temperature", 0.88))

            val url = "$BASE_URL$MODEL_NAME:generateContent?key=$apiKey"
            val body = requestJson.toString().toRequestBody("application/json".toMediaType())
            val request = Request.Builder().url(url).post(body).build()

            val response = client.newCall(request).execute()
            val responseBody = response.body?.string() ?: ""

            var cleanText = JSONObject(responseBody)
                .getJSONArray("candidates")
                .getJSONObject(0)
                .getJSONObject("content")
                .getJSONArray("parts")
                .getJSONObject(0)
                .getString("text")
                .trim()

            if (cleanText.startsWith("```json")) cleanText = cleanText.removePrefix("```json")
            if (cleanText.startsWith("```")) cleanText = cleanText.removePrefix("```")
            if (cleanText.endsWith("```")) cleanText = cleanText.removeSuffix("```")
            cleanText = cleanText.trim()

            val arr = JSONArray(cleanText)
            val result = mutableListOf<String>()
            for (i in 0 until arr.length()) {
                result.add(arr.getString(i))
            }
            if (result.isNotEmpty()) result else getOfflineContextCaptions(topic, style, language, modifier)
        } catch (e: Exception) {
            getOfflineContextCaptions(topic, style, language, modifier)
        }
    }

    // AI Story Generator
    suspend fun generateAiStory(
        topic: String,
        language: String
    ): AiStory = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        val hasValidKey = apiKey.isNotBlank() && apiKey != "MY_GEMINI_API_KEY"

        if (!hasValidKey) {
            return@withContext getOfflineAiStory(topic, language)
        }

        try {
            val prompt = """
                You are MemeForge AI Story Studio.
                Create a hilarious, engaging 4-scene comedic story based on this topic:
                Topic: "$topic"
                Language: $language

                Format your response strictly as valid JSON:
                {
                   "title": "Catchy Story Title",
                   "synopsis": "One sentence summary of the story",
                   "scenes": [
                      {
                        "sceneNumber": 1,
                        "title": "Scene 1 Title",
                        "caption": "Punchy subtitle for the screen",
                        "voiceoverScript": "Narrator script for this scene (2-3 sentences)",
                        "durationSeconds": 5,
                        "visualDescription": "Visual direction for what is happening"
                      },
                      ... 4 scenes total
                   ]
                }
                Return ONLY JSON.
            """.trimIndent()

            val contentsArray = JSONArray().put(
                JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt)))
            )
            val requestJson = JSONObject()
                .put("contents", contentsArray)
                .put("generationConfig", JSONObject().put("temperature", 0.9))

            val url = "$BASE_URL$MODEL_NAME:generateContent?key=$apiKey"
            val body = requestJson.toString().toRequestBody("application/json".toMediaType())
            val request = Request.Builder().url(url).post(body).build()

            val response = client.newCall(request).execute()
            val responseBody = response.body?.string() ?: ""

            var cleanText = JSONObject(responseBody)
                .getJSONArray("candidates")
                .getJSONObject(0)
                .getJSONObject("content")
                .getJSONArray("parts")
                .getJSONObject(0)
                .getString("text")
                .trim()

            if (cleanText.startsWith("```json")) cleanText = cleanText.removePrefix("```json")
            if (cleanText.startsWith("```")) cleanText = cleanText.removePrefix("```")
            if (cleanText.endsWith("```")) cleanText = cleanText.removeSuffix("```")
            cleanText = cleanText.trim()

            val json = JSONObject(cleanText)
            val title = json.optString("title", "The Epic Adventure")
            val synopsis = json.optString("synopsis", topic)
            val scenesArray = json.optJSONArray("scenes")
            val scenes = mutableListOf<StoryScene>()

            if (scenesArray != null) {
                for (i in 0 until scenesArray.length()) {
                    val sObj = scenesArray.getJSONObject(i)
                    scenes.add(
                        StoryScene(
                            sceneNumber = sObj.optInt("sceneNumber", i + 1),
                            title = sObj.optString("title", "Scene ${i + 1}"),
                            caption = sObj.optString("caption", "Scene ${i + 1} caption"),
                            voiceoverScript = sObj.optString("voiceoverScript", "Voiceover script here"),
                            durationSeconds = sObj.optInt("durationSeconds", 5),
                            visualDescription = sObj.optString("visualDescription", "Visual details")
                        )
                    )
                }
            }

            if (scenes.isNotEmpty()) {
                AiStory(
                    id = UUID.randomUUID().toString(),
                    topic = topic,
                    title = title,
                    synopsis = synopsis,
                    language = language,
                    scenes = scenes
                )
            } else {
                getOfflineAiStory(topic, language)
            }
        } catch (e: Exception) {
            getOfflineAiStory(topic, language)
        }
    }

    private fun parseMemeJson(rawText: String, style: String, language: String): GeneratedMemeResult {
        try {
            var cleanText = rawText.trim()
            if (cleanText.startsWith("```json")) cleanText = cleanText.removePrefix("```json")
            if (cleanText.startsWith("```")) cleanText = cleanText.removePrefix("```")
            if (cleanText.endsWith("```")) cleanText = cleanText.removeSuffix("```")
            cleanText = cleanText.trim()

            val json = JSONObject(cleanText)
            val top = json.optString("topText", "WHEN LIFE GIVES YOU MEMES")
            val bottom = json.optString("bottomText", "YOU FORGE THEM WITH AI")
            val punchline = json.optString("punchline", "$top $bottom")

            return GeneratedMemeResult(
                topText = top.uppercase(),
                bottomText = bottom.uppercase(),
                punchline = punchline,
                style = style,
                language = language,
                isAiGenerated = true
            )
        } catch (e: Exception) {
            val lines = rawText.lines().filter { it.isNotBlank() }
            val top = lines.getOrNull(0)?.replace("\"", "")?.trim() ?: "ME WHEN"
            val bottom = lines.getOrNull(1)?.replace("\"", "")?.trim() ?: "NO EXPLANATION NEEDED"
            return GeneratedMemeResult(
                topText = top.uppercase(),
                bottomText = bottom.uppercase(),
                punchline = "$top $bottom",
                style = style,
                language = language,
                isAiGenerated = true
            )
        }
    }

    private fun bitmapToBase64(bitmap: Bitmap): String {
        val maxDim = 800
        val width = bitmap.width
        val height = bitmap.height
        val scaledBitmap = if (width > maxDim || height > maxDim) {
            val ratio = width.toFloat() / height.toFloat()
            val newWidth: Int
            val newHeight: Int
            if (ratio > 1) {
                newWidth = maxDim
                newHeight = (maxDim / ratio).toInt()
            } else {
                newHeight = maxDim
                newWidth = (maxDim * ratio).toInt()
            }
            Bitmap.createScaledBitmap(bitmap, newWidth, newHeight, true)
        } else {
            bitmap
        }

        val outputStream = ByteArrayOutputStream()
        scaledBitmap.compress(Bitmap.CompressFormat.JPEG, 75, outputStream)
        val bytes = outputStream.toByteArray()
        return Base64.encodeToString(bytes, Base64.NO_WRAP)
    }

    // Creative Offline Humor Generator for all Styles & Languages
    fun getCreativeEngineCaption(style: String, language: String, customPrompt: String): GeneratedMemeResult {
        val memes = when (language) {
            "Roman Urdu" -> when (style) {
                "Desi Pakistani", "Desi/Pakistani" -> listOf(
                    Pair("AMMI KE SAMNE PHONE CHALAYA", "SARI BEEMARION KI JAD YAHI HAI! 📱🔥"),
                    Pair("RISHTEDAAR: BETA AGAY KA KYA SOCHA HAI?", "MAIN: BAS CHAI PI KE NIKALNA HAI ☕"),
                    Pair("BIRYANI MEIN ELAICHI A GAYI", "MOOD SWING LEVEL: MAXIMUM 😭"),
                    Pair("MEHMAN: BETA RESULT KAB AA RAHA HAI?", "MAIN: UNCLE APKI PENSION KAB KHTM HO RAHI? 💀")
                )
                "Savage", "Sarcastic" -> listOf(
                    Pair("TUMHARI OPINION MAANGI THI KISI NE?", "GOOGLE MAPS BHI APKI AUQAT NAHI DHUND SAKA 🔥"),
                    Pair("SEEN PE CHORNA MERI HOBBY NAHI", "LEKIN APKO REPLY DENA MERI TOUHEEN HAI 💅"),
                    Pair("CONFIDENCE CHECK KARO", "ZERO KNOWLEDGE, 100% GYAN 🤡"),
                    Pair("MAIN TO SIRF HANSTA HOON", "TAAKE SAMNE WALA CONFUSE HO JAYE 🤣")
                )
                "School", "School/Student" -> listOf(
                    Pair("EXAM HALL MEIN QUESTION PAPER DEKHA", "SYLLABUS BHI BOL RAHA MAIN APKO JANNTA NAHI 📚"),
                    Pair("TEACHER: KAL SAB ASSIGNMENT LE KE AYEN", "BACKBENCHERS: KAL TO AETBAAR HAI NA SIR? 🤣"),
                    Pair("5 MINUTE PADHAI, 2 GHANTAY REELS", "STUDENT LIFE IN A NUTSHELL ⏳")
                )
                "Friendship" -> listOf(
                    Pair("DOST NE BIL PAY KARNE KI KOSHISH KI", "ZAMEEN HIL GAYI, AFTAB ULTA NIKAL AYA 💸"),
                    Pair("DOST: BHAI SECRET HAI KISI KO MAT BATANA", "MAIN 5 MINUTE BAAD: PURAY MOHALLAY MEIN LIVE 🗣️"),
                    Pair("MERI ZINDAGI KE SAARE GALAT FAISLE", "US DOST KI WAJAH SE HAIN JIS KA NAAM NAHI LE SAKTA 😂")
                )
                "Love" -> listOf(
                    Pair("UNHONE REPLY DIYA 'K'", "MAIN PURI RAAT SHAYARI LIKHTA RAHA 💔"),
                    Pair("CHAI AUR TUM", "DONO HI MERAY NASHEEBN MEIN NAHI ☕❤️"),
                    Pair("SINGLE HO KAR BHI BREAKUP WALE GAANE", "FEEL PURI AATI HAI BHAI 🎶")
                )
                "Family" -> listOf(
                    Pair("BAAP KA PHONE CALL PICK NA KARO", "PURAY KHANDAN MEIN F.I.R DARJ HO JATI HAI 🚨"),
                    Pair("MUMMY: KHANA BAN GAYA HAI AA JAO", "MAIN GAYA TO PATTA CHALA ROTI BHI NAHI PAKI 🫓"),
                    Pair("CHOTAY BHAI NE REMOTE CHHEEN LIYA", "THIRD WORLD WAR BEGINS IN LIVING ROOM 🥊")
                )
                else -> listOf(
                    Pair("PLANNING: SUBHA 6 BAJE UTHUNGA", "REALITY: 12 BAJE ANKH KHULI AUR AFSOOS BHI NAHI 😴"),
                    Pair("SALARY AATI HAI TO AISA LAGTA HAI", "GUEST APPEARANCE KE LIYE AAYI HO 💸"),
                    Pair("ME TRYING TO FIX MY SLEEP CYCLE", "SLEEP CYCLE FIXING MY WHOLE LIFE IN REVERSE 🔄")
                )
            }
            "Urdu" -> when (style) {
                "Desi Pakistani", "Desi/Pakistani" -> listOf(
                    Pair("امی کے سامنے فون آن کیا", "ساری بیماریوں کی جڑ یہی فون ہے! 📱"),
                    Pair("بریانی میں الائچی آ گئی", "موڈ آف لیول انفینٹی 😭"),
                    Pair("رشتہ دار: بیٹا آگے کیا کرنا ہے؟", "میں: بس چائے پی کے جانا ہے! ☕")
                )
                "School", "School/Student" -> listOf(
                    Pair("امتحان میں پرچہ دیکھا تو پتا چلا", "ہم غلط صدی میں پیدا ہو گئے ہیں 📚"),
                    Pair("پنج منٹ پڑھائی", "چار گھنٹے انسٹاگرام ریلز 🕒")
                )
                else -> listOf(
                    Pair("ہمیشہ دیر کر دیتا ہوں میں", "صبح جلدی اٹھنے کے ارادے میں ⏰"),
                    Pair("زندگی میں سکون اور چائے", "دونوں ہی نصیب سے ملتے ہیں ☕")
                )
            }
            "Hinglish" -> when (style) {
                "Savage", "Sarcastic" -> listOf(
                    Pair("PEOPLE WHO GIVE UNWANTED ADVICE", "ARE THE ONES UNEMPLOYED IN REAL LIFE 💀"),
                    Pair("APKA ATTITUDE APNE PAAS RAKHO", "HUMSE HANDLE NAHI HOGA AUR BARDASHT TO BILKUL NAHI 🔥"),
                    Pair("BRO THINKS HE IS THE MAIN CHARACTER", "NPC DETECTED IN REAL TIME 🤡")
                )
                "School", "School/Student" -> listOf(
                    Pair("ONE NIGHT BEFORE SEMESTER EXAMS", "EINSTEIN KA REINCARNATION HO GAYA HOON 🧠⚡"),
                    Pair("TEACHER: WHY ARE YOU LAUGHING AT THE BACK?", "MY BRAIN: THAT RANDOM MEME FROM 2021 😭")
                )
                else -> listOf(
                    Pair("SALARY DAY FEELS LIKE A KING", "5 DAYS LATER: BHAI 20 RUPAYE GPAY KAR DE 💸"),
                    Pair("WHEN YOU SAY '5 MINS MEIN AAYA'", "AND YOU HAVEN'T EVEN LEFT BED YET 🛌")
                )
            }
            else -> when (style) {
                "Savage", "Sarcastic" -> listOf(
                    Pair("I WOULD AGREE WITH YOU", "BUT THEN WE WOULD BOTH BE WRONG 💅"),
                    Pair("I'M NOT LAZY", "I'M ON ENERGY-SAVING MODE 🔋"),
                    Pair("MY PATIENCE IS AS THIN", "AS MY WALLET RIGHT NOW 💀")
                )
                "School", "School/Student" -> listOf(
                    Pair("ME READING THE FIRST QUESTION OF THE EXAM", "WONDERING IF I EVEN ENROLLED IN THIS CLASS 📝"),
                    Pair("CALCULATING MINIMUM MARKS NEEDED", "JUST TO BARELY PASS WITH MY DIGNITY 🎓"),
                    Pair("SUBMITTED ASSIGNMENT AT 11:59 PM", "FEELING LIKE ETHAN HUNT IN MISSION IMPOSSIBLE 💥")
                )
                "Cute" -> listOf(
                    Pair("DO I LOOK CHUBBY?", "I AM JUST OVERFLOWING WITH CUTENESS 🐾✨"),
                    Pair("WOKE UP LOOKING THIS ADORABLE", "NO FILTER NEEDED, JUST PURE CHARM 🥰")
                )
                "Friendship" -> listOf(
                    Pair("BEST FRIEND ENTERS THE ROOM", "CHAOS LEVEL ELEVATED TO 999 🌪️"),
                    Pair("WE DON'T EVEN NEED WORDS", "ONE LOOK AND WE BOTH BURST OUT LAUGHING 🤝")
                )
                else -> listOf(
                    Pair("WHEN YOU ACCIDENTALLY OPEN THE FRONT CAMERA", "AND RECONSIDER ALL YOUR LIFE CHOICES 📸"),
                    Pair("MY BRAIN AT 3 AM", "PONDERING WHY WATER IS WET 🧠"),
                    Pair("EXPECTATION VS REALITY", "EXPECTED HOLLYWOOD, GOT COMEDY CIRCUS 🎪")
                )
            }
        }

        val selected = memes[Random.nextInt(memes.size)]
        val punchline = if (customPrompt.isNotBlank()) {
            "${selected.first} — $customPrompt — ${selected.second}"
        } else {
            "${selected.first}: ${selected.second}"
        }

        return GeneratedMemeResult(
            topText = selected.first,
            bottomText = selected.second,
            punchline = punchline,
            style = style,
            language = language,
            isAiGenerated = isApiKeyConfigured()
        )
    }

    private fun getOfflineContextCaptions(
        topic: String,
        style: String,
        language: String,
        modifier: String
    ): List<String> {
        val t = if (topic.isBlank()) "Yeh Scene" else topic

        return when (language) {
            "Roman Urdu" -> when (modifier) {
                "Shorter" -> listOf(
                    "Scene on hai! 🔥 #$t",
                    "Mood: Zero apologies 💀 #Viral",
                    "Yeh alag hi dukh hai 😭 #Desi",
                    "Peak comedy moments 🤣 #Relatable"
                )
                "More Desi" -> listOf(
                    "Ammi: 'Phone ki wajah se hua hai sab!' 📱🔥 #$t #DesiHouseholds",
                    "Biryani mein elaichi aur zindagi mein dukh, dono lazmi hain 🍛💀 #PakistaniVibes",
                    "Rishtedaar: Beta result kab aayega? Me: Uncle dua karein bas 🤲😂 #FamilyInterrogation",
                    "Chai ki pehli chuski aur sara sakoon wapis ☕✨ #DesiRelatable"
                )
                "Funnier" -> listOf(
                    "Maine socha tha 2026 mein akal aayegi, abhi tak to sirf neend aa rahi hai 😴💀 #$t",
                    "Meri galtiyon ki list itni lambi hai ke Netflix documentary ban sakti hai 🎬😭 #PeakChaos",
                    "Confidence check: Exam mein bina parhe sab se pehle submit karna 🤡📝 #StudentLife",
                    "Dost: 'Bhai bill 50-50 karte hain' — Me: 'Main to bas dekhne aaya tha' 💸🤣 #BroLife"
                )
                else -> listOf(
                    "Lagta hai yeh scene sirf meri zindagi mein hi possible hai 😭🔥 #$t #DesiRelatable #MemeForge",
                    "Zindagi chal nahi rahi, bas doud rahi hai ulte raste pe 💀 #PakistaniMemes #Mood",
                    "Rishte mein to hum sab ke dost lagte hain, lekin bill pe ghayab ho jate hain 😂 #FriendshipGoals",
                    "Confidence level: Zero prep ke sath viva attend karna 📚✨ #StudentLife #MemeVibe"
                )
            }
            "Urdu" -> listOf(
                "زندگی میں بس اتنا سکون چاہیے جتنا چائے کی پہلی چسکی میں ہوتا ہے ☕ #اردو #میمز",
                "ابھی تو شروعات ہے، اصل کہانی تو باقی ہے 🔥 #وائرل #مزاح",
                "امتحان میں بیٹھ کر سمجھ آیا کہ غلط دنیا میں آ گئے ہیں 📚 #اسکول #طالب_علم",
                "سچائی کڑوی ہوتی ہے لیکن بریانی لذیذ ہوتی ہے 🍛 #کھانا #خوشی"
            )
            "Hinglish" -> listOf(
                "When $t hits different at 2 AM with zero regrets 💀 #ViralReels #Relatable #Trending",
                "Bro thought he could outsmart destiny with $t 🤡 #PeakComedy #MemeForge",
                "Main character energy with absolute zero budget 💅 #HinglishMemes #VibeCheck",
                "Never let them know your next move... including yourself 🔄 #SigmaGrind #Humor"
            )
            else -> listOf(
                "Living proof that $t is 90% chaos and 10% pure luck 🚀 #Relatable #MemeDaily",
                "Nobody warned me adulthood was going to be 95% $t and 5% pretending to be fine ☕ #Mood",
                "Powered by iced coffee, existential dread, and pure meme culture 💀✨ #CreatorLife",
                "When reality hits harder than Monday morning alarms 💥 #ViralHumor #MemeForgeAI"
            )
        }
    }

    private fun getOfflineAiStory(topic: String, language: String): AiStory {
        val title = if (topic.contains("school", ignoreCase = true) || topic.contains("student", ignoreCase = true)) {
            "The Backbencher Exam Survival"
        } else {
            "The Great Viral Chaos: $topic"
        }

        val scenes = when (language) {
            "Roman Urdu", "Urdu", "Hinglish" -> listOf(
                StoryScene(
                    sceneNumber = 1,
                    title = "The False Confidence",
                    caption = "Subha 7:00 AM — 'Aaj to topper ban ke dikhaunga'",
                    voiceoverScript = "Subha subha student ne tayyari ka ailan kiya. Books kholi aur pehla page parhte hi neend ne hamla kar diya.",
                    durationSeconds = 5,
                    visualDescription = "Student sitting with huge book pile looking dramatically confident"
                ),
                StoryScene(
                    sceneNumber = 2,
                    title = "Exam Hall Ambush",
                    caption = "Exam Paper: 'Define that one thing teacher skipped'",
                    voiceoverScript = "Exam hall mein question paper hath mein aate hi student ko laga ke yeh syllabus Mars ke kisi school se download hua hai.",
                    durationSeconds = 6,
                    visualDescription = "Student staring at exam paper with utter shock and despair"
                ),
                StoryScene(
                    sceneNumber = 3,
                    title = "The Backbencher Signal",
                    caption = "Eye contact with best friend across the room 👀",
                    voiceoverScript = "Dost ki taraf dekha to pata chala wo khud ceiling ke fans count kar raha tha. Dono ke dilon mein ek hi awaaz thi: 'Game over'.",
                    durationSeconds = 6,
                    visualDescription = "Two friends making funny eye contact across exam room"
                ),
                StoryScene(
                    sceneNumber = 4,
                    title = "The Triumphant Exit",
                    caption = "Canteen mein samosa party: 'Passing marks to aa hi jayenge!' 🥟",
                    voiceoverScript = "Paper jaisa bhi hua ho, exam hall se nikal kar canteen mein samosa khana qoumi farz hai. Confidence level wapis 100 percent!",
                    durationSeconds = 6,
                    visualDescription = "Celebrating at canteen with chai and samosa laughing together"
                )
            )
            else -> listOf(
                StoryScene(
                    sceneNumber = 1,
                    title = "The Master Plan",
                    caption = "7:00 AM — 'Today I will conquer everything'",
                    voiceoverScript = "Our hero woke up with glorious motivation, opened the study desk, and immediately spent two hours organizing pens.",
                    durationSeconds = 5,
                    visualDescription = "Hero sitting with books and dramatic coffee mug"
                ),
                StoryScene(
                    sceneNumber = 2,
                    title = "The Sudden Shock",
                    caption = "Question 1 was not in the textbook 💀",
                    voiceoverScript = "The test arrived. It contained questions derived from alternate dimensions and forgotten ancient knowledge.",
                    durationSeconds = 6,
                    visualDescription = "Shocked face staring wide-eyed at paper"
                ),
                StoryScene(
                    sceneNumber = 3,
                    title = "Telepathic Connection",
                    caption = "Looking at best friend who also has no clue 👀",
                    voiceoverScript = "A silent glance across the desks confirmed it: neither had studied, and both accepted their shared comedic fate.",
                    durationSeconds = 6,
                    visualDescription = "Both friends shrugging comically"
                ),
                StoryScene(
                    sceneNumber = 4,
                    title = "Victory Regardless",
                    caption = "Iced coffee in hand: 'It is what it is' ✨",
                    voiceoverScript = "Because no matter what happens, a cold beverage and funny memes will restore honor to the day.",
                    durationSeconds = 6,
                    visualDescription = "Walking into the sunset holding coffee and smiling"
                )
            )
        }

        return AiStory(
            id = UUID.randomUUID().toString(),
            topic = topic,
            title = title,
            synopsis = "A hilarious comedy sketch about $topic",
            language = language,
            scenes = scenes
        )
    }

    // AI Content Assistant Engine
    suspend fun refineContentWithAssistant(
        content: String,
        actionType: String,
        language: String
    ): String = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        val hasValidKey = apiKey.isNotBlank() && apiKey != "MY_GEMINI_API_KEY"

        if (!hasValidKey) {
            return@withContext getOfflineAssistantRefinement(content, actionType, language)
        }

        try {
            val taskPrompt = when (actionType) {
                "Make it Funnier" -> "Make the following text significantly funnier, more savage and humorous: \"$content\""
                "Make it More Desi" -> "Rewrite the following text with relatable Pakistani/South Asian cultural humor, street slang, and desi tropes: \"$content\""
                "Make it Shorter" -> "Condense the following text into a very punchy, short one-liner: \"$content\""
                "Make it More Viral-style" -> "Turn the following text into high-engagement creator format suitable for Shorts/Reels: \"$content\""
                "Generate Hook" -> "Create an irresistible opening 3-second hook for social video based on: \"$content\""
                "Generate Caption" -> "Write a creator caption with emojis based on: \"$content\""
                "Generate Description" -> "Write a detailed 2-3 sentence video description for: \"$content\""
                "Generate Hashtags" -> "Generate 8-10 trending viral hashtags for: \"$content\""
                "Generate Title" -> "Generate 3 catchy clickable video titles for: \"$content\""
                else -> "Refine and polish the following content: \"$content\""
            }

            val prompt = """
                You are MemeForge AI Content Assistant.
                Target Language: $language
                Instruction: $taskPrompt
                Note: Do not make guarantees about virality. Return only the revised text directly.
            """.trimIndent()

            val contentsArray = JSONArray().put(
                JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt)))
            )
            val requestJson = JSONObject()
                .put("contents", contentsArray)
                .put("generationConfig", JSONObject().put("temperature", 0.85))

            val url = "$BASE_URL$MODEL_NAME:generateContent?key=$apiKey"
            val body = requestJson.toString().toRequestBody("application/json".toMediaType())
            val request = Request.Builder().url(url).post(body).build()

            val response = client.newCall(request).execute()
            val responseBody = response.body?.string() ?: ""

            val text = JSONObject(responseBody)
                .getJSONArray("candidates")
                .getJSONObject(0)
                .getJSONObject("content")
                .getJSONArray("parts")
                .getJSONObject(0)
                .getString("text")
                .trim()

            if (text.isNotBlank()) text else getOfflineAssistantRefinement(content, actionType, language)
        } catch (e: Exception) {
            getOfflineAssistantRefinement(content, actionType, language)
        }
    }

    private fun getOfflineAssistantRefinement(content: String, actionType: String, language: String): String {
        val base = if (content.isBlank()) "When life gives you memes" else content
        return when (actionType) {
            "Make it Funnier" -> "Bro thought $base was serious, until reality delivered the punchline 💀😂"
            "Make it More Desi" -> "Ammi ne kaha tha $base mat karo, ab bhugto biryani mein elaichi ki tarah! 🍛🔥"
            "Make it Shorter" -> "$base. No cap. 🧢"
            "Make it More Viral-style" -> "POV: You realize $base is 100% accurate in 2026 👀✨"
            "Generate Hook" -> "Stop scrolling! You won't believe what happened next with $base 🛑"
            "Generate Caption" -> "Tag that one friend who relates to $base a little too much 🤣👇"
            "Generate Description" -> "An unfiltered, hilarious take on $base. Like, comment, and share if this ever happened to you!"
            "Generate Hashtags" -> "#MemeForge #Relatable #ViralReels #DesiMemes #Humor #TrendingNow #ComedyGold"
            "Generate Title" -> "1. The Truth About $base\n2. Why $base Hits Different\n3. Nobody Warned Me About $base"
            else -> "Revised: $base (Refined with MemeForge AI)"
        }
    }

    // Auto Subtitle Phrase & Word Timing Generator
    fun generateAutoSubtitles(script: String, totalDurationSec: Float): List<com.example.data.model.SubtitleItem> {
        val cleaned = script.trim()
        if (cleaned.isBlank()) return emptyList()

        // Split by punctuation or chunks of 4-6 words
        val words = cleaned.split("\\s+".toRegex()).filter { it.isNotBlank() }
        if (words.isEmpty()) return emptyList()

        val wordsPerChunk = 4
        val chunks = words.chunked(wordsPerChunk)
        val chunkDuration = totalDurationSec / chunks.size.coerceAtLeast(1)

        val result = mutableListOf<com.example.data.model.SubtitleItem>()
        var currentStart = 0f

        for ((idx, chunkWords) in chunks.withIndex()) {
            val chunkEnd = (currentStart + chunkDuration).coerceAtMost(totalDurationSec)
            val chunkText = chunkWords.joinToString(" ")

            val wordDuration = (chunkEnd - currentStart) / chunkWords.size.coerceAtLeast(1)
            var wStart = currentStart
            val timedWords = chunkWords.map { w ->
                val wEnd = wStart + wordDuration
                val item = com.example.data.model.SubtitleWord(w, wStart, wEnd)
                wStart = wEnd
                item
            }

            result.add(
                com.example.data.model.SubtitleItem(
                    id = "sub_$idx",
                    text = chunkText,
                    startSec = currentStart,
                    endSec = chunkEnd,
                    words = timedWords
                )
            )
            currentStart = chunkEnd
        }

        return result
    }
}
