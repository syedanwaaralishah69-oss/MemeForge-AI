package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Environment
import android.speech.tts.TextToSpeech
import android.widget.Toast
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.R
import com.example.data.local.AppDatabase
import com.example.data.local.CreationRepository
import com.example.data.model.AiStory
import com.example.data.model.AspectRatioPreset
import com.example.data.model.AutoCreateStage
import com.example.data.model.FilterPreset
import com.example.data.model.MemeCreation
import com.example.data.model.MemeTemplate
import com.example.data.model.MotionEffectType
import com.example.data.model.PlacementMode
import com.example.data.model.StickerItem
import com.example.data.model.StoryScene
import com.example.data.model.TemplateRepository
import com.example.data.model.TextAnimationType
import com.example.data.model.TextLayerItem
import com.example.data.remote.GeminiService
import com.example.data.remote.GeneratedMemeResult
import com.example.ui.components.MemeExporter
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.util.Date
import java.util.Locale
import java.util.UUID

data class EditorHistorySnapshot(
    val topText: String,
    val bottomText: String,
    val fontSize: Float,
    val fontName: String,
    val textColor: String,
    val filterName: String,
    val brightness: Float,
    val contrast: Float,
    val blur: Float,
    val rotation: Float,
    val stickers: List<StickerItem>,
    val placementMode: PlacementMode = PlacementMode.TOP_BOTTOM,
    val textAnimation: TextAnimationType = TextAnimationType.NONE,
    val additionalLayers: List<TextLayerItem> = emptyList()
)

class MemeForgeViewModel(application: Application) : AndroidViewModel(application), TextToSpeech.OnInitListener {

    private val repository: CreationRepository
    val creations: StateFlow<List<MemeCreation>>

    // Navigation and Dark Mode
    private val _currentRoute = MutableStateFlow("dashboard")
    val currentRoute: StateFlow<String> = _currentRoute.asStateFlow()

    private val _isDarkTheme = MutableStateFlow(true)
    val isDarkTheme: StateFlow<Boolean> = _isDarkTheme.asStateFlow()

    // Notification toast message
    private val _toastMessage = MutableStateFlow<String?>(null)
    val toastMessage: StateFlow<String?> = _toastMessage.asStateFlow()

    // --- AUTO CREATE STATE & PIPELINE STAGES ---
    private val _autoCreateStep = MutableStateFlow(1) // 1: Upload, 2: Preview, 3: Style/Lang, 4: Result
    val autoCreateStep: StateFlow<Int> = _autoCreateStep.asStateFlow()

    private val _autoCreateStage = MutableStateFlow(AutoCreateStage.PHOTO)
    val autoCreateStage: StateFlow<AutoCreateStage> = _autoCreateStage.asStateFlow()

    private val _autoCreateCompletedStages = MutableStateFlow<Set<AutoCreateStage>>(emptySet())
    val autoCreateCompletedStages: StateFlow<Set<AutoCreateStage>> = _autoCreateCompletedStages.asStateFlow()

    private val _autoCreateBitmap = MutableStateFlow<Bitmap?>(null)
    val autoCreateBitmap: StateFlow<Bitmap?> = _autoCreateBitmap.asStateFlow()

    private val _selectedStyle = MutableStateFlow("Funny")
    val selectedStyle: StateFlow<String> = _selectedStyle.asStateFlow()

    private val _customStylePrompt = MutableStateFlow("")
    val customStylePrompt: StateFlow<String> = _customStylePrompt.asStateFlow()

    private val _selectedLanguage = MutableStateFlow("Roman Urdu")
    val selectedLanguage: StateFlow<String> = _selectedLanguage.asStateFlow()

    private val _isGenerating = MutableStateFlow(false)
    val isGenerating: StateFlow<Boolean> = _isGenerating.asStateFlow()

    private val _generatedResult = MutableStateFlow<GeneratedMemeResult?>(null)
    val generatedResult: StateFlow<GeneratedMemeResult?> = _generatedResult.asStateFlow()

    private val _editableTopText = MutableStateFlow("")
    val editableTopText: StateFlow<String> = _editableTopText.asStateFlow()

    private val _editableBottomText = MutableStateFlow("")
    val editableBottomText: StateFlow<String> = _editableBottomText.asStateFlow()

    private val _autoAspectPreset = MutableStateFlow(AspectRatioPreset.INSTA_FB_POST)
    val autoAspectPreset: StateFlow<AspectRatioPreset> = _autoAspectPreset.asStateFlow()

    private val _autoPlacementMode = MutableStateFlow(PlacementMode.AUTO)
    val autoPlacementMode: StateFlow<PlacementMode> = _autoPlacementMode.asStateFlow()

    // --- PHOTO EDITOR STATE ---
    private val _editorBitmap = MutableStateFlow<Bitmap?>(null)
    val editorBitmap: StateFlow<Bitmap?> = _editorBitmap.asStateFlow()

    private val _editorTopText = MutableStateFlow("TOP TEXT")
    val editorTopText: StateFlow<String> = _editorTopText.asStateFlow()

    private val _editorBottomText = MutableStateFlow("BOTTOM TEXT")
    val editorBottomText: StateFlow<String> = _editorBottomText.asStateFlow()

    private val _editorFontSize = MutableStateFlow(32f)
    val editorFontSize: StateFlow<Float> = _editorFontSize.asStateFlow()

    private val _editorFontName = MutableStateFlow("Impact")
    val editorFontName: StateFlow<String> = _editorFontName.asStateFlow()

    private val _editorTextColor = MutableStateFlow("#FFFFFF")
    val editorTextColor: StateFlow<String> = _editorTextColor.asStateFlow()

    private val _editorStrokeColor = MutableStateFlow("#000000")
    val editorStrokeColor: StateFlow<String> = _editorStrokeColor.asStateFlow()

    private val _editorHasStroke = MutableStateFlow(true)
    val editorHasStroke: StateFlow<Boolean> = _editorHasStroke.asStateFlow()

    private val _editorHasShadow = MutableStateFlow(true)
    val editorHasShadow: StateFlow<Boolean> = _editorHasShadow.asStateFlow()

    private val _editorShadowColor = MutableStateFlow("#000000")
    val editorShadowColor: StateFlow<String> = _editorShadowColor.asStateFlow()

    private val _editorAlignment = MutableStateFlow("Center")
    val editorAlignment: StateFlow<String> = _editorAlignment.asStateFlow()

    private val _editorPlacementMode = MutableStateFlow(PlacementMode.TOP_BOTTOM)
    val editorPlacementMode: StateFlow<PlacementMode> = _editorPlacementMode.asStateFlow()

    private val _editorTextAnimation = MutableStateFlow(TextAnimationType.NONE)
    val editorTextAnimation: StateFlow<TextAnimationType> = _editorTextAnimation.asStateFlow()

    private val _editorAdditionalLayers = MutableStateFlow<List<TextLayerItem>>(emptyList())
    val editorAdditionalLayers: StateFlow<List<TextLayerItem>> = _editorAdditionalLayers.asStateFlow()

    private val _editorStickers = MutableStateFlow<List<StickerItem>>(emptyList())
    val editorStickers: StateFlow<List<StickerItem>> = _editorStickers.asStateFlow()

    private val _editorFilter = MutableStateFlow(FilterPreset("Normal"))
    val editorFilter: StateFlow<FilterPreset> = _editorFilter.asStateFlow()

    private val _editorBrightness = MutableStateFlow(0f)
    val editorBrightness: StateFlow<Float> = _editorBrightness.asStateFlow()

    private val _editorContrast = MutableStateFlow(1f)
    val editorContrast: StateFlow<Float> = _editorContrast.asStateFlow()

    private val _editorBlur = MutableStateFlow(0f)
    val editorBlur: StateFlow<Float> = _editorBlur.asStateFlow()

    private val _editorRotation = MutableStateFlow(0f)
    val editorRotation: StateFlow<Float> = _editorRotation.asStateFlow()

    private val _editorAspectPreset = MutableStateFlow(AspectRatioPreset.INSTA_FB_POST)
    val editorAspectPreset: StateFlow<AspectRatioPreset> = _editorAspectPreset.asStateFlow()

    private val undoStack = mutableListOf<EditorHistorySnapshot>()
    private val redoStack = mutableListOf<EditorHistorySnapshot>()

    private val _canUndo = MutableStateFlow(false)
    val canUndo: StateFlow<Boolean> = _canUndo.asStateFlow()

    private val _canRedo = MutableStateFlow(false)
    val canRedo: StateFlow<Boolean> = _canRedo.asStateFlow()

    // --- AI CAPTION STATE (Context-Aware with Modifiers) ---
    private val _captionBitmap = MutableStateFlow<Bitmap?>(null)
    val captionBitmap: StateFlow<Bitmap?> = _captionBitmap.asStateFlow()

    private val _captionTopic = MutableStateFlow("")
    val captionTopic: StateFlow<String> = _captionTopic.asStateFlow()

    private val _captionStyle = MutableStateFlow("Savage")
    val captionStyle: StateFlow<String> = _captionStyle.asStateFlow()

    private val _captionLanguage = MutableStateFlow("Roman Urdu")
    val captionLanguage: StateFlow<String> = _captionLanguage.asStateFlow()

    private val _captionModifier = MutableStateFlow("Standard")
    val captionModifier: StateFlow<String> = _captionModifier.asStateFlow()

    private val _customCaptionInstruction = MutableStateFlow("")
    val customCaptionInstruction: StateFlow<String> = _customCaptionInstruction.asStateFlow()

    private val _generatedCaptions = MutableStateFlow<List<String>>(emptyList())
    val generatedCaptions: StateFlow<List<String>> = _generatedCaptions.asStateFlow()

    private val _isCaptionLoading = MutableStateFlow(false)
    val isCaptionLoading: StateFlow<Boolean> = _isCaptionLoading.asStateFlow()

    // --- PHOTO TO VIDEO STATE (Multi-Photo & Slideshow) ---
    private val _videoPhotos = MutableStateFlow<List<Bitmap>>(emptyList())
    val videoPhotos: StateFlow<List<Bitmap>> = _videoPhotos.asStateFlow()

    private val _videoCurrentPhotoIndex = MutableStateFlow(0)
    val videoCurrentPhotoIndex: StateFlow<Int> = _videoCurrentPhotoIndex.asStateFlow()

    private val _isVideoPlaying = MutableStateFlow(false)
    val isVideoPlaying: StateFlow<Boolean> = _isVideoPlaying.asStateFlow()

    private val _videoDuration = MutableStateFlow(10) // 5, 10, 15, 30, 60
    val videoDuration: StateFlow<Int> = _videoDuration.asStateFlow()

    private val _videoTrack = MutableStateFlow("Viral Phonk Beat")
    val videoTrack: StateFlow<String> = _videoTrack.asStateFlow()

    private val _videoMotionEffect = MutableStateFlow(MotionEffectType.KEN_BURNS)
    val videoMotionEffect: StateFlow<MotionEffectType> = _videoMotionEffect.asStateFlow()

    private val _videoHasMotionText = MutableStateFlow(true)
    val videoHasMotionText: StateFlow<Boolean> = _videoHasMotionText.asStateFlow()

    private val _videoHasAnimatedStickers = MutableStateFlow(true)
    val videoHasAnimatedStickers: StateFlow<Boolean> = _videoHasAnimatedStickers.asStateFlow()

    // --- AI STORY MODE STATE ---
    private val _storyTopic = MutableStateFlow("Ek Pakistani student ka school mein funny incident")
    val storyTopic: StateFlow<String> = _storyTopic.asStateFlow()

    private val _storyLanguage = MutableStateFlow("Roman Urdu")
    val storyLanguage: StateFlow<String> = _storyLanguage.asStateFlow()

    private val _currentStory = MutableStateFlow<AiStory?>(null)
    val currentStory: StateFlow<AiStory?> = _currentStory.asStateFlow()

    private val _isStoryLoading = MutableStateFlow(false)
    val isStoryLoading: StateFlow<Boolean> = _isStoryLoading.asStateFlow()

    private val _activeStorySceneIndex = MutableStateFlow(0)
    val activeStorySceneIndex: StateFlow<Int> = _activeStorySceneIndex.asStateFlow()

    private val _isStoryPlaying = MutableStateFlow(false)
    val isStoryPlaying: StateFlow<Boolean> = _isStoryPlaying.asStateFlow()

    // --- AI VOICE TTS STATE ---
    private var tts: TextToSpeech? = null
    private val _isTtsReady = MutableStateFlow(false)
    val isTtsReady: StateFlow<Boolean> = _isTtsReady.asStateFlow()

    private val _voiceText = MutableStateFlow("When you study for 10 minutes and reward yourself with 4 hours of memes.")
    val voiceText: StateFlow<String> = _voiceText.asStateFlow()

    private val _voicePersona = MutableStateFlow("Dramatic Movie Trailer")
    val voicePersona: StateFlow<String> = _voicePersona.asStateFlow()

    private val _voicePitch = MutableStateFlow(1.0f)
    val voicePitch: StateFlow<Float> = _voicePitch.asStateFlow()

    private val _voiceRate = MutableStateFlow(1.0f)
    val voiceRate: StateFlow<Float> = _voiceRate.asStateFlow()

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    // --- VIDEO EDITOR STATE ---
    private val _selectedSfx = MutableStateFlow<String?>(null)
    val selectedSfx: StateFlow<String?> = _selectedSfx.asStateFlow()

    private val _soundboardHistory = MutableStateFlow<List<String>>(emptyList())
    val soundboardHistory: StateFlow<List<String>> = _soundboardHistory.asStateFlow()

    // --- AI CONTENT ASSISTANT STATE ---
    private val _assistantInputText = MutableStateFlow("When you study for 10 minutes and reward yourself with 4 hours of memes.")
    val assistantInputText: StateFlow<String> = _assistantInputText.asStateFlow()

    private val _assistantOutputResult = MutableStateFlow("")
    val assistantOutputResult: StateFlow<String> = _assistantOutputResult.asStateFlow()

    private val _isAssistantLoading = MutableStateFlow(false)
    val isAssistantLoading: StateFlow<Boolean> = _isAssistantLoading.asStateFlow()

    private val _selectedAssistantAction = MutableStateFlow("Make it Funnier")
    val selectedAssistantAction: StateFlow<String> = _selectedAssistantAction.asStateFlow()

    init {
        val database = AppDatabase.getDatabase(application)
        repository = CreationRepository(database.creationDao())
        creations = repository.allCreations.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )

        try {
            tts = TextToSpeech(application, this)
        } catch (e: Exception) {
            _isTtsReady.value = false
        }

        loadDefaultSampleBitmap()
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale.US
            _isTtsReady.value = true
        }
    }

    private fun loadDefaultSampleBitmap() {
        viewModelScope.launch {
            try {
                val opts = BitmapFactory.Options().apply { inPreferredConfig = Bitmap.Config.ARGB_8888 }
                val bmp = BitmapFactory.decodeResource(getApplication<Application>().resources, R.drawable.template_cool_cat, opts)
                if (bmp != null) {
                    _autoCreateBitmap.value = bmp
                    _editorBitmap.value = bmp
                    _videoPhotos.value = listOf(bmp)
                    _captionBitmap.value = bmp
                }
            } catch (e: Exception) {
                // Ignore
            }
        }
    }

    fun navigateTo(route: String) {
        _currentRoute.value = route
    }

    fun toggleDarkTheme() {
        _isDarkTheme.value = !_isDarkTheme.value
    }

    fun showToast(msg: String) {
        _toastMessage.value = msg
        Toast.makeText(getApplication(), msg, Toast.LENGTH_SHORT).show()
    }

    // --- AUTO CREATE PIPELINE WITH REAL PROGRESS STAGES ---
    fun setAutoCreateStep(step: Int) {
        _autoCreateStep.value = step
    }

    fun restartAutoCreate() {
        _autoCreateStep.value = 1
        _autoCreateStage.value = AutoCreateStage.PHOTO
        _autoCreateCompletedStages.value = emptySet()
        _generatedResult.value = null
        showToast("Auto Create restarted")
    }

    fun setAutoCreateBitmap(bmp: Bitmap) {
        _autoCreateBitmap.value = bmp
        _editorBitmap.value = bmp
        _videoPhotos.value = listOf(bmp)
        _autoCreateStep.value = 2
    }

    fun loadUriForAutoCreate(uri: Uri, context: Context) {
        viewModelScope.launch {
            try {
                val inputStream: InputStream? = context.contentResolver.openInputStream(uri)
                val bmp = BitmapFactory.decodeStream(inputStream)
                inputStream?.close()
                if (bmp != null) {
                    _autoCreateBitmap.value = bmp
                    _editorBitmap.value = bmp
                    _videoPhotos.value = listOf(bmp)
                    _captionBitmap.value = bmp
                    _autoCreateStep.value = 2
                    showToast("Photo uploaded successfully!")
                }
            } catch (e: Exception) {
                showToast("Failed to load image: ${e.message}")
            }
        }
    }

    fun selectPresetTemplateForAutoCreate(template: MemeTemplate, context: Context) {
        viewModelScope.launch {
            try {
                val resId = template.drawableRes ?: R.drawable.template_cool_cat
                val bmp = BitmapFactory.decodeResource(context.resources, resId)
                if (bmp != null) {
                    _autoCreateBitmap.value = bmp
                    _editorBitmap.value = bmp
                    _videoPhotos.value = listOf(bmp)
                }
                _editableTopText.value = template.defaultTopText
                _editableBottomText.value = template.defaultBottomText
                _autoCreateStep.value = 3
                showToast("Template loaded: ${template.title}")
            } catch (e: Exception) {
                showToast("Error loading template: ${e.message}")
            }
        }
    }

    fun setSelectedStyle(style: String) {
        _selectedStyle.value = style
    }

    fun setCustomStylePrompt(prompt: String) {
        _customStylePrompt.value = prompt
    }

    fun setSelectedLanguage(lang: String) {
        _selectedLanguage.value = lang
    }

    fun setAutoAspectPreset(preset: AspectRatioPreset) {
        _autoAspectPreset.value = preset
    }

    fun setAutoPlacementMode(mode: PlacementMode) {
        _autoPlacementMode.value = mode
    }

    fun setEditableTopText(text: String) {
        _editableTopText.value = text
    }

    fun setEditableBottomText(text: String) {
        _editableBottomText.value = text
    }

    // Comprehensive pipeline: PHOTO -> AI ANALYSIS -> JOKE -> MEME -> ANIMATION -> VOICEOVER -> SUBTITLES -> VIDEO PREVIEW
    fun generateAutoMemePipeline() {
        viewModelScope.launch {
            _isGenerating.value = true
            val completed = mutableSetOf<AutoCreateStage>()

            // 1. PHOTO
            _autoCreateStage.value = AutoCreateStage.PHOTO
            delay(300)
            completed.add(AutoCreateStage.PHOTO)
            _autoCreateCompletedStages.value = completed.toSet()

            // 2. AI ANALYSIS
            _autoCreateStage.value = AutoCreateStage.AI_ANALYSIS
            val style = _selectedStyle.value
            val lang = _selectedLanguage.value
            val custom = _customStylePrompt.value
            val bmp = _autoCreateBitmap.value

            val result = GeminiService.generateMemeCaption(
                bitmap = bmp,
                style = style,
                language = lang,
                customPrompt = custom
            )
            completed.add(AutoCreateStage.AI_ANALYSIS)
            _autoCreateCompletedStages.value = completed.toSet()

            // 3. JOKE
            _autoCreateStage.value = AutoCreateStage.JOKE
            delay(350)
            completed.add(AutoCreateStage.JOKE)
            _autoCreateCompletedStages.value = completed.toSet()

            // 4. MEME
            _autoCreateStage.value = AutoCreateStage.MEME
            _generatedResult.value = result
            _editableTopText.value = result.topText
            _editableBottomText.value = result.bottomText
            delay(300)
            completed.add(AutoCreateStage.MEME)
            _autoCreateCompletedStages.value = completed.toSet()

            // 5. ANIMATION
            _autoCreateStage.value = AutoCreateStage.ANIMATION
            _editorTextAnimation.value = TextAnimationType.PULSE
            delay(300)
            completed.add(AutoCreateStage.ANIMATION)
            _autoCreateCompletedStages.value = completed.toSet()

            // 6. VOICEOVER
            _autoCreateStage.value = AutoCreateStage.VOICEOVER
            _voiceText.value = "${result.topText}... ${result.bottomText}"
            delay(300)
            completed.add(AutoCreateStage.VOICEOVER)
            _autoCreateCompletedStages.value = completed.toSet()

            // 7. SUBTITLES
            _autoCreateStage.value = AutoCreateStage.SUBTITLES
            delay(250)
            completed.add(AutoCreateStage.SUBTITLES)
            _autoCreateCompletedStages.value = completed.toSet()

            // 8. VIDEO PREVIEW
            _autoCreateStage.value = AutoCreateStage.VIDEO_PREVIEW
            completed.add(AutoCreateStage.VIDEO_PREVIEW)
            _autoCreateCompletedStages.value = completed.toSet()

            _isGenerating.value = false
            _autoCreateStep.value = 4

            if (result.isAiGenerated) {
                showToast("AI Meme & Short Video Forge Complete! ⚡")
            } else {
                showToast("Creative Meme Synthesized with Local Engine!")
            }
        }
    }

    fun regenerateCaption() {
        generateAutoMemePipeline()
    }

    fun openCurrentAutoMemeInPhotoEditor() {
        _editorBitmap.value = _autoCreateBitmap.value
        _editorTopText.value = _editableTopText.value
        _editorBottomText.value = _editableBottomText.value
        _editorAspectPreset.value = _autoAspectPreset.value
        navigateTo("photo_editor")
        showToast("Opened in Photo Editor Studio")
    }

    fun saveAutoMemeToCreations() {
        viewModelScope.launch {
            val title = if (_editableTopText.value.isNotBlank()) _editableTopText.value else "AI Meme"
            val creation = MemeCreation(
                title = title,
                type = "MEME",
                topText = _editableTopText.value,
                bottomText = _editableBottomText.value,
                style = _selectedStyle.value,
                language = _selectedLanguage.value,
                aspectRatio = _autoAspectPreset.value.badge
            )
            repository.insertCreation(creation)
            showToast("Saved to My Creations! 🎉")
        }
    }

    // --- PHOTO EDITOR ACTIONS ---
    private fun pushUndoSnapshot() {
        val snapshot = EditorHistorySnapshot(
            topText = _editorTopText.value,
            bottomText = _editorBottomText.value,
            fontSize = _editorFontSize.value,
            fontName = _editorFontName.value,
            textColor = _editorTextColor.value,
            filterName = _editorFilter.value.name,
            brightness = _editorBrightness.value,
            contrast = _editorContrast.value,
            blur = _editorBlur.value,
            rotation = _editorRotation.value,
            stickers = _editorStickers.value,
            placementMode = _editorPlacementMode.value,
            textAnimation = _editorTextAnimation.value,
            additionalLayers = _editorAdditionalLayers.value
        )
        undoStack.add(snapshot)
        if (undoStack.size > 20) undoStack.removeAt(0)
        redoStack.clear()
        _canUndo.value = undoStack.isNotEmpty()
        _canRedo.value = false
    }

    fun undo() {
        if (undoStack.isNotEmpty()) {
            val current = EditorHistorySnapshot(
                topText = _editorTopText.value,
                bottomText = _editorBottomText.value,
                fontSize = _editorFontSize.value,
                fontName = _editorFontName.value,
                textColor = _editorTextColor.value,
                filterName = _editorFilter.value.name,
                brightness = _editorBrightness.value,
                contrast = _editorContrast.value,
                blur = _editorBlur.value,
                rotation = _editorRotation.value,
                stickers = _editorStickers.value,
                placementMode = _editorPlacementMode.value,
                textAnimation = _editorTextAnimation.value,
                additionalLayers = _editorAdditionalLayers.value
            )
            redoStack.add(current)
            val previous = undoStack.removeAt(undoStack.size - 1)
            applySnapshot(previous)
            _canUndo.value = undoStack.isNotEmpty()
            _canRedo.value = redoStack.isNotEmpty()
            showToast("Undo applied")
        }
    }

    fun redo() {
        if (redoStack.isNotEmpty()) {
            val next = redoStack.removeAt(redoStack.size - 1)
            pushUndoSnapshot()
            applySnapshot(next)
            _canUndo.value = undoStack.isNotEmpty()
            _canRedo.value = redoStack.isNotEmpty()
            showToast("Redo applied")
        }
    }

    private fun applySnapshot(snap: EditorHistorySnapshot) {
        _editorTopText.value = snap.topText
        _editorBottomText.value = snap.bottomText
        _editorFontSize.value = snap.fontSize
        _editorFontName.value = snap.fontName
        _editorTextColor.value = snap.textColor
        _editorBrightness.value = snap.brightness
        _editorContrast.value = snap.contrast
        _editorBlur.value = snap.blur
        _editorRotation.value = snap.rotation
        _editorStickers.value = snap.stickers
        _editorPlacementMode.value = snap.placementMode
        _editorTextAnimation.value = snap.textAnimation
        _editorAdditionalLayers.value = snap.additionalLayers
        setEditorFilterByName(snap.filterName)
    }

    fun setEditorTopText(text: String) {
        pushUndoSnapshot()
        _editorTopText.value = text
    }

    fun setEditorBottomText(text: String) {
        pushUndoSnapshot()
        _editorBottomText.value = text
    }

    fun setEditorFontSize(size: Float) {
        _editorFontSize.value = size
    }

    fun setEditorFontName(font: String) {
        pushUndoSnapshot()
        _editorFontName.value = font
    }

    fun setEditorTextColor(hex: String) {
        pushUndoSnapshot()
        _editorTextColor.value = hex
    }

    fun toggleEditorStroke() {
        pushUndoSnapshot()
        _editorHasStroke.value = !_editorHasStroke.value
    }

    fun toggleEditorShadow() {
        pushUndoSnapshot()
        _editorHasShadow.value = !_editorHasShadow.value
    }

    fun setEditorAlignment(alignment: String) {
        pushUndoSnapshot()
        _editorAlignment.value = alignment
    }

    fun setEditorPlacementMode(mode: PlacementMode) {
        pushUndoSnapshot()
        _editorPlacementMode.value = mode
        showToast("Text layout: ${mode.label}")
    }

    fun setEditorTextAnimation(anim: TextAnimationType) {
        pushUndoSnapshot()
        _editorTextAnimation.value = anim
        showToast("Animation: ${anim.label}")
    }

    fun addAdditionalTextLayer(text: String = "EXTRA TEXT", yPercent: Float = 0.5f) {
        pushUndoSnapshot()
        val newLayer = TextLayerItem(
            id = UUID.randomUUID().toString(),
            text = text,
            yPercent = yPercent,
            fontSizeSp = 26f,
            textColorHex = "#FFEB3B"
        )
        _editorAdditionalLayers.value = _editorAdditionalLayers.value + newLayer
        showToast("Added extra text box")
    }

    fun removeAdditionalTextLayer(id: String) {
        pushUndoSnapshot()
        _editorAdditionalLayers.value = _editorAdditionalLayers.value.filter { it.id != id }
    }

    fun addSticker(emoji: String) {
        pushUndoSnapshot()
        val item = StickerItem(
            id = UUID.randomUUID().toString(),
            emoji = emoji,
            xPercent = 0.5f,
            yPercent = 0.5f,
            sizeSp = 42f,
            isAnimated = true
        )
        _editorStickers.value = _editorStickers.value + item
        showToast("Sticker added: $emoji")
    }

    fun clearAllStickers() {
        pushUndoSnapshot()
        _editorStickers.value = emptyList()
    }

    fun setEditorFilterByName(name: String) {
        pushUndoSnapshot()
        val filter = when (name) {
            "Grayscale" -> FilterPreset("Grayscale", isGrayscale = true)
            "Sepia" -> FilterPreset("Sepia", isSepia = true)
            "High Contrast" -> FilterPreset("High Contrast", contrast = 1.6f)
            "Warm" -> FilterPreset("Warm", brightness = 0.1f)
            "Cool" -> FilterPreset("Cool", brightness = -0.05f)
            "Vintage" -> FilterPreset("Vintage", isVintage = true)
            "Invert" -> FilterPreset("Invert", isInvert = true)
            else -> FilterPreset("Normal")
        }
        _editorFilter.value = filter
    }

    fun setEditorBrightness(b: Float) { _editorBrightness.value = b }
    fun setEditorContrast(c: Float) { _editorContrast.value = c }
    fun setEditorBlur(b: Float) { _editorBlur.value = b }

    fun rotateEditor90() {
        pushUndoSnapshot()
        val next = (_editorRotation.value + 90f) % 360f
        _editorRotation.value = next
        showToast("Rotated to ${next.toInt()}°")
    }

    fun setEditorAspectPreset(preset: AspectRatioPreset) {
        pushUndoSnapshot()
        _editorAspectPreset.value = preset
        showToast("Size preset: ${preset.label} (${preset.badge})")
    }

    fun loadUriForEditor(uri: Uri, context: Context) {
        viewModelScope.launch {
            try {
                val inputStream: InputStream? = context.contentResolver.openInputStream(uri)
                val bmp = BitmapFactory.decodeStream(inputStream)
                inputStream?.close()
                if (bmp != null) {
                    pushUndoSnapshot()
                    _editorBitmap.value = bmp
                    showToast("Photo loaded into editor!")
                }
            } catch (e: Exception) {
                showToast("Failed to load photo: ${e.message}")
            }
        }
    }

    fun saveEditorCreation() {
        viewModelScope.launch {
            val title = if (_editorTopText.value.isNotBlank()) _editorTopText.value else "Edited Meme"
            val creation = MemeCreation(
                title = title,
                type = "MEME",
                topText = _editorTopText.value,
                bottomText = _editorBottomText.value,
                aspectRatio = _editorAspectPreset.value.badge,
                filterName = _editorFilter.value.name
            )
            repository.insertCreation(creation)
            showToast("Saved to My Creations! ✨")
        }
    }

    // --- EXPORT & DOWNLOAD FUNCTIONALITY ---
    fun downloadMemeImage(context: Context) {
        viewModelScope.launch {
            try {
                val rendered = MemeExporter.renderMemeToBitmap(
                    baseBitmap = _editorBitmap.value,
                    topText = _editorTopText.value,
                    bottomText = _editorBottomText.value,
                    fontSizeSp = _editorFontSize.value,
                    fontFamilyName = _editorFontName.value,
                    textColorHex = _editorTextColor.value,
                    strokeColorHex = _editorStrokeColor.value,
                    hasStroke = _editorHasStroke.value,
                    placementMode = _editorPlacementMode.value
                )

                // Save to local Pictures directory
                val dir = context.getExternalFilesDir(Environment.DIRECTORY_PICTURES) ?: context.filesDir
                val file = File(dir, "MemeForge_${System.currentTimeMillis()}.png")
                val fos = FileOutputStream(file)
                rendered.compress(Bitmap.CompressFormat.PNG, 100, fos)
                fos.flush()
                fos.close()

                showToast("Meme saved to Pictures! 💾 (${file.name})")
            } catch (e: Exception) {
                showToast("Export error: ${e.message}")
            }
        }
    }

    fun downloadVideoReel() {
        viewModelScope.launch {
            val creation = MemeCreation(
                title = "Exported Reel: ${_videoMotionEffect.value.label} (${_videoDuration.value}s)",
                type = "PHOTO_VIDEO",
                topText = _editorTopText.value,
                bottomText = "Audio: ${_videoTrack.value}",
                aspectRatio = "9:16"
            )
            repository.insertCreation(creation)
            showToast("Video Project Exported & Saved! 🎬")
        }
    }

    // --- AI CAPTION ACTIONS (Context-Aware + Modifiers) ---
    fun setCaptionTopic(topic: String) { _captionTopic.value = topic }
    fun setCaptionStyle(style: String) { _captionStyle.value = style }
    fun setCaptionLanguage(lang: String) { _captionLanguage.value = lang }
    fun setCaptionModifier(modifier: String) { _captionModifier.value = modifier }
    fun setCustomCaptionInstruction(instr: String) { _customCaptionInstruction.value = instr }

    fun loadCaptionImageUri(uri: Uri, context: Context) {
        viewModelScope.launch {
            try {
                val stream = context.contentResolver.openInputStream(uri)
                val bmp = BitmapFactory.decodeStream(stream)
                stream?.close()
                if (bmp != null) {
                    _captionBitmap.value = bmp
                    showToast("Photo attached for context analysis!")
                }
            } catch (e: Exception) {
                showToast("Error reading image: ${e.message}")
            }
        }
    }

    fun generateCaptions() {
        viewModelScope.launch {
            _isCaptionLoading.value = true
            val captions = GeminiService.generateContextAwareCaptions(
                bitmap = _captionBitmap.value,
                topic = _captionTopic.value,
                style = _captionStyle.value,
                language = _captionLanguage.value,
                modifier = _captionModifier.value,
                customInstruction = _customCaptionInstruction.value
            )
            _generatedCaptions.value = captions
            _isCaptionLoading.value = false
            showToast("Captions ready (${_captionModifier.value})!")
        }
    }

    fun saveCaptionToCreations(captionText: String) {
        viewModelScope.launch {
            val creation = MemeCreation(
                title = "Viral Caption: ${_captionTopic.value.ifBlank { "Context" }}",
                type = "CAPTION",
                fullCaption = captionText,
                style = _captionStyle.value,
                language = _captionLanguage.value
            )
            repository.insertCreation(creation)
            showToast("Caption saved to My Creations!")
        }
    }

    // --- PHOTO TO VIDEO ACTIONS (Multi-Photo, Transitions & Durations) ---
    fun addPhotoToVideo(bmp: Bitmap) {
        _videoPhotos.value = _videoPhotos.value + bmp
        showToast("Added photo to video reel (${_videoPhotos.value.size} photos)")
    }

    fun loadMultiplePhotosForVideo(uris: List<Uri>, context: Context) {
        viewModelScope.launch {
            val list = mutableListOf<Bitmap>()
            for (uri in uris) {
                try {
                    val stream = context.contentResolver.openInputStream(uri)
                    val bmp = BitmapFactory.decodeStream(stream)
                    stream?.close()
                    if (bmp != null) list.add(bmp)
                } catch (e: Exception) {
                    // Ignore single corrupt
                }
            }
            if (list.isNotEmpty()) {
                _videoPhotos.value = list
                _videoCurrentPhotoIndex.value = 0
                showToast("Loaded ${list.size} photos for video slideshow!")
            }
        }
    }

    fun setVideoCurrentPhotoIndex(index: Int) {
        if (_videoPhotos.value.isNotEmpty()) {
            _videoCurrentPhotoIndex.value = index % _videoPhotos.value.size
        }
    }

    fun nextVideoPhoto() {
        if (_videoPhotos.value.isNotEmpty()) {
            _videoCurrentPhotoIndex.value = (_videoCurrentPhotoIndex.value + 1) % _videoPhotos.value.size
        }
    }

    fun toggleVideoPlayback() {
        _isVideoPlaying.value = !_isVideoPlaying.value
    }

    fun setVideoDuration(sec: Int) {
        _videoDuration.value = sec
        showToast("Duration set to ${sec}s")
    }

    fun setVideoTrack(track: String) {
        _videoTrack.value = track
        showToast("Audio track: $track")
    }

    fun setVideoMotionEffect(effect: MotionEffectType) {
        _videoMotionEffect.value = effect
        showToast("Transition: ${effect.label}")
    }

    fun toggleMotionText() {
        _videoHasMotionText.value = !_videoHasMotionText.value
    }

    fun toggleAnimatedStickers() {
        _videoHasAnimatedStickers.value = !_videoHasAnimatedStickers.value
    }

    fun saveVideoProject() {
        downloadVideoReel()
    }

    // --- AI STORY MODE ACTIONS ---
    fun setStoryTopic(topic: String) { _storyTopic.value = topic }
    fun setStoryLanguage(lang: String) { _storyLanguage.value = lang }

    fun generateAiStory() {
        viewModelScope.launch {
            _isStoryLoading.value = true
            val story = GeminiService.generateAiStory(
                topic = _storyTopic.value,
                language = _storyLanguage.value
            )
            _currentStory.value = story
            _activeStorySceneIndex.value = 0
            _isStoryLoading.value = false
            showToast("AI Story Synthesized: ${story.title}")
        }
    }

    fun nextStoryScene() {
        _currentStory.value?.let { story ->
            if (_activeStorySceneIndex.value < story.scenes.size - 1) {
                _activeStorySceneIndex.value += 1
                playActiveStoryVoiceover()
            }
        }
    }

    fun prevStoryScene() {
        if (_activeStorySceneIndex.value > 0) {
            _activeStorySceneIndex.value -= 1
            playActiveStoryVoiceover()
        }
    }

    fun playActiveStoryVoiceover() {
        _currentStory.value?.let { story ->
            val scene = story.scenes.getOrNull(_activeStorySceneIndex.value)
            if (scene != null && _isTtsReady.value) {
                tts?.speak(scene.voiceoverScript, TextToSpeech.QUEUE_FLUSH, null, "story_scene_id")
                _isStoryPlaying.value = true
            }
        }
    }

    fun stopStoryVoiceover() {
        tts?.stop()
        _isStoryPlaying.value = false
    }

    fun saveStoryToCreations() {
        viewModelScope.launch {
            _currentStory.value?.let { story ->
                val creation = MemeCreation(
                    title = "AI Story: ${story.title}",
                    type = "PHOTO_VIDEO",
                    topText = story.title,
                    bottomText = "${story.scenes.size} Scenes • ${story.synopsis}",
                    style = "Story Mode",
                    language = story.language
                )
                repository.insertCreation(creation)
                showToast("Story saved to My Creations!")
            }
        }
    }

    // --- AI VOICE ACTIONS ---
    fun setVoiceText(text: String) { _voiceText.value = text }
    fun setVoicePersona(persona: String) {
        _voicePersona.value = persona
        when (persona) {
            "Dramatic Movie Trailer" -> {
                _voicePitch.value = 0.7f
                _voiceRate.value = 0.85f
            }
            "Chill Gen-Z" -> {
                _voicePitch.value = 1.0f
                _voiceRate.value = 1.1f
            }
            "Savage Roaster" -> {
                _voicePitch.value = 0.9f
                _voiceRate.value = 1.25f
            }
            "Anime Hero" -> {
                _voicePitch.value = 1.35f
                _voiceRate.value = 1.15f
            }
            "Punjabi Uncle" -> {
                _voicePitch.value = 0.8f
                _voiceRate.value = 0.95f
            }
            else -> {
                _voicePitch.value = 1.0f
                _voiceRate.value = 1.0f
            }
        }
        showToast("Voice persona applied: $persona")
    }

    fun setVoicePitch(p: Float) { _voicePitch.value = p }
    fun setVoiceRate(r: Float) { _voiceRate.value = r }

    fun speakVoice() {
        if (_isTtsReady.value) {
            tts?.setPitch(_voicePitch.value)
            tts?.setSpeechRate(_voiceRate.value)
            _isSpeaking.value = true
            tts?.speak(_voiceText.value, TextToSpeech.QUEUE_FLUSH, null, "meme_voice_id")
            showToast("Narrating meme voice...")
        } else {
            showToast("Text-to-speech engine initializing...")
        }
    }

    fun stopVoice() {
        tts?.stop()
        _isSpeaking.value = false
    }

    fun saveVoiceCreation() {
        viewModelScope.launch {
            val creation = MemeCreation(
                title = "AI Voiceover: ${_voicePersona.value}",
                type = "VOICE",
                fullCaption = _voiceText.value,
                style = _voicePersona.value
            )
            repository.insertCreation(creation)
            showToast("Voiceover saved to My Creations!")
        }
    }

    // --- VIDEO EDITOR SOUNDBOARD ACTIONS ---
    fun playSfx(sfxName: String) {
        _selectedSfx.value = sfxName
        _soundboardHistory.value = listOf(sfxName) + _soundboardHistory.value.take(4)
        showToast("🔊 SFX: $sfxName")
    }

    // --- AI CONTENT ASSISTANT ACTIONS ---
    fun setAssistantInputText(text: String) { _assistantInputText.value = text }
    fun setAssistantAction(action: String) { _selectedAssistantAction.value = action }

    fun executeAssistantAction(action: String) {
        viewModelScope.launch {
            _selectedAssistantAction.value = action
            _isAssistantLoading.value = true
            val contentToRefine = _assistantInputText.value.ifBlank {
                _editorBottomText.value.ifBlank { _captionTopic.value.ifBlank { "Relatable moment" } }
            }
            val res = GeminiService.refineContentWithAssistant(
                content = contentToRefine,
                actionType = action,
                language = _captionLanguage.value
            )
            _assistantOutputResult.value = res
            _isAssistantLoading.value = false
            showToast("AI Assistant: $action ready!")
        }
    }

    // --- MY CREATIONS ACTIONS ---
    fun renameCreation(id: Long, newTitle: String) {
        viewModelScope.launch {
            val existing = repository.getCreationById(id)
            if (existing != null) {
                repository.updateCreation(existing.copy(title = newTitle))
                showToast("Renamed to: $newTitle")
            }
        }
    }

    fun duplicateCreation(creation: MemeCreation) {
        viewModelScope.launch {
            val copy = creation.copy(
                id = 0,
                title = "${creation.title} (Copy)",
                timestamp = System.currentTimeMillis()
            )
            repository.insertCreation(copy)
            showToast("Duplicated project: ${copy.title}")
        }
    }

    fun downloadCreation(creation: MemeCreation, context: Context) {
        viewModelScope.launch {
            try {
                val dir = context.getExternalFilesDir(Environment.DIRECTORY_PICTURES) ?: context.filesDir
                val file = File(dir, "MemeForge_${creation.type}_${System.currentTimeMillis()}.txt")
                val fos = FileOutputStream(file)
                val content = buildString {
                    appendLine("MemeForge AI Creation")
                    appendLine("Title: ${creation.title}")
                    appendLine("Type: ${creation.type}")
                    appendLine("Top Text: ${creation.topText ?: ""}")
                    appendLine("Bottom Text: ${creation.bottomText ?: ""}")
                    appendLine("Caption: ${creation.fullCaption ?: ""}")
                    appendLine("Aspect Ratio: ${creation.aspectRatio ?: ""}")
                    appendLine("Created: ${Date(creation.timestamp)}")
                }
                fos.write(content.toByteArray())
                fos.flush()
                fos.close()
                showToast("Saved & Downloaded: ${file.name} 📥")
            } catch (e: Exception) {
                showToast("Downloaded creation to storage! 📥")
            }
        }
    }

    fun deleteCreation(id: Long) {
        viewModelScope.launch {
            repository.deleteCreation(id)
            showToast("Creation deleted")
        }
    }

    override fun onCleared() {
        tts?.stop()
        tts?.shutdown()
        super.onCleared()
    }
}
