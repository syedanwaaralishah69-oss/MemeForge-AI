package com.example.ui.components

import android.content.Context
import android.graphics.Bitmap
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.RectF
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.model.AspectRatioPreset
import com.example.data.model.FilterPreset
import com.example.data.model.MotionEffectType
import com.example.data.model.PlacementMode
import com.example.data.model.StickerItem
import com.example.data.model.TextAnimationType
import com.example.data.model.TextLayerItem
import kotlin.math.sin

@Composable
fun MemeCanvasView(
    bitmap: Bitmap?,
    topText: String = "",
    bottomText: String = "",
    fontSizeSp: Float = 30f,
    fontFamilyName: String = "Impact",
    textColorHex: String = "#FFFFFF",
    strokeColorHex: String = "#000000",
    hasStroke: Boolean = true,
    hasShadow: Boolean = true,
    shadowColorHex: String = "#000000",
    textAlignment: String = "Center",
    placementMode: PlacementMode = PlacementMode.TOP_BOTTOM,
    textAnimation: TextAnimationType = TextAnimationType.NONE,
    additionalTextLayers: List<TextLayerItem> = emptyList(),
    filter: FilterPreset = FilterPreset("Normal"),
    brightness: Float = 0f,
    contrast: Float = 1f,
    rotationDeg: Float = 0f,
    aspectPreset: AspectRatioPreset = AspectRatioPreset.INSTA_FB_POST,
    stickers: List<StickerItem> = emptyList(),
    motionEffect: MotionEffectType = MotionEffectType.KEN_BURNS,
    isMotionActive: Boolean = false,
    modifier: Modifier = Modifier
) {
    val ratio = aspectPreset.ratioWidth / aspectPreset.ratioHeight

    // Motion animation transition for animated video preview
    val infiniteTransition = rememberInfiniteTransition(label = "canvas_anim")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = 1.06f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )

    val shakeOffset by infiniteTransition.animateFloat(
        initialValue = -6f,
        targetValue = 6f,
        animationSpec = infiniteRepeatable(
            animation = tween(120, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "shake_offset"
    )

    val motionZoom by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = 1.18f,
        animationSpec = infiniteRepeatable(
            animation = tween(4000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "motion_zoom"
    )

    val motionPan by infiniteTransition.animateFloat(
        initialValue = -15f,
        targetValue = 15f,
        animationSpec = infiniteRepeatable(
            animation = tween(5000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "motion_pan"
    )

    val effectiveScale = when {
        isMotionActive && motionEffect == MotionEffectType.KEN_BURNS -> motionZoom
        isMotionActive && motionEffect == MotionEffectType.ZOOM_IN_OUT -> motionZoom
        isMotionActive && motionEffect == MotionEffectType.BOUNCE -> pulseScale
        textAnimation == TextAnimationType.PULSE -> pulseScale
        textAnimation == TextAnimationType.POP_IN -> pulseScale
        else -> 1.0f
    }

    val effectiveShake = when {
        isMotionActive && motionEffect == MotionEffectType.SHAKE -> shakeOffset
        textAnimation == TextAnimationType.SHAKE -> shakeOffset
        else -> 0f
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .aspectRatio(ratio)
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFF0F0C1E))
            .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
            .testTag("meme_canvas_view"),
        contentAlignment = Alignment.Center
    ) {
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .scale(effectiveScale)
                .rotate(rotationDeg)
        ) {
            val canvasWidth = size.width
            val canvasHeight = size.height
            if (canvasWidth <= 0 || canvasHeight <= 0) return@Canvas

            // 1. Draw base photo if available
            bitmap?.let { bmp ->
                val srcWidth = bmp.width
                val srcHeight = bmp.height

                val scaleX = canvasWidth / srcWidth
                val scaleY = canvasHeight / srcHeight
                val baseScale = maxOf(scaleX, scaleY)

                val scaledWidth = srcWidth * baseScale
                val scaledHeight = srcHeight * baseScale
                val panOffset = if (isMotionActive && motionEffect == MotionEffectType.PAN) motionPan else 0f
                val left = ((canvasWidth - scaledWidth) / 2f) + panOffset
                val top = (canvasHeight - scaledHeight) / 2f

                drawIntoCanvas { canvas ->
                    val nativePaint = Paint().apply {
                        isAntiAlias = true
                        isFilterBitmap = true

                        val cm = ColorMatrix()
                        if (filter.isGrayscale) {
                            cm.setSaturation(0f)
                        } else if (filter.isSepia) {
                            cm.set(floatArrayOf(
                                0.393f, 0.769f, 0.189f, 0f, 0f,
                                0.349f, 0.686f, 0.168f, 0f, 0f,
                                0.272f, 0.534f, 0.131f, 0f, 0f,
                                0f, 0f, 0f, 1f, 0f
                            ))
                        } else if (filter.isInvert) {
                            cm.set(floatArrayOf(
                                -1f, 0f, 0f, 0f, 255f,
                                0f, -1f, 0f, 0f, 255f,
                                0f, 0f, -1f, 0f, 255f,
                                0f, 0f, 0f, 1f, 0f
                            ))
                        } else if (filter.isVintage) {
                            cm.set(floatArrayOf(
                                0.9f, 0f, 0f, 0f, 30f,
                                0f, 0.8f, 0f, 0f, 20f,
                                0f, 0f, 0.6f, 0f, 10f,
                                0f, 0f, 0f, 1f, 0f
                            ))
                        }

                        val totalContrast = contrast * filter.contrast
                        val totalBrightness = (brightness + filter.brightness) * 128f
                        if (totalContrast != 1f || totalBrightness != 0f) {
                            val adjCm = ColorMatrix(floatArrayOf(
                                totalContrast, 0f, 0f, 0f, totalBrightness,
                                0f, totalContrast, 0f, 0f, totalBrightness,
                                0f, 0f, totalContrast, 0f, totalBrightness,
                                0f, 0f, 0f, 1f, 0f
                            ))
                            cm.postConcat(adjCm)
                        }

                        colorFilter = ColorMatrixColorFilter(cm)
                    }

                    canvas.nativeCanvas.drawBitmap(
                        bmp,
                        android.graphics.Rect(0, 0, srcWidth, srcHeight),
                        RectF(left, top, left + scaledWidth, top + scaledHeight),
                        nativePaint
                    )
                }
            }

            // 2. Center Card Overlay if placement mode is CENTER_CARD
            if (placementMode == PlacementMode.CENTER_CARD && (topText.isNotBlank() || bottomText.isNotBlank())) {
                drawIntoCanvas { canvas ->
                    val density = canvasWidth / 360f
                    val cardPaint = Paint().apply {
                        isAntiAlias = true
                        color = android.graphics.Color.argb(200, 16, 12, 36)
                        style = Paint.Style.FILL
                    }
                    val borderPaint = Paint().apply {
                        isAntiAlias = true
                        color = android.graphics.Color.argb(180, 168, 85, 247)
                        strokeWidth = 2f * density
                        style = Paint.Style.STROKE
                    }
                    val cardRect = RectF(
                        canvasWidth * 0.08f,
                        canvasHeight * 0.32f,
                        canvasWidth * 0.92f,
                        canvasHeight * 0.68f
                    )
                    canvas.nativeCanvas.drawRoundRect(cardRect, 16f * density, 16f * density, cardPaint)
                    canvas.nativeCanvas.drawRoundRect(cardRect, 16f * density, 16f * density, borderPaint)
                }
            }

            // 3. Draw Meme Text (Top, Bottom, Center, Additional Layers)
            drawIntoCanvas { canvas ->
                val density = canvasWidth / 360f
                val effectiveTextSize = fontSizeSp * density

                val tf = when (fontFamilyName) {
                    "Monospace" -> android.graphics.Typeface.MONOSPACE
                    "Serif" -> android.graphics.Typeface.SERIF
                    "Cursive" -> android.graphics.Typeface.create("cursive", android.graphics.Typeface.BOLD)
                    "Sans-Serif" -> android.graphics.Typeface.DEFAULT_BOLD
                    else -> android.graphics.Typeface.create("Impact", android.graphics.Typeface.BOLD)
                }

                val strokePaint = Paint().apply {
                    isAntiAlias = true
                    textSize = effectiveTextSize
                    typeface = tf
                    style = Paint.Style.STROKE
                    strokeWidth = effectiveTextSize * 0.16f
                    color = try {
                        android.graphics.Color.parseColor(strokeColorHex)
                    } catch (e: Exception) {
                        android.graphics.Color.BLACK
                    }
                    textAlign = when (textAlignment) {
                        "Left" -> Paint.Align.LEFT
                        "Right" -> Paint.Align.RIGHT
                        else -> Paint.Align.CENTER
                    }
                }

                val fillPaint = Paint().apply {
                    isAntiAlias = true
                    textSize = effectiveTextSize
                    typeface = tf
                    style = Paint.Style.FILL
                    color = try {
                        android.graphics.Color.parseColor(textColorHex)
                    } catch (e: Exception) {
                        android.graphics.Color.WHITE
                    }
                    if (hasShadow) {
                        val sCol = try {
                            android.graphics.Color.parseColor(shadowColorHex)
                        } catch (e: Exception) {
                            android.graphics.Color.BLACK
                        }
                        val glowMultiplier = if (textAnimation == TextAnimationType.GLOW) 18f else 6f
                        setShadowLayer(glowMultiplier * density, 2f * density, 2f * density, sCol)
                    }
                    textAlign = when (textAlignment) {
                        "Left" -> Paint.Align.LEFT
                        "Right" -> Paint.Align.RIGHT
                        else -> Paint.Align.CENTER
                    }
                }

                val textX = (when (textAlignment) {
                    "Left" -> 24f * density
                    "Right" -> canvasWidth - (24f * density)
                    else -> canvasWidth / 2f
                }) + effectiveShake

                when (placementMode) {
                    PlacementMode.CENTER_CARD -> {
                        var centerY = canvasHeight * 0.44f
                        if (topText.isNotBlank()) {
                            val topLines = splitTextIntoLines(topText, canvasWidth * 0.78f, fillPaint)
                            for (line in topLines) {
                                if (hasStroke) canvas.nativeCanvas.drawText(line, textX, centerY, strokePaint)
                                canvas.nativeCanvas.drawText(line, textX, centerY, fillPaint)
                                centerY += effectiveTextSize * 1.15f
                            }
                        }
                        if (bottomText.isNotBlank()) {
                            val bottomLines = splitTextIntoLines(bottomText, canvasWidth * 0.78f, fillPaint)
                            for (line in bottomLines) {
                                if (hasStroke) canvas.nativeCanvas.drawText(line, textX, centerY, strokePaint)
                                canvas.nativeCanvas.drawText(line, textX, centerY, fillPaint)
                                centerY += effectiveTextSize * 1.15f
                            }
                        }
                    }
                    PlacementMode.TOP_ONLY -> {
                        if (topText.isNotBlank()) {
                            val lines = splitTextIntoLines(topText, canvasWidth * 0.9f, fillPaint)
                            var currentY = 50f * density
                            for (line in lines) {
                                if (hasStroke) canvas.nativeCanvas.drawText(line, textX, currentY, strokePaint)
                                canvas.nativeCanvas.drawText(line, textX, currentY, fillPaint)
                                currentY += effectiveTextSize * 1.15f
                            }
                        }
                    }
                    PlacementMode.BOTTOM_ONLY -> {
                        if (bottomText.isNotBlank()) {
                            val lines = splitTextIntoLines(bottomText, canvasWidth * 0.9f, fillPaint)
                            var startY = canvasHeight - (28f * density) - ((lines.size - 1) * effectiveTextSize * 1.15f)
                            for (line in lines) {
                                if (hasStroke) canvas.nativeCanvas.drawText(line, textX, startY, strokePaint)
                                canvas.nativeCanvas.drawText(line, textX, startY, fillPaint)
                                startY += effectiveTextSize * 1.15f
                            }
                        }
                    }
                    else -> { // AUTO or TOP_BOTTOM
                        if (topText.isNotBlank()) {
                            val topLines = splitTextIntoLines(topText, canvasWidth * 0.9f, fillPaint)
                            var currentY = 48f * density
                            for (line in topLines) {
                                if (hasStroke) canvas.nativeCanvas.drawText(line, textX, currentY, strokePaint)
                                canvas.nativeCanvas.drawText(line, textX, currentY, fillPaint)
                                currentY += effectiveTextSize * 1.15f
                            }
                        }

                        if (bottomText.isNotBlank()) {
                            val bottomLines = splitTextIntoLines(bottomText, canvasWidth * 0.9f, fillPaint)
                            var startY = canvasHeight - (28f * density) - ((bottomLines.size - 1) * effectiveTextSize * 1.15f)
                            for (line in bottomLines) {
                                if (hasStroke) canvas.nativeCanvas.drawText(line, textX, startY, strokePaint)
                                canvas.nativeCanvas.drawText(line, textX, startY, fillPaint)
                                startY += effectiveTextSize * 1.15f
                            }
                        }
                    }
                }

                // Render Additional Multiple Text Boxes
                for (layer in additionalTextLayers) {
                    val layerPaint = Paint(fillPaint).apply {
                        textSize = layer.fontSizeSp * density
                        color = try {
                            android.graphics.Color.parseColor(layer.textColorHex)
                        } catch (e: Exception) {
                            android.graphics.Color.WHITE
                        }
                    }
                    val layerStroke = Paint(strokePaint).apply {
                        textSize = layer.fontSizeSp * density
                        color = try {
                            android.graphics.Color.parseColor(layer.strokeColorHex)
                        } catch (e: Exception) {
                            android.graphics.Color.BLACK
                        }
                    }
                    val ly = layer.yPercent * canvasHeight
                    if (layer.hasStroke) canvas.nativeCanvas.drawText(layer.text, textX, ly, layerStroke)
                    canvas.nativeCanvas.drawText(layer.text, textX, ly, layerPaint)
                }

                // Draw Stickers & Emojis
                val emojiPaint = Paint().apply {
                    isAntiAlias = true
                    style = Paint.Style.FILL
                }
                for (sticker in stickers) {
                    val sScale = if (sticker.isAnimated) pulseScale else 1f
                    emojiPaint.textSize = sticker.sizeSp * density * sScale
                    val sx = sticker.xPercent * canvasWidth
                    val sy = sticker.yPercent * canvasHeight
                    canvas.nativeCanvas.drawText(sticker.emoji, sx, sy, emojiPaint)
                }
            }
        }
    }
}

private fun splitTextIntoLines(text: String, maxWidth: Float, paint: Paint): List<String> {
    val words = text.split(" ")
    val lines = mutableListOf<String>()
    var currentLine = StringBuilder()

    for (word in words) {
        val testLine = if (currentLine.isEmpty()) word else "$currentLine $word"
        val measured = paint.measureText(testLine)
        if (measured > maxWidth && currentLine.isNotEmpty()) {
            lines.add(currentLine.toString())
            currentLine = StringBuilder(word)
        } else {
            currentLine = StringBuilder(testLine)
        }
    }
    if (currentLine.isNotEmpty()) {
        lines.add(currentLine.toString())
    }
    return lines
}

// Utility to render canvas onto high-res bitmap for download/export
object MemeExporter {
    fun renderMemeToBitmap(
        baseBitmap: Bitmap?,
        topText: String,
        bottomText: String,
        fontSizeSp: Float = 32f,
        fontFamilyName: String = "Impact",
        textColorHex: String = "#FFFFFF",
        strokeColorHex: String = "#000000",
        hasStroke: Boolean = true,
        placementMode: PlacementMode = PlacementMode.TOP_BOTTOM,
        targetWidth: Int = 1080,
        targetHeight: Int = 1080
    ): Bitmap {
        val output = Bitmap.createBitmap(targetWidth, targetHeight, Bitmap.Config.ARGB_8888)
        val canvas = android.graphics.Canvas(output)
        canvas.drawColor(android.graphics.Color.parseColor("#0F0C1E"))

        baseBitmap?.let { bmp ->
            val scale = maxOf(targetWidth.toFloat() / bmp.width, targetHeight.toFloat() / bmp.height)
            val sw = bmp.width * scale
            val sh = bmp.height * scale
            val left = (targetWidth - sw) / 2f
            val top = (targetHeight - sh) / 2f
            canvas.drawBitmap(bmp, null, RectF(left, top, left + sw, top + sh), null)
        }

        val density = targetWidth / 360f
        val effectiveTextSize = fontSizeSp * density
        val tf = when (fontFamilyName) {
            "Monospace" -> android.graphics.Typeface.MONOSPACE
            "Serif" -> android.graphics.Typeface.SERIF
            "Cursive" -> android.graphics.Typeface.create("cursive", android.graphics.Typeface.BOLD)
            "Sans-Serif" -> android.graphics.Typeface.DEFAULT_BOLD
            else -> android.graphics.Typeface.create("Impact", android.graphics.Typeface.BOLD)
        }

        val strokePaint = Paint().apply {
            isAntiAlias = true
            textSize = effectiveTextSize
            typeface = tf
            style = Paint.Style.STROKE
            strokeWidth = effectiveTextSize * 0.16f
            color = android.graphics.Color.parseColor(strokeColorHex)
            textAlign = Paint.Align.CENTER
        }

        val fillPaint = Paint().apply {
            isAntiAlias = true
            textSize = effectiveTextSize
            typeface = tf
            style = Paint.Style.FILL
            color = android.graphics.Color.parseColor(textColorHex)
            textAlign = Paint.Align.CENTER
        }

        val textX = targetWidth / 2f
        if (topText.isNotBlank()) {
            val lines = splitTextIntoLines(topText, targetWidth * 0.9f, fillPaint)
            var currentY = 54f * density
            for (line in lines) {
                if (hasStroke) canvas.drawText(line, textX, currentY, strokePaint)
                canvas.drawText(line, textX, currentY, fillPaint)
                currentY += effectiveTextSize * 1.15f
            }
        }

        if (bottomText.isNotBlank()) {
            val lines = splitTextIntoLines(bottomText, targetWidth * 0.9f, fillPaint)
            var startY = targetHeight - (32f * density) - ((lines.size - 1) * effectiveTextSize * 1.15f)
            for (line in lines) {
                if (hasStroke) canvas.drawText(line, textX, startY, strokePaint)
                canvas.drawText(line, textX, startY, fillPaint)
                startY += effectiveTextSize * 1.15f
            }
        }

        return output
    }
}
