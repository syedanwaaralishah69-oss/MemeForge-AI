package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Subtitles
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.SubtitleItem
import com.example.data.model.SubtitleStyle
import com.example.data.model.VoiceOption
import com.example.data.remote.GeminiService
import com.example.ui.theme.ForgeAmberAccent
import com.example.ui.theme.ForgeCyanLight
import com.example.ui.theme.ForgePinkPunch
import com.example.ui.theme.ForgePurpleLight
import com.example.ui.theme.ForgePurplePrimary
import com.example.ui.viewmodel.MemeForgeViewModel

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AiVoiceScreen(
    viewModel: MemeForgeViewModel,
    modifier: Modifier = Modifier
) {
    val voiceText by viewModel.voiceText.collectAsState()
    val rate by viewModel.voiceRate.collectAsState()
    val isSpeaking by viewModel.isSpeaking.collectAsState()

    var selectedLanguage by remember { mutableStateOf("Roman Urdu") }
    var selectedVoice by remember { mutableStateOf(VoiceOption.ENERGETIC) }
    var voiceVolume by remember { mutableStateOf(1.0f) }

    // Auto Subtitle State
    var subtitles by remember { mutableStateOf<List<SubtitleItem>>(emptyList()) }
    var selectedSubtitleStyle by remember { mutableStateOf(SubtitleStyle.HORMOZI_YELLOW) }
    var subtitlePosition by remember { mutableStateOf("Bottom") } // Top, Center, Bottom
    var subtitleFontSize by remember { mutableStateOf(24f) }

    val languages = listOf("Urdu", "Roman Urdu", "Hinglish", "English")
    val positions = listOf("Top", "Center", "Bottom")

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 48.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Toolbar
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { viewModel.navigateTo("dashboard") }) {
                    Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, contentDescription = "Back", modifier = Modifier.size(28.dp))
                }
                Text(
                    text = "AI Voiceover & Auto Subtitles",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
            }
        }

        // Voiceover Script Input Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                border = androidx.compose.foundation.BorderStroke(1.dp, ForgeAmberAccent.copy(alpha = 0.3f))
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.RecordVoiceOver, contentDescription = null, tint = ForgeAmberAccent)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Voiceover Script",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        // Regenerate script button
                        OutlinedButton(
                            onClick = {
                                val samples = listOf(
                                    "When you study for 10 minutes and reward yourself with 4 hours of memes.",
                                    "Ammi ne kaha tha 5 minute mein aa rahi hoon, ab 2 ghantay ho gaye hain.",
                                    "Bro thought he could pass the exam without opening the book. Reality hit hard.",
                                    "Life advice: Never argue with someone who eats biryani with a spoon."
                                )
                                viewModel.setVoiceText(samples.random())
                                viewModel.showToast("Generated new script!")
                            },
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Regenerate", fontSize = 12.sp)
                        }
                    }

                    OutlinedTextField(
                        value = voiceText,
                        onValueChange = { viewModel.setVoiceText(it) },
                        label = { Text("Enter voiceover script") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(110.dp)
                            .testTag("input_voice_script"),
                        shape = RoundedCornerShape(12.dp)
                    )

                    // Language Selection
                    Text("Script Language:", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        languages.forEach { l ->
                            FilterChip(
                                selected = selectedLanguage == l,
                                onClick = { selectedLanguage = l },
                                label = { Text(l, fontSize = 12.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = ForgeCyanLight,
                                    selectedLabelColor = Color.Black
                                )
                            )
                        }
                    }

                    // Voice Options (Male, Female, Energetic, Funny, Calm, Storytelling)
                    Text("Voice Profile / Persona:", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        VoiceOption.values().forEach { v ->
                            FilterChip(
                                selected = selectedVoice == v,
                                onClick = {
                                    selectedVoice = v
                                    viewModel.setVoicePitch(v.pitch)
                                    viewModel.setVoiceRate(v.speed)
                                    viewModel.setVoicePersona(v.label)
                                },
                                label = { Text(v.label) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = ForgeAmberAccent,
                                    selectedLabelColor = Color.Black
                                )
                            )
                        }
                    }

                    // Voice Speed Slider
                    Column {
                        Text("Voice Speed: ${String.format("%.2f", rate)}x", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Slider(
                            value = rate,
                            onValueChange = { viewModel.setVoiceRate(it) },
                            valueRange = 0.5f..1.8f
                        )
                    }

                    // Voice Volume Slider
                    Column {
                        Text("Voice Volume: ${(voiceVolume * 100).toInt()}%", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Slider(
                            value = voiceVolume,
                            onValueChange = { voiceVolume = it },
                            valueRange = 0f..1f
                        )
                    }

                    // Audio Playback Controls
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = {
                                if (isSpeaking) viewModel.stopVoice()
                                else viewModel.speakVoice()
                            },
                            modifier = Modifier
                                .weight(1f)
                                .height(50.dp)
                                .testTag("btn_speak_voice"),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isSpeaking) Color.Red else ForgeAmberAccent
                            )
                        ) {
                            Icon(
                                imageVector = if (isSpeaking) Icons.Default.Stop else Icons.Default.PlayArrow,
                                contentDescription = null,
                                tint = Color.Black
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (isSpeaking) "Stop Preview" else "Audition Voiceover",
                                color = Color.Black,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Button(
                            onClick = { viewModel.saveVoiceCreation() },
                            modifier = Modifier
                                .weight(1f)
                                .height(50.dp),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = ForgePurplePrimary)
                        ) {
                            Icon(Icons.Default.Save, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Save Voice", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // AUTO SUBTITLES SECTION
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                border = androidx.compose.foundation.BorderStroke(1.dp, ForgeCyanLight.copy(alpha = 0.3f))
            ) {
                Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Subtitles, contentDescription = null, tint = ForgeCyanLight)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Auto Subtitles Generator (Shorts / Reels)", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    }

                    Text(
                        text = "Automatically synchronizes words and phrases from your voiceover script.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Button(
                        onClick = {
                            subtitles = GeminiService.generateAutoSubtitles(voiceText, 10f)
                            viewModel.showToast("Generated ${subtitles.size} timed subtitle phrases!")
                        },
                        modifier = Modifier.fillMaxWidth().height(48.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = ForgeCyanLight)
                    ) {
                        Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Color.Black)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("⚡ Generate Timed Subtitles", color = Color.Black, fontWeight = FontWeight.Bold)
                    }

                    // Subtitle Styles
                    Text("Reels Subtitle Visual Style:", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        SubtitleStyle.values().forEach { st ->
                            FilterChip(
                                selected = selectedSubtitleStyle == st,
                                onClick = { selectedSubtitleStyle = st },
                                label = { Text(st.label) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = ForgePurplePrimary,
                                    selectedLabelColor = Color.White
                                )
                            )
                        }
                    }

                    // Subtitle Position
                    Text("On-Screen Position:", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        positions.forEach { pos ->
                            FilterChip(
                                selected = subtitlePosition == pos,
                                onClick = { subtitlePosition = pos },
                                label = { Text(pos) }
                            )
                        }
                    }

                    // Subtitle Font Size Slider
                    Column {
                        Text("Subtitle Font Size: ${subtitleFontSize.toInt()}sp", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Slider(
                            value = subtitleFontSize,
                            onValueChange = { subtitleFontSize = it },
                            valueRange = 16f..40f
                        )
                    }

                    // Live Subtitle Preview Box
                    if (subtitles.isNotEmpty()) {
                        Text("Timed Subtitles Timeline Preview:", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            subtitles.forEach { sub ->
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                    shape = RoundedCornerShape(10.dp),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
                                ) {
                                    Row(
                                        modifier = Modifier.padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = sub.text,
                                                fontSize = 14.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = Color(android.graphics.Color.parseColor(selectedSubtitleStyle.fontColorHex))
                                            )
                                            Spacer(modifier = Modifier.height(2.dp))
                                            Text(
                                                text = "${String.format("%.1f", sub.startSec)}s - ${String.format("%.1f", sub.endSec)}s (${sub.words.size} words timed)",
                                                fontSize = 11.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }

                                        Surface(
                                            shape = RoundedCornerShape(6.dp),
                                            color = ForgeCyanLight.copy(alpha = 0.2f)
                                        ) {
                                            Text(
                                                text = "SYNCED",
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = ForgeCyanLight,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        // Send Subtitles to Video Editor
                        Button(
                            onClick = {
                                viewModel.setEditorBottomText(subtitles.firstOrNull()?.text ?: "")
                                viewModel.navigateTo("video_editor")
                                viewModel.showToast("Subtitles synchronized with video timeline!")
                            },
                            modifier = Modifier.fillMaxWidth().height(48.dp),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = ForgePurplePrimary)
                        ) {
                            Icon(Icons.Default.Tune, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Open in Video Editor Timeline", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}
