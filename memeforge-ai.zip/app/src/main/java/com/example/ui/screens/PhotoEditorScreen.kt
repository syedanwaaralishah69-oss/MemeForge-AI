package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.FormatAlignLeft
import androidx.compose.material.icons.automirrored.filled.FormatAlignRight
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.RotateRight
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.FormatAlignCenter
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Slider
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AspectRatioPreset
import com.example.data.model.PlacementMode
import com.example.data.model.TextAnimationType
import com.example.ui.components.MemeCanvasView
import com.example.ui.theme.ForgeAmberAccent
import com.example.ui.theme.ForgeCyanLight
import com.example.ui.theme.ForgePinkPunch
import com.example.ui.theme.ForgePurpleLight
import com.example.ui.theme.ForgePurplePrimary
import com.example.ui.viewmodel.MemeForgeViewModel

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun PhotoEditorScreen(
    viewModel: MemeForgeViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val bitmap by viewModel.editorBitmap.collectAsState()
    val topText by viewModel.editorTopText.collectAsState()
    val bottomText by viewModel.editorBottomText.collectAsState()
    val fontSize by viewModel.editorFontSize.collectAsState()
    val fontName by viewModel.editorFontName.collectAsState()
    val textColor by viewModel.editorTextColor.collectAsState()
    val strokeColor by viewModel.editorStrokeColor.collectAsState()
    val hasStroke by viewModel.editorHasStroke.collectAsState()
    val hasShadow by viewModel.editorHasShadow.collectAsState()
    val alignment by viewModel.editorAlignment.collectAsState()
    val placementMode by viewModel.editorPlacementMode.collectAsState()
    val textAnimation by viewModel.editorTextAnimation.collectAsState()
    val additionalLayers by viewModel.editorAdditionalLayers.collectAsState()
    val stickers by viewModel.editorStickers.collectAsState()
    val filter by viewModel.editorFilter.collectAsState()
    val brightness by viewModel.editorBrightness.collectAsState()
    val contrast by viewModel.editorContrast.collectAsState()
    val blur by viewModel.editorBlur.collectAsState()
    val rotation by viewModel.editorRotation.collectAsState()
    val aspectPreset by viewModel.editorAspectPreset.collectAsState()
    val canUndo by viewModel.canUndo.collectAsState()
    val canRedo by viewModel.canRedo.collectAsState()

    var selectedTab by remember { mutableStateOf(0) }
    val tabs = listOf("Text & AI", "Layout & Shadow", "Animation", "Stickers", "Filters", "Adjust", "Size / Crop")

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        uri?.let { viewModel.loadUriForEditor(it, context) }
    }

    val memeEmojis = listOf("🔥", "😂", "💀", "😎", "✨", "👑", "💯", "🤫", "🤡", "🧢", "🗿", "😭", "🥊", "☕", "📱", "🍕", "🍔", "👀", "💣", "🎉")
    val filterNames = listOf("Normal", "Grayscale", "Sepia", "High Contrast", "Warm", "Cool", "Vintage", "Invert")
    val fonts = listOf("Impact", "Sans-Serif", "Serif", "Monospace", "Cursive")
    val colors = listOf("#FFFFFF", "#FFFF00", "#FF0055", "#00F0FF", "#00FF66", "#FF9900", "#000000")

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 48.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Toolbar: Back, Undo, Redo, Rotate, Photo, Save
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { viewModel.navigateTo("dashboard") }) {
                        Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, contentDescription = "Back", modifier = Modifier.size(28.dp))
                    }
                    Text(
                        text = "AI Meme Studio",
                        fontSize = 19.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = { viewModel.undo() },
                        enabled = canUndo,
                        modifier = Modifier.testTag("btn_undo")
                    ) {
                        Icon(
                            Icons.AutoMirrored.Filled.Undo,
                            contentDescription = "Undo",
                            tint = if (canUndo) MaterialTheme.colorScheme.primary else Color.Gray
                        )
                    }

                    IconButton(
                        onClick = { viewModel.redo() },
                        enabled = canRedo,
                        modifier = Modifier.testTag("btn_redo")
                    ) {
                        Icon(
                            Icons.AutoMirrored.Filled.Redo,
                            contentDescription = "Redo",
                            tint = if (canRedo) MaterialTheme.colorScheme.primary else Color.Gray
                        )
                    }

                    IconButton(
                        onClick = { viewModel.rotateEditor90() },
                        modifier = Modifier.testTag("btn_rotate")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.RotateRight, contentDescription = "Rotate 90°")
                    }

                    IconButton(
                        onClick = {
                            photoPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        },
                        modifier = Modifier.testTag("btn_replace_photo")
                    ) {
                        Icon(Icons.Default.AddPhotoAlternate, contentDescription = "Change Image")
                    }

                    IconButton(
                        onClick = { viewModel.saveEditorCreation() },
                        modifier = Modifier.testTag("btn_save_editor")
                    ) {
                        Icon(Icons.Default.Save, contentDescription = "Save", tint = ForgePurpleLight)
                    }
                }
            }
        }

        // Editor Canvas
        item {
            MemeCanvasView(
                bitmap = bitmap,
                topText = topText,
                bottomText = bottomText,
                fontSizeSp = fontSize,
                fontFamilyName = fontName,
                textColorHex = textColor,
                strokeColorHex = strokeColor,
                hasStroke = hasStroke,
                hasShadow = hasShadow,
                textAlignment = alignment,
                placementMode = placementMode,
                textAnimation = textAnimation,
                additionalTextLayers = additionalLayers,
                filter = filter,
                brightness = brightness,
                contrast = contrast,
                rotationDeg = rotation,
                aspectPreset = aspectPreset,
                stickers = stickers,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(if (aspectPreset == AspectRatioPreset.TIKTOK_REELS_SHORTS) 380.dp else 290.dp)
            )
        }

        // Tabs Row
        item {
            ScrollableTabRow(
                selectedTabIndex = selectedTab,
                edgePadding = 0.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                tabs.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        text = { Text(title, fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal) }
                    )
                }
            }
        }

        // TAB 0: TEXT & AI
        if (selectedTab == 0) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // AI Auto Joke Generator Button
                        Button(
                            onClick = {
                                viewModel.generateAutoMemePipeline()
                                viewModel.showToast("AI analyzed image and created joke!")
                            },
                            modifier = Modifier.fillMaxWidth().height(46.dp),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = ForgePurplePrimary)
                        ) {
                            Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("⚡ AI Analyze Image & Place Joke", fontWeight = FontWeight.Bold)
                        }

                        OutlinedTextField(
                            value = topText,
                            onValueChange = { viewModel.setEditorTopText(it) },
                            label = { Text("Top Setup Text") },
                            modifier = Modifier.fillMaxWidth().testTag("input_top_text"),
                            shape = RoundedCornerShape(12.dp)
                        )

                        OutlinedTextField(
                            value = bottomText,
                            onValueChange = { viewModel.setEditorBottomText(it) },
                            label = { Text("Bottom Punchline Text") },
                            modifier = Modifier.fillMaxWidth().testTag("input_bottom_text"),
                            shape = RoundedCornerShape(12.dp)
                        )

                        // Additional Multiple Text Boxes
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Extra Text Boxes (${additionalLayers.size}):", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Button(
                                onClick = { viewModel.addAdditionalTextLayer("NEW TEXT BOX") },
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = ForgeCyanLight)
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Add Box", color = Color.Black, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        additionalLayers.forEachIndexed { idx, layer ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text("#${idx + 1}: ${layer.text}", fontSize = 13.sp, modifier = Modifier.weight(1f))
                                IconButton(onClick = { viewModel.removeAdditionalTextLayer(layer.id) }) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.Red, modifier = Modifier.size(18.dp))
                                }
                            }
                        }

                        // Font selection
                        Text("Font Family:", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(fonts) { f ->
                                FilterChip(
                                    selected = fontName == f,
                                    onClick = { viewModel.setEditorFontName(f) },
                                    label = { Text(f) }
                                )
                            }
                        }

                        // Font size slider
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Size: ${fontSize.toInt()}sp", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.width(90.dp))
                            Slider(
                                value = fontSize,
                                onValueChange = { viewModel.setEditorFontSize(it) },
                                valueRange = 16f..52f,
                                modifier = Modifier.weight(1f)
                            )
                        }

                        // Text Color Palette
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text("Color:", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                            colors.forEach { hex ->
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(CircleShape)
                                        .background(Color(android.graphics.Color.parseColor(hex)))
                                        .border(
                                            if (textColor == hex) 2.5.dp else 1.dp,
                                            if (textColor == hex) MaterialTheme.colorScheme.primary else Color.Gray,
                                            CircleShape
                                        )
                                        .clickable { viewModel.setEditorTextColor(hex) }
                                )
                            }
                        }

                        // Alignment
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            IconButton(onClick = { viewModel.setEditorAlignment("Left") }) {
                                Icon(Icons.AutoMirrored.Filled.FormatAlignLeft, contentDescription = "Left")
                            }
                            IconButton(onClick = { viewModel.setEditorAlignment("Center") }) {
                                Icon(Icons.Default.FormatAlignCenter, contentDescription = "Center")
                            }
                            IconButton(onClick = { viewModel.setEditorAlignment("Right") }) {
                                Icon(Icons.AutoMirrored.Filled.FormatAlignRight, contentDescription = "Right")
                            }
                        }
                    }
                }
            }
        }

        // TAB 1: LAYOUT & SHADOW
        if (selectedTab == 1) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Automatic Text Placement Mode:", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            PlacementMode.values().forEach { mode ->
                                FilterChip(
                                    selected = placementMode == mode,
                                    onClick = { viewModel.setEditorPlacementMode(mode) },
                                    label = { Text(mode.label) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = ForgePurplePrimary,
                                        selectedLabelColor = Color.White
                                    )
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        Text("Outline & Drop Shadow Effects:", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            FilterChip(
                                selected = hasStroke,
                                onClick = { viewModel.toggleEditorStroke() },
                                label = { Text(if (hasStroke) "Black Outline: ON" else "Outline: OFF") }
                            )

                            FilterChip(
                                selected = hasShadow,
                                onClick = { viewModel.toggleEditorShadow() },
                                label = { Text(if (hasShadow) "Drop Shadow: ON" else "Shadow: OFF") }
                            )
                        }
                    }
                }
            }
        }

        // TAB 2: ANIMATION
        if (selectedTab == 2) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Text Animation / Motion Styling:", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            TextAnimationType.values().forEach { anim ->
                                FilterChip(
                                    selected = textAnimation == anim,
                                    onClick = { viewModel.setEditorTextAnimation(anim) },
                                    label = { Text(anim.label) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = ForgePinkPunch,
                                        selectedLabelColor = Color.White
                                    )
                                )
                            }
                        }
                    }
                }
            }
        }

        // TAB 3: STICKERS
        if (selectedTab == 3) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Tap any emoji to add to canvas:", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                            if (stickers.isNotEmpty()) {
                                Text(
                                    "Clear All",
                                    fontSize = 12.sp,
                                    color = Color.Red,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.clickable { viewModel.clearAllStickers() }
                                )
                            }
                        }

                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            memeEmojis.forEach { emoji ->
                                Box(
                                    modifier = Modifier
                                        .size(46.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(MaterialTheme.colorScheme.surface)
                                        .clickable { viewModel.addSticker(emoji) },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(emoji, fontSize = 24.sp)
                                }
                            }
                        }
                    }
                }
            }
        }

        // TAB 4: FILTERS
        if (selectedTab == 4) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Meme Filters:", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            filterNames.forEach { name ->
                                FilterChip(
                                    selected = filter.name == name,
                                    onClick = { viewModel.setEditorFilterByName(name) },
                                    label = { Text(name) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = ForgePurplePrimary,
                                        selectedLabelColor = Color.White
                                    )
                                )
                            }
                        }
                    }
                }
            }
        }

        // TAB 5: ADJUST
        if (selectedTab == 5) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        Text("Image Adjustments:", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        Column {
                            Text("Brightness: ${(brightness * 100).toInt()}%", fontSize = 12.sp)
                            Slider(value = brightness, onValueChange = { viewModel.setEditorBrightness(it) }, valueRange = -0.5f..0.5f)
                        }
                        Column {
                            Text("Contrast: ${String.format("%.1f", contrast)}x", fontSize = 12.sp)
                            Slider(value = contrast, onValueChange = { viewModel.setEditorContrast(it) }, valueRange = 0.5f..2.0f)
                        }
                        Column {
                            Text("Blur Effect: ${blur.toInt()}", fontSize = 12.sp)
                            Slider(value = blur, onValueChange = { viewModel.setEditorBlur(it) }, valueRange = 0f..10f)
                        }
                    }
                }
            }
        }

        // TAB 6: SIZE / CROP
        if (selectedTab == 6) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Select Platform Canvas Preset:", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            AspectRatioPreset.values().forEach { preset ->
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { viewModel.setEditorAspectPreset(preset) },
                                    shape = RoundedCornerShape(10.dp),
                                    colors = CardDefaults.cardColors(
                                        containerColor = if (aspectPreset == preset) ForgePurplePrimary.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surface
                                    ),
                                    border = androidx.compose.foundation.BorderStroke(
                                        if (aspectPreset == preset) 1.5.dp else 1.dp,
                                        if (aspectPreset == preset) ForgePurpleLight else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
                                    )
                                ) {
                                    Row(
                                        modifier = Modifier.padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(preset.label, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                                        Text(preset.badge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, fontSize = 13.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // EXPORT & ACTION CONTROLS
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = { viewModel.downloadMemeImage(context) },
                        modifier = Modifier.weight(1f).height(50.dp).testTag("btn_download_image"),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = ForgeCyanLight)
                    ) {
                        Icon(Icons.Default.Download, contentDescription = null, tint = Color.Black)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Download Image", color = Color.Black, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = { viewModel.saveEditorCreation() },
                        modifier = Modifier.weight(1f).height(50.dp).testTag("btn_save_photo_editor"),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = ForgePurplePrimary)
                    ) {
                        Icon(Icons.Default.Save, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Save to Creations", fontWeight = FontWeight.Bold)
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = { viewModel.regenerateCaption() },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Regenerate Joke")
                    }

                    OutlinedButton(
                        onClick = {
                            viewModel.setEditorTopText("TOP TEXT")
                            viewModel.setEditorBottomText("BOTTOM TEXT")
                            viewModel.showToast("Reset text")
                        },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("Reset Text")
                    }
                }
            }
        }
    }
}
