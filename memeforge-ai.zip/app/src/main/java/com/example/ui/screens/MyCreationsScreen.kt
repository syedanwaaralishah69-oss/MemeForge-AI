package com.example.ui.screens

import android.content.Intent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.MemeCreation
import com.example.ui.theme.ForgeAmberAccent
import com.example.ui.theme.ForgeCyanLight
import com.example.ui.theme.ForgePinkPunch
import com.example.ui.theme.ForgePurpleLight
import com.example.ui.theme.ForgePurplePrimary
import com.example.ui.viewmodel.MemeForgeViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun MyCreationsScreen(
    viewModel: MemeForgeViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val creations by viewModel.creations.collectAsState()

    var selectedFilter by remember { mutableStateOf("All") }
    val filters = listOf("All", "Images", "Videos", "Drafts", "Templates")

    var itemToRename by remember { mutableStateOf<MemeCreation?>(null) }
    var renameInput by remember { mutableStateOf("") }

    val filteredList = when (selectedFilter) {
        "All" -> creations
        "Images" -> creations.filter { it.type == "MEME" || it.type == "IMAGE" || it.type == "PHOTO" }
        "Videos" -> creations.filter { it.type == "PHOTO_VIDEO" || it.type == "VIDEO" || it.type == "STORY" }
        "Drafts" -> creations.filter { it.type == "CAPTION" || it.type == "VOICE" || it.type == "DRAFT" }
        "Templates" -> creations.filter { it.type == "TEMPLATE" || it.style?.contains("Template", ignoreCase = true) == true }
        else -> creations
    }

    // Rename Dialog
    if (itemToRename != null) {
        AlertDialog(
            onDismissRequest = { itemToRename = null },
            title = { Text("Rename Creation") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Enter new project title:", fontSize = 13.sp)
                    OutlinedTextField(
                        value = renameInput,
                        onValueChange = { renameInput = it },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        itemToRename?.let {
                            if (renameInput.isNotBlank()) {
                                viewModel.renameCreation(it.id, renameInput.trim())
                            }
                        }
                        itemToRename = null
                    }
                ) {
                    Text("Save")
                }
            },
            dismissButton = {
                TextButton(onClick = { itemToRename = null }) {
                    Text("Cancel")
                }
            }
        )
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 48.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { viewModel.navigateTo("dashboard") }) {
                    Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, contentDescription = "Back", modifier = Modifier.size(28.dp))
                }
                Text(
                    text = "My Creations",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
            }
        }

        // Filter chips (Images, Videos, Drafts, Templates)
        item {
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(filters) { filter ->
                    val count = when (filter) {
                        "All" -> creations.size
                        "Images" -> creations.count { it.type == "MEME" || it.type == "IMAGE" || it.type == "PHOTO" }
                        "Videos" -> creations.count { it.type == "PHOTO_VIDEO" || it.type == "VIDEO" || it.type == "STORY" }
                        "Drafts" -> creations.count { it.type == "CAPTION" || it.type == "VOICE" || it.type == "DRAFT" }
                        "Templates" -> creations.count { it.type == "TEMPLATE" || it.style?.contains("Template", ignoreCase = true) == true }
                        else -> 0
                    }
                    FilterChip(
                        selected = selectedFilter == filter,
                        onClick = { selectedFilter = filter },
                        label = { Text("$filter ($count)") }
                    )
                }
            }
        }

        // Empty State
        if (filteredList.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Text(
                            text = when (selectedFilter) {
                                "Images" -> "🖼️"
                                "Videos" -> "🎬"
                                "Drafts" -> "📝"
                                "Templates" -> "📑"
                                else -> "🎨"
                            },
                            fontSize = 42.sp
                        )
                        Text(
                            text = "No $selectedFilter yet",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = if (selectedFilter == "Templates") {
                                "Browse the Meme Template Vault to clone and customize editable templates."
                            } else {
                                "Use Auto Create or Photo Editor to generate and save your viral masterpieces."
                            },
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            lineHeight = 18.sp
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        if (selectedFilter == "Templates") {
                            Button(
                                onClick = { viewModel.navigateTo("meme_templates") },
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = ForgePurplePrimary)
                            ) {
                                Icon(Icons.Default.PhotoLibrary, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Open Template Vault", fontWeight = FontWeight.Bold)
                            }
                        } else {
                            Button(
                                onClick = {
                                    viewModel.setAutoCreateStep(1)
                                    viewModel.navigateTo("auto_create")
                                },
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = ForgePurplePrimary)
                            ) {
                                Icon(Icons.Default.AutoAwesome, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("⚡ Create a Meme Now", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        } else {
            items(filteredList, key = { it.id }) { item ->
                CreationCard(
                    creation = item,
                    onRename = {
                        itemToRename = item
                        renameInput = item.title
                    },
                    onDelete = { viewModel.deleteCreation(item.id) },
                    onDuplicate = { viewModel.duplicateCreation(item) },
                    onDownload = { viewModel.downloadCreation(item, context) },
                    onEdit = {
                        item.topText?.let { viewModel.setEditorTopText(it) }
                        item.bottomText?.let { viewModel.setEditorBottomText(it) }
                        if (item.type == "PHOTO_VIDEO") {
                            viewModel.navigateTo("video_editor")
                        } else {
                            viewModel.navigateTo("photo_editor")
                        }
                        viewModel.showToast("Loaded into Studio for editing!")
                    },
                    onShare = {
                        val sendIntent = Intent().apply {
                            action = Intent.ACTION_SEND
                            putExtra(
                                Intent.EXTRA_TEXT,
                                "${item.title}\n${item.topText ?: ""}\n${item.bottomText ?: item.fullCaption ?: ""}\n\nCreated with MemeForge AI"
                            )
                            type = "text/plain"
                        }
                        val shareIntent = Intent.createChooser(sendIntent, "Share Meme")
                        context.startActivity(shareIntent)
                    }
                )
            }
        }
    }
}

@Composable
private fun CreationCard(
    creation: MemeCreation,
    onRename: () -> Unit,
    onDuplicate: () -> Unit,
    onDownload: () -> Unit,
    onDelete: () -> Unit,
    onEdit: () -> Unit,
    onShare: () -> Unit
) {
    val dateStr = SimpleDateFormat("MMM d, yyyy • h:mm a", Locale.getDefault())
        .format(Date(creation.timestamp))

    val (typeColor, typeLabel) = when (creation.type) {
        "MEME" -> Pair(ForgePurpleLight, "IMAGE MEME")
        "CAPTION" -> Pair(ForgeCyanLight, "DRAFT CAPTION")
        "PHOTO_VIDEO" -> Pair(ForgePinkPunch, "REEL VIDEO")
        "VOICE" -> Pair(ForgeAmberAccent, "VOICE DRAFT")
        "TEMPLATE" -> Pair(Color(0xFF10B981), "TEMPLATE")
        else -> Pair(Color.White, creation.type)
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("creation_item_${creation.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.25f))
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = typeColor.copy(alpha = 0.2f)
                ) {
                    Text(
                        text = typeLabel,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = typeColor,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                    )
                }

                Text(
                    text = dateStr,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = creation.title,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.weight(1f)
                )

                IconButton(
                    onClick = onRename,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        Icons.Default.Edit,
                        contentDescription = "Rename",
                        modifier = Modifier.size(16.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // Content preview
            creation.topText?.let { top ->
                if (top.isNotBlank()) {
                    Text(
                        text = "“$top”",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }

            creation.bottomText?.let { bottom ->
                if (bottom.isNotBlank()) {
                    Text(
                        text = bottom,
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }

            creation.fullCaption?.let { cap ->
                Text(
                    text = cap,
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurface,
                    lineHeight = 18.sp
                )
            }

            // Tags / Attributes
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                creation.aspectRatio?.let {
                    Surface(shape = RoundedCornerShape(4.dp), color = MaterialTheme.colorScheme.surface) {
                        Text(it, fontSize = 10.sp, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                    }
                }
                creation.style?.let {
                    Surface(shape = RoundedCornerShape(4.dp), color = MaterialTheme.colorScheme.surface) {
                        Text(it, fontSize = 10.sp, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                    }
                }
                creation.language?.let {
                    Surface(shape = RoundedCornerShape(4.dp), color = MaterialTheme.colorScheme.surface) {
                        Text(it, fontSize = 10.sp, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                    }
                }
            }

            // 5 Action Controls: Rename, Edit, Duplicate, Delete, Download (+ Share)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onDuplicate, modifier = Modifier.size(36.dp)) {
                    Icon(Icons.Default.ContentCopy, contentDescription = "Duplicate", modifier = Modifier.size(18.dp))
                }
                IconButton(onClick = onDownload, modifier = Modifier.size(36.dp)) {
                    Icon(Icons.Default.Download, contentDescription = "Download", tint = ForgeCyanLight, modifier = Modifier.size(18.dp))
                }
                IconButton(onClick = onShare, modifier = Modifier.size(36.dp)) {
                    Icon(Icons.Default.Share, contentDescription = "Share", modifier = Modifier.size(18.dp))
                }
                IconButton(onClick = onEdit, modifier = Modifier.size(36.dp)) {
                    Icon(Icons.Default.Tune, contentDescription = "Edit in Studio", tint = ForgePurpleLight, modifier = Modifier.size(18.dp))
                }
                IconButton(onClick = onDelete, modifier = Modifier.size(36.dp)) {
                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.Red, modifier = Modifier.size(18.dp))
                }
            }
        }
    }
}
