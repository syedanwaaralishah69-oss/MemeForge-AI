package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AspectRatioPreset
import com.example.data.model.AutoCreateStage
import com.example.data.model.MotionEffectType
import com.example.data.model.PlacementMode
import com.example.data.model.TemplateRepository
import com.example.data.model.TextAnimationType
import com.example.ui.components.MemeCanvasView
import com.example.ui.theme.ForgeAmberAccent
import com.example.ui.theme.ForgeCyanLight
import com.example.ui.theme.ForgePinkPunch
import com.example.ui.theme.ForgePurpleLight
import com.example.ui.theme.ForgePurplePrimary
import com.example.ui.viewmodel.MemeForgeViewModel

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AutoCreateScreen(
    viewModel: MemeForgeViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val step by viewModel.autoCreateStep.collectAsState()
    val bitmap by viewModel.autoCreateBitmap.collectAsState()
    val selectedStyle by viewModel.selectedStyle.collectAsState()
    val customStylePrompt by viewModel.customStylePrompt.collectAsState()
    val selectedLanguage by viewModel.selectedLanguage.collectAsState()
    val isGenerating by viewModel.isGenerating.collectAsState()
    val editableTopText by viewModel.editableTopText.collectAsState()
    val editableBottomText by viewModel.editableBottomText.collectAsState()
    val autoAspectPreset by viewModel.autoAspectPreset.collectAsState()
    val autoStage by viewModel.autoCreateStage.collectAsState()
    val completedStages by viewModel.autoCreateCompletedStages.collectAsState()
    val isSpeaking by viewModel.isSpeaking.collectAsState()
    val placementMode by viewModel.autoPlacementMode.collectAsState()

    var showEditDialog by remember { mutableStateOf(false) }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        uri?.let { viewModel.loadUriForAutoCreate(it, context) }
    }

    val styles = listOf(
        "Funny",
        "Desi/Pakistani",
        "Savage",
        "Cute",
        "Friendship",
        "Love",
        "School/Student",
        "Family",
        "Custom"
    )

    val languages = listOf("Roman Urdu", "Urdu", "Hinglish", "English")

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 48.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Top Nav / Step Tracker
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = {
                            if (step > 1) viewModel.setAutoCreateStep(step - 1)
                            else viewModel.navigateTo("dashboard")
                        }
                    ) {
                        Icon(
                            Icons.AutoMirrored.Filled.KeyboardArrowLeft,
                            contentDescription = "Back",
                            modifier = Modifier.size(28.dp)
                        )
                    }
                    Text(
                        text = "Auto Create Flow",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    IconButton(onClick = { viewModel.restartAutoCreate() }) {
                        Icon(Icons.Default.RestartAlt, contentDescription = "Restart", tint = ForgeCyanLight)
                    }

                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = ForgePurplePrimary.copy(alpha = 0.2f)
                    ) {
                        Text(
                            text = "Step $step of 4",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = ForgePurpleLight,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                }
            }
        }

        // STEP 1: UPLOAD PHOTO
        if (step == 1) {
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("upload_card"),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    border = androidx.compose.foundation.BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(72.dp)
                                .clip(CircleShape)
                                .background(ForgePurplePrimary.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                Icons.Default.AddPhotoAlternate,
                                contentDescription = "Upload",
                                tint = ForgePurpleLight,
                                modifier = Modifier.size(36.dp)
                            )
                        }

                        Text(
                            text = "Step 1 — Upload a Photo",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        Text(
                            text = "Choose any picture from your device, or select a classic viral meme below.",
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            lineHeight = 18.sp
                        )

                        Button(
                            onClick = {
                                photoPickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .testTag("btn_select_photo"),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = ForgePurplePrimary)
                        ) {
                            Icon(Icons.Default.AddPhotoAlternate, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Pick Photo from Gallery", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // Quick templates to pick from
            item {
                Text(
                    text = "Or choose a viral meme template:",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onBackground
                )
            }

            item {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(TemplateRepository.templates) { t ->
                        Card(
                            modifier = Modifier
                                .width(180.dp)
                                .clickable {
                                    viewModel.selectPresetTemplateForAutoCreate(t, context)
                                    viewModel.setAutoCreateStep(2)
                                },
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    t.title,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    maxLines = 1
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    t.sampleCaption,
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 2
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    "Select →",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }
                }
            }
        }

        // STEP 2: PREVIEW PHOTO & SIZE PRESET
        if (step >= 2) {
            item {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (step == 4) "Final Meme & Video Preview" else "Photo Preview",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold
                        )
                        if (step < 4) {
                            Text(
                                text = "Change Photo",
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.clickable {
                                    photoPickerLauncher.launch(
                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                    )
                                }
                            )
                        }
                    }

                    // Meme Canvas View
                    MemeCanvasView(
                        bitmap = bitmap,
                        topText = if (step == 4) editableTopText else "",
                        bottomText = if (step == 4) editableBottomText else "",
                        aspectPreset = autoAspectPreset,
                        placementMode = placementMode,
                        textAnimation = if (step == 4) TextAnimationType.PULSE else TextAnimationType.NONE,
                        motionEffect = MotionEffectType.KEN_BURNS,
                        isMotionActive = step == 4,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(if (autoAspectPreset == AspectRatioPreset.TIKTOK_REELS_SHORTS) 400.dp else 290.dp)
                    )

                    // Aspect ratio size presets selector
                    Text(
                        text = "Size / Platform Preset:",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(AspectRatioPreset.values()) { preset ->
                            FilterChip(
                                selected = autoAspectPreset == preset,
                                onClick = { viewModel.setAutoAspectPreset(preset) },
                                label = { Text("${preset.badge} • ${preset.label}", fontSize = 12.sp) }
                            )
                        }
                    }
                }
            }
        }

        // STEP 2 to 3 Forward Button
        if (step == 2) {
            item {
                Button(
                    onClick = { viewModel.setAutoCreateStep(3) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("btn_next_to_styles"),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = ForgePurplePrimary)
                ) {
                    Text("Next: Select Style & Language →", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // STEP 3: SELECT STYLE & LANGUAGE + AI PIPELINE PROGRESS
        if (step == 3) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Text(
                            text = "Step 3 — Select Meme Style / Tone",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            styles.forEach { s ->
                                FilterChip(
                                    selected = selectedStyle == s,
                                    onClick = { viewModel.setSelectedStyle(s) },
                                    label = { Text(s, fontWeight = if (selectedStyle == s) FontWeight.Bold else FontWeight.Normal) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = ForgePurplePrimary,
                                        selectedLabelColor = Color.White
                                    )
                                )
                            }
                        }

                        // Custom style text input
                        AnimatedVisibility(visible = selectedStyle == "Custom") {
                            OutlinedTextField(
                                value = customStylePrompt,
                                onValueChange = { viewModel.setCustomStylePrompt(it) },
                                label = { Text("Custom Prompt (e.g. Sarcastic corporate boss meme)") },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("input_custom_style"),
                                shape = RoundedCornerShape(12.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(
                            text = "Step 4 — Select Language",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            languages.forEach { lang ->
                                FilterChip(
                                    selected = selectedLanguage == lang,
                                    onClick = { viewModel.setSelectedLanguage(lang) },
                                    label = { Text(lang, fontSize = 12.sp) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = ForgeCyanLight,
                                        selectedLabelColor = Color.Black
                                    )
                                )
                            }
                        }

                        // Text Placement Mode Selection
                        Text(
                            text = "Text Placement:",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(PlacementMode.AUTO, PlacementMode.TOP_BOTTOM, PlacementMode.CENTER_CARD).forEach { mode ->
                                FilterChip(
                                    selected = placementMode == mode,
                                    onClick = { viewModel.setAutoPlacementMode(mode) },
                                    label = { Text(mode.label, fontSize = 12.sp) }
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // PIPELINE PROGRESS STAGES TRACKER (When Generating)
                        if (isGenerating) {
                            Card(
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                shape = RoundedCornerShape(14.dp),
                                border = androidx.compose.foundation.BorderStroke(1.dp, ForgePurpleLight.copy(alpha = 0.5f))
                            ) {
                                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text("⚡ AI Forge Pipeline Active:", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = ForgePurpleLight)

                                    AutoCreateStage.values().forEach { stage ->
                                        val isCompleted = completedStages.contains(stage)
                                        val isCurrent = autoStage == stage

                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                                        ) {
                                            if (isCompleted) {
                                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF10B981), modifier = Modifier.size(18.dp))
                                            } else if (isCurrent) {
                                                CircularProgressIndicator(color = ForgeAmberAccent, modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                                            } else {
                                                Icon(Icons.Default.RadioButtonUnchecked, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(18.dp))
                                            }

                                            Text(
                                                text = stage.title,
                                                fontSize = 12.sp,
                                                fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal,
                                                color = if (isCurrent) ForgeAmberAccent else MaterialTheme.colorScheme.onSurface
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        // Generate Button
                        Button(
                            onClick = { viewModel.generateAutoMemePipeline() },
                            enabled = !isGenerating,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(54.dp)
                                .testTag("btn_generate_auto_meme"),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = ForgePurplePrimary)
                        ) {
                            if (isGenerating) {
                                CircularProgressIndicator(
                                    color = Color.White,
                                    modifier = Modifier.size(24.dp),
                                    strokeWidth = 2.5.dp
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Text("Forging: ${autoStage.title}...", fontWeight = FontWeight.Bold)
                            } else {
                                Icon(Icons.Default.AutoAwesome, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("⚡ AUTO CREATE MEME & VIDEO", fontSize = 16.sp, fontWeight = FontWeight.Black)
                            }
                        }
                    }
                }
            }
        }

        // STEP 4: RESULT, EXPORT, DOWNLOAD, REGENERATE, RESTART
        if (step == 4) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = "AI Caption & Subtitles:",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = editableTopText,
                                    fontWeight = FontWeight.Black,
                                    fontSize = 15.sp,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = editableBottomText,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }

                        // Voiceover narration play button
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.RecordVoiceOver, contentDescription = null, tint = ForgeCyanLight, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("AI Voiceover:", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                            }

                            Button(
                                onClick = {
                                    if (isSpeaking) viewModel.stopVoice()
                                    else viewModel.speakVoice()
                                },
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isSpeaking) Color.Red else ForgeCyanLight
                                )
                            ) {
                                Icon(
                                    imageVector = if (isSpeaking) Icons.Default.Stop else Icons.Default.PlayArrow,
                                    contentDescription = null,
                                    tint = Color.Black,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = if (isSpeaking) "Stop" else "Listen",
                                    color = Color.Black,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp
                                )
                            }
                        }

                        // Regenerate and Edit Caption buttons
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            OutlinedButton(
                                onClick = { viewModel.regenerateCaption() },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("btn_regenerate"),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Regenerate")
                            }

                            Button(
                                onClick = { showEditDialog = true },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("btn_edit_caption"),
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = ForgeCyanLight)
                            ) {
                                Icon(Icons.Default.Edit, contentDescription = null, tint = Color.Black, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Edit Text", color = Color.Black, fontWeight = FontWeight.Bold)
                            }
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        // EXPORT BUTTONS (Download Image & Download Video)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Button(
                                onClick = { viewModel.downloadMemeImage(context) },
                                modifier = Modifier.weight(1f).height(50.dp).testTag("btn_download_image_auto"),
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = ForgePurplePrimary)
                            ) {
                                Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Download Image", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            }

                            Button(
                                onClick = { viewModel.downloadVideoReel() },
                                modifier = Modifier.weight(1f).height(50.dp).testTag("btn_download_video_auto"),
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = ForgePinkPunch)
                            ) {
                                Icon(Icons.Default.Movie, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Download Video", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        // Open in Full Photo Editor & Save & Restart
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            OutlinedButton(
                                onClick = { viewModel.openCurrentAutoMemeInPhotoEditor() },
                                modifier = Modifier.weight(1f).height(46.dp),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(Icons.Default.Tune, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Edit in Studio", fontSize = 12.sp)
                            }

                            OutlinedButton(
                                onClick = { viewModel.restartAutoCreate() },
                                modifier = Modifier.weight(1f).height(46.dp),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(Icons.Default.RestartAlt, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Restart Flow", fontSize = 12.sp)
                            }
                        }

                        Button(
                            onClick = { viewModel.saveAutoMemeToCreations() },
                            modifier = Modifier.fillMaxWidth().height(48.dp),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = ForgePurplePrimary.copy(alpha = 0.35f))
                        ) {
                            Icon(Icons.Default.Save, contentDescription = null, tint = ForgePurpleLight)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Save to My Creations", color = ForgePurpleLight, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }

    // Modal Dialog for Editing Caption
    if (showEditDialog) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { showEditDialog = false },
            title = { Text("Edit Meme Caption", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = editableTopText,
                        onValueChange = { viewModel.setEditableTopText(it) },
                        label = { Text("Top Setup Text") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = editableBottomText,
                        onValueChange = { viewModel.setEditableBottomText(it) },
                        label = { Text("Bottom Punchline Text") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = { showEditDialog = false },
                    colors = ButtonDefaults.buttonColors(containerColor = ForgePurplePrimary)
                ) {
                    Text("Apply")
                }
            }
        )
    }
}
