package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// MemeForge AI Modern Creator Palette
val ForgePurplePrimary = Color(0xFFA855F7)
val ForgePurpleLight = Color(0xFFC084FC)
val ForgePurpleDark = Color(0xFF7E22CE)

val ForgeCyanSecondary = Color(0xFF06B6D4)
val ForgeCyanLight = Color(0xFF22D3EE)

val ForgeAmberAccent = Color(0xFFF59E0B)
val ForgeAmberBright = Color(0xFFFBBF24)
val ForgePinkPunch = Color(0xFFEC4899)
val ForgeGreenVibrant = Color(0xFF10B981)

// Dark Surfaces
val DarkBg = Color(0xFF0D0A1A)
val DarkSurface = Color(0xFF16122C)
val DarkSurfaceElevated = Color(0xFF211C40)
val DarkBorder = Color(0xFF2E2657)
val TextPrimaryDark = Color(0xFFF8FAFC)
val TextSecondaryDark = Color(0xFF94A3B8)

// Light Surfaces
val LightBg = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceElevated = Color(0xFFF1F5F9)
val LightBorder = Color(0xFFE2E8F0)
val TextPrimaryLight = Color(0xFF0F172A)
val TextSecondaryLight = Color(0xFF64748B)
