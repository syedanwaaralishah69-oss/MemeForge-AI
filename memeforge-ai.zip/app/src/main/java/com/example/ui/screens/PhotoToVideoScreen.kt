package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Slideshow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AspectRatioPreset
import com.example.data.model.MotionEffectType
import com.example.data.model.StickerItem
import com.example.ui.components.MemeCanvasView
import com.example.ui.theme.ForgeCyanLight
import com.example.ui.theme.ForgePinkPunch
import com.example.ui.theme.ForgePurpleLight
import com.example.ui.theme.ForgePurplePrimary
import com.example.ui.viewmodel.MemeForgeViewModel

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun PhotoToVideoScreen(
    viewModel: MemeForgeViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val photos by viewModel.videoPhotos.collectAsState()
    val currentPhotoIndex by viewModel.videoCurrentPhotoIndex.collectAsState()
    val topText by viewModel.editorTopText.collectAsState()
    val bottomText by viewModel.editorBottomText.collectAsState()
    val isPlaying by viewModel.isVideoPlaying.collectAsState()
    val duration by viewModel.videoDuration.collectAsState()
    val track by viewModel.videoTrack.collectAsState()
    val motionEffect by viewModel.videoMotionEffect.collectAsState()
    val hasMotionText by viewModel.videoHasMotionText.collectAsState()
    val hasAnimatedStickers by viewModel.videoHasAnimatedStickers.collectAsState()

    val currentBitmap = photos.getOrNull(currentPhotoIndex) ?: viewModel.editorBitmap.collectAsState().value

    // Multi-photo picker launcher
    val multiplePhotoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia(maxItems = 10)
    ) { uris: List<Uri> ->
        if (uris.isNotEmpty()) {
            viewModel.loadMultiplePhotosForVideo(uris, context)
        }
    }

    // Animation progress
    val infiniteTransition = rememberInfiniteTransition(label = "video_progress")
    val progressAnim by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(duration * 1000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "progress"
    )

    val durationPresets = listOf(5, 10, 15, 30, 60)
    val musicTracks = listOf(
        "Viral Phonk Beat",
        "Lo-fi Meme Chill",
        "Synthwave Arcade",
        "Desi Dhol Funk",
        "Suspense Drone",
        "Comedy Tiptoe"
    )

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 48.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Toolbar
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { viewModel.navigateTo("dashboard") }) {
                    Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, contentDescription = "Back", modifier = Modifier.size(28.dp))
                }
                Text(
                    text = "Photo-to-Video Reel Creator",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
            }
        }

        // Live Animated Video Canvas
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                border = androidx.compose.foundation.BorderStroke(1.5.dp, ForgePinkPunch.copy(alpha = 0.5f))
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(340.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color.Black),
                        contentAlignment = Alignment.Center
                    ) {
                        MemeCanvasView(
                            bitmap = currentBitmap,
                            topText = if (hasMotionText) topText else "",
                            bottomText = if (hasMotionText) bottomText else "",
                            aspectPreset = AspectRatioPreset.TIKTOK_REELS_SHORTS,
                            motionEffect = motionEffect,
                            isMotionActive = isPlaying,
                            stickers = if (hasAnimatedStickers) listOf(
                                StickerItem("v_s1", "🔥", 0.85f, 0.2f, 36f, isAnimated = true),
                                StickerItem("v_s2", "✨", 0.15f, 0.85f, 32f, isAnimated = true)
                            ) else emptyList(),
                            modifier = Modifier.fillMaxSize()
                        )

                        // Play/Pause Overlay Button
                        Box(
                            modifier = Modifier
                                .size(56.dp)
                                .clip(CircleShape)
                                .background(Color.Black.copy(alpha = 0.6f))
                                .border(1.5.dp, Color.White, CircleShape)
                                .clickable { viewModel.toggleVideoPlayback() }
                                .testTag("btn_play_pause_video"),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = if (isPlaying) "Pause" else "Play",
                                tint = Color.White,
                                modifier = Modifier.size(32.dp)
                            )
                        }

                        // Slide Indicator / Multi-Photo count badge
                        if (photos.size > 1) {
                            Surface(
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .padding(10.dp),
                                shape = RoundedCornerShape(8.dp),
                                color = Color.Black.copy(alpha = 0.75f)
                            ) {
                                Text(
                                    text = "Photo ${currentPhotoIndex + 1}/${photos.size}",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }

                        // Track Badge Overlay
                        Box(
                            modifier = Modifier
                                .align(Alignment.BottomStart)
                                .padding(12.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color.Black.copy(alpha = 0.7f))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(Icons.Default.MusicNote, contentDescription = null, tint = ForgeCyanLight, modifier = Modifier.size(14.dp))
                                Text(track, fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    // Progress Bar
                    LinearProgressIndicator(
                        progress = { if (isPlaying) progressAnim else 0f },
                        modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                        color = ForgePinkPunch
                    )
                }
            }
        }

        // Multi-Photo Slideshow Strip
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Slideshow, contentDescription = null, tint = ForgePurpleLight)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Slideshow Photos (${photos.size})",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Button(
                            onClick = {
                                multiplePhotoPickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            },
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = ForgePurplePrimary.copy(alpha = 0.25f))
                        ) {
                            Icon(Icons.Default.AddPhotoAlternate, contentDescription = null, tint = ForgePurpleLight, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Add Photos", color = ForgePurpleLight, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    if (photos.isNotEmpty()) {
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            itemsIndexed(photos) { idx, bmp ->
                                Image(
                                    bitmap = bmp.asImageBitmap(),
                                    contentDescription = "Photo $idx",
                                    modifier = Modifier
                                        .size(56.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .border(
                                            if (currentPhotoIndex == idx) 2.dp else 1.dp,
                                            if (currentPhotoIndex == idx) ForgePinkPunch else Color.Gray.copy(alpha = 0.4f),
                                            RoundedCornerShape(8.dp)
                                        )
                                        .clickable { viewModel.setVideoCurrentPhotoIndex(idx) }
                                )
                            }
                        }
                    }
                }
            }
        }

        // Motion Effects & Transitions
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Motion Effects & Transitions:", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        MotionEffectType.values().forEach { eff ->
                            FilterChip(
                                selected = motionEffect == eff,
                                onClick = { viewModel.setVideoMotionEffect(eff) },
                                label = { Text(eff.label) }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    // Video Duration Selection (5s, 10s, 15s, 30s, 60s)
                    Text("Reel Duration:", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(durationPresets) { sec ->
                            FilterChip(
                                selected = duration == sec,
                                onClick = { viewModel.setVideoDuration(sec) },
                                label = { Text("${sec}s", fontWeight = FontWeight.Bold) }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    // Motion text & Animated stickers toggles
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        FilterChip(
                            selected = hasMotionText,
                            onClick = { viewModel.toggleMotionText() },
                            label = { Text(if (hasMotionText) "Motion Text: ON" else "Motion Text: OFF") }
                        )

                        FilterChip(
                            selected = hasAnimatedStickers,
                            onClick = { viewModel.toggleAnimatedStickers() },
                            label = { Text(if (hasAnimatedStickers) "Stickers: ON" else "Stickers: OFF") }
                        )
                    }
                }
            }
        }

        // Music Selection
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.GraphicEq, contentDescription = null, tint = ForgeCyanLight)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Select Music Track:", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    }

                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        musicTracks.forEach { mTrack ->
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { viewModel.setVideoTrack(mTrack) },
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = if (track == mTrack) ForgePurplePrimary.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surface
                                ),
                                border = androidx.compose.foundation.BorderStroke(
                                    if (track == mTrack) 1.5.dp else 1.dp,
                                    if (track == mTrack) ForgePurpleLight else MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)
                                )
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(mTrack, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                    if (track == mTrack) {
                                        Text("SELECTED 🎵", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = ForgeCyanLight)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Social Export Presets Selection
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Social Export Presets:", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        AspectRatioPreset.values().forEach { preset ->
                            FilterChip(
                                selected = false,
                                onClick = { viewModel.showToast("Export preset configured: ${preset.label} (${preset.badge})") },
                                label = { Text("${preset.label} (${preset.badge})", fontSize = 11.sp) }
                            )
                        }
                    }
                }
            }
        }

        // Export and Download Video Button & Social Share
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = { viewModel.downloadVideoReel() },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("btn_export_video_reel"),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = ForgePinkPunch)
                ) {
                    Icon(Icons.Default.Download, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Export & Download Video Reel (${duration}s)", fontSize = 15.sp, fontWeight = FontWeight.Bold)
                }

                OutlinedButton(
                    onClick = {
                        val sendIntent = Intent().apply {
                            action = Intent.ACTION_SEND
                            putExtra(
                                Intent.EXTRA_TEXT,
                                "Check out my new video reel made with MemeForge AI! Track: $track (${duration}s) #MemeForge #ViralReels"
                            )
                            type = "text/plain"
                        }
                        val shareIntent = Intent.createChooser(sendIntent, "Share Reel to Socials")
                        context.startActivity(shareIntent)
                    },
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.Share, contentDescription = null, tint = ForgeCyanLight)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Share to Social Apps", fontWeight = FontWeight.Bold, color = ForgeCyanLight)
                }
            }
        }
    }
}
