package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CallSplit
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AspectRatioPreset
import com.example.data.model.AudioCategory
import com.example.data.model.AudioLibraryRepository
import com.example.data.model.TimelineClip
import com.example.data.model.TimelineTrackType
import com.example.ui.components.MemeCanvasView
import com.example.ui.theme.ForgeAmberAccent
import com.example.ui.theme.ForgeCyanLight
import com.example.ui.theme.ForgePinkPunch
import com.example.ui.theme.ForgePurpleLight
import com.example.ui.theme.ForgePurplePrimary
import com.example.ui.viewmodel.MemeForgeViewModel

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun VideoEditorScreen(
    viewModel: MemeForgeViewModel,
    modifier: Modifier = Modifier
) {
    val bitmap by viewModel.editorBitmap.collectAsState()
    val topText by viewModel.editorTopText.collectAsState()
    val bottomText by viewModel.editorBottomText.collectAsState()
    val voiceText by viewModel.voiceText.collectAsState()

    var timelinePosition by remember { mutableStateOf(3.0f) }
    var isPlaying by remember { mutableStateOf(false) }

    // Multi-track clips list
    val timelineClips = remember {
        mutableStateListOf(
            TimelineClip("c_vid", TimelineTrackType.VIDEO, "Main Reel Video", 0f, 10f),
            TimelineClip("c_img", TimelineTrackType.IMAGES, "Meme Base Photo", 0f, 10f),
            TimelineClip("c_txt", TimelineTrackType.TEXT, "Header: $topText", 0f, 10f),
            TimelineClip("c_voc", TimelineTrackType.VOICE, "AI Voice Narration", 0.5f, 7.5f),
            TimelineClip("c_mus", TimelineTrackType.MUSIC, "BGM: Viral Phonk Beat", 0f, 10f, volume = 0.4f),
            TimelineClip("c_sfx", TimelineTrackType.SFX, "Vine Boom Drop", 4.2f, 1.5f),
            TimelineClip("c_sub", TimelineTrackType.SUBTITLES, "Auto-Captions Subtitles", 0.5f, 8.0f)
        )
    }

    var selectedClipId by remember { mutableStateOf<String?>("c_vid") }
    val selectedClip = timelineClips.firstOrNull { it.id == selectedClipId }

    // Audio mixing and control state
    var selectedAudioCategory by remember { mutableStateOf(AudioCategory.FUNNY) }
    var voiceMusicBalance by remember { mutableStateOf(0.7f) } // 70% Voice / 30% Music
    var fadeInOutEnabled by remember { mutableStateOf(true) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 48.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Toolbar
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { viewModel.navigateTo("dashboard") }) {
                        Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, contentDescription = "Back", modifier = Modifier.size(28.dp))
                    }
                    Text(
                        text = "Advanced Video Studio",
                        fontSize = 19.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { viewModel.showToast("Timeline undo") }) {
                        Icon(Icons.AutoMirrored.Filled.Undo, contentDescription = "Undo")
                    }
                    IconButton(onClick = { viewModel.showToast("Timeline redo") }) {
                        Icon(Icons.AutoMirrored.Filled.Redo, contentDescription = "Redo")
                    }
                    IconButton(onClick = { viewModel.saveVideoProject() }) {
                        Icon(Icons.Default.Save, contentDescription = "Save", tint = ForgePurpleLight)
                    }
                }
            }
        }

        // Real-Time Preview Player Canvas
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    MemeCanvasView(
                        bitmap = bitmap,
                        topText = topText,
                        bottomText = bottomText,
                        aspectPreset = AspectRatioPreset.TIKTOK_REELS_SHORTS,
                        isMotionActive = isPlaying,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(290.dp)
                    )

                    // Scrubber Controls
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        IconButton(
                            onClick = { isPlaying = !isPlaying },
                            modifier = Modifier
                                .size(42.dp)
                                .clip(CircleShape)
                                .background(ForgePurplePrimary)
                        ) {
                            Icon(
                                imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = if (isPlaying) "Pause" else "Play",
                                tint = Color.White
                            )
                        }

                        Slider(
                            value = timelinePosition,
                            onValueChange = { timelinePosition = it },
                            valueRange = 0f..10f,
                            modifier = Modifier.weight(1f)
                        )

                        Text(
                            text = "${String.format("%.1f", timelinePosition)}s / 10s",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // 7-TRACK MULTI-TIMELINE VIEW
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Layers, contentDescription = null, tint = ForgePurpleLight)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("7-Track Timeline", fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        }

                        Text("Tap clip to select & edit", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }

                    // Display all 7 timeline tracks
                    TimelineTrackType.values().forEach { trackType ->
                        val clip = timelineClips.firstOrNull { it.trackType == trackType }
                        val isSelected = clip?.id == selectedClipId
                        val trackColor = Color(android.graphics.Color.parseColor(trackType.badgeColorHex))

                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { clip?.let { selectedClipId = it.id } },
                            shape = RoundedCornerShape(8.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (isSelected) trackColor.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surface
                            ),
                            border = androidx.compose.foundation.BorderStroke(
                                if (isSelected) 1.5.dp else 1.dp,
                                if (isSelected) trackColor else MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)
                            )
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                    Surface(
                                        shape = RoundedCornerShape(4.dp),
                                        color = trackColor.copy(alpha = 0.25f)
                                    ) {
                                        Text(
                                            text = trackType.label.uppercase(),
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Black,
                                            color = trackColor,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = clip?.label ?: "Empty Track",
                                        fontSize = 12.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        maxLines = 1
                                    )
                                }

                                Text(
                                    text = clip?.let { "${String.format("%.1f", it.startSec)}s - ${String.format("%.1f", it.startSec + it.durationSec)}s" } ?: "",
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }

        // SELECTED CLIP EDITING CONTROLS (Trim, Split, Delete, Duplicate, Speed, Volume)
        selectedClip?.let { clip ->
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    border = androidx.compose.foundation.BorderStroke(1.dp, ForgeCyanLight.copy(alpha = 0.4f))
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Edit Clip: ${clip.label}", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = ForgeCyanLight)
                            Text("Track: ${clip.trackType.label}", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                        }

                        // Action Buttons Bar (Split, Duplicate, Delete)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedButton(
                                onClick = {
                                    val idx = timelineClips.indexOfFirst { it.id == clip.id }
                                    if (idx != -1) {
                                        val firstHalf = clip.copy(durationSec = clip.durationSec / 2f)
                                        val secondHalf = clip.copy(
                                            id = "c_${System.currentTimeMillis()}",
                                            startSec = clip.startSec + (clip.durationSec / 2f),
                                            durationSec = clip.durationSec / 2f,
                                            label = "${clip.label} (Part 2)"
                                        )
                                        timelineClips[idx] = firstHalf
                                        timelineClips.add(secondHalf)
                                        viewModel.showToast("Split clip into 2 segments")
                                    }
                                },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.CallSplit, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Split", fontSize = 11.sp)
                            }

                            OutlinedButton(
                                onClick = {
                                    val duplicate = clip.copy(
                                        id = "c_${System.currentTimeMillis()}",
                                        startSec = (clip.startSec + clip.durationSec).coerceAtMost(10f),
                                        label = "${clip.label} (Copy)"
                                    )
                                    timelineClips.add(duplicate)
                                    viewModel.showToast("Duplicated clip")
                                },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Duplicate", fontSize = 11.sp)
                            }

                            OutlinedButton(
                                onClick = {
                                    timelineClips.removeIf { it.id == clip.id }
                                    selectedClipId = timelineClips.firstOrNull()?.id
                                    viewModel.showToast("Deleted clip")
                                },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.Delete, contentDescription = null, tint = Color.Red, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Delete", color = Color.Red, fontSize = 11.sp)
                            }
                        }

                        // Trim Slider (Duration)
                        Column {
                            Text("Trim Duration: ${String.format("%.1f", clip.durationSec)}s", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            Slider(
                                value = clip.durationSec,
                                onValueChange = { newDur ->
                                    val idx = timelineClips.indexOfFirst { it.id == clip.id }
                                    if (idx != -1) timelineClips[idx] = clip.copy(durationSec = newDur)
                                },
                                valueRange = 1f..10f
                            )
                        }

                        // Clip Speed (0.5x, 1x, 1.5x, 2x)
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("Speed:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            listOf(0.5f, 1.0f, 1.5f, 2.0f).forEach { spd ->
                                FilterChip(
                                    selected = clip.speed == spd,
                                    onClick = {
                                        val idx = timelineClips.indexOfFirst { it.id == clip.id }
                                        if (idx != -1) timelineClips[idx] = clip.copy(speed = spd)
                                        viewModel.showToast("Playback speed: ${spd}x")
                                    },
                                    label = { Text("${spd}x", fontSize = 11.sp) }
                                )
                            }
                        }

                        // Clip Volume Slider
                        Column {
                            Text("Track Volume: ${(clip.volume * 100).toInt()}%", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            Slider(
                                value = clip.volume,
                                onValueChange = { newVol ->
                                    val idx = timelineClips.indexOfFirst { it.id == clip.id }
                                    if (idx != -1) timelineClips[idx] = clip.copy(volume = newVol)
                                },
                                valueRange = 0f..1f
                            )
                        }
                    }
                }
            }
        }

        // AUDIO LIBRARY SYSTEM (Categories, Tracks, Mixing & Fade)
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.GraphicEq, contentDescription = null, tint = ForgeAmberAccent)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Licensed Audio Library", fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    }

                    // Audio Categories Chips
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(AudioCategory.values()) { cat ->
                            FilterChip(
                                selected = selectedAudioCategory == cat,
                                onClick = { selectedAudioCategory = cat },
                                label = { Text(cat.label, fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = ForgeAmberAccent,
                                    selectedLabelColor = Color.Black
                                )
                            )
                        }
                    }

                    // Filtered Tracks
                    val catTracks = AudioLibraryRepository.tracks.filter { it.category == selectedAudioCategory }
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        catTracks.forEach { trackItem ->
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        viewModel.setVideoTrack(trackItem.name)
                                        viewModel.showToast("Loaded track: ${trackItem.name}")
                                    },
                                shape = RoundedCornerShape(8.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(trackItem.name, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        Text(
                                            text = if (trackItem.isSfx) "Sound Effect • ${trackItem.durationSec}s" else "BGM Track • ${trackItem.durationSec}s",
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }

                                    Button(
                                        onClick = {
                                            viewModel.setVideoTrack(trackItem.name)
                                            viewModel.showToast("Added ${trackItem.name} to timeline")
                                        },
                                        shape = RoundedCornerShape(8.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = ForgePurplePrimary.copy(alpha = 0.3f))
                                    ) {
                                        Icon(Icons.Default.Add, contentDescription = null, tint = ForgePurpleLight, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Add", color = ForgePurpleLight, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }

                    // Audio Mixing Controls (Voice vs Music Balance & Fade In/Out)
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("Voice / Music Mixing Balance:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("Voice ${(voiceMusicBalance * 100).toInt()}%", fontSize = 11.sp, modifier = Modifier.width(60.dp))
                                Slider(
                                    value = voiceMusicBalance,
                                    onValueChange = { voiceMusicBalance = it },
                                    valueRange = 0f..1f,
                                    modifier = Modifier.weight(1f)
                                )
                                Text("Music ${((1f - voiceMusicBalance) * 100).toInt()}%", fontSize = 11.sp, modifier = Modifier.width(60.dp))
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Automatic Audio Fade In / Out", fontSize = 12.sp)
                                Switch(checked = fadeInOutEnabled, onCheckedChange = { fadeInOutEnabled = it })
                            }
                        }
                    }
                }
            }
        }

        // Export Video Project Button
        item {
            Button(
                onClick = { viewModel.saveVideoProject() },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("btn_save_timeline_video"),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = ForgePurplePrimary)
            ) {
                Icon(Icons.Default.Save, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Export & Render Video Timeline", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}
