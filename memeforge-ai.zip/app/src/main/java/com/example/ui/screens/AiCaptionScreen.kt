package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.ForgeAmberAccent
import com.example.ui.theme.ForgeCyanLight
import com.example.ui.theme.ForgePurpleLight
import com.example.ui.theme.ForgePurplePrimary
import com.example.ui.viewmodel.MemeForgeViewModel

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AiCaptionScreen(
    viewModel: MemeForgeViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val topic by viewModel.captionTopic.collectAsState()
    val style by viewModel.captionStyle.collectAsState()
    val lang by viewModel.captionLanguage.collectAsState()
    val captions by viewModel.generatedCaptions.collectAsState()
    val isLoading by viewModel.isCaptionLoading.collectAsState()
    val captionBitmap by viewModel.captionBitmap.collectAsState()
    val captionModifier by viewModel.captionModifier.collectAsState()
    val customInstruction by viewModel.customCaptionInstruction.collectAsState()

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        uri?.let { viewModel.loadCaptionImageUri(it, context) }
    }

    val styles = listOf(
        "Funny",
        "Desi Pakistani",
        "Savage",
        "Cute",
        "Friendship",
        "Love",
        "School",
        "Family",
        "Sarcastic",
        "Custom"
    )

    val languages = listOf("Roman Urdu", "Urdu", "Hinglish", "English")
    val modifiers = listOf("Standard", "Shorter", "Funnier", "More Desi", "Custom")

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 48.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Toolbar
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { viewModel.navigateTo("dashboard") }) {
                    Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, contentDescription = "Back", modifier = Modifier.size(28.dp))
                }
                Text(
                    text = "AI Caption Generator",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
            }
        }

        // Generator Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                border = androidx.compose.foundation.BorderStroke(1.dp, ForgePurpleLight.copy(alpha = 0.3f))
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text(
                        text = "Multimodal Image & Context Captioning",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    // Image attachment row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        captionBitmap?.let { bmp ->
                            Image(
                                bitmap = bmp.asImageBitmap(),
                                contentDescription = "Attached photo",
                                modifier = Modifier
                                    .size(64.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .border(1.dp, ForgePurpleLight, RoundedCornerShape(10.dp))
                            )
                        }

                        Button(
                            onClick = {
                                photoPickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            },
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = ForgePurplePrimary.copy(alpha = 0.2f))
                        ) {
                            Icon(Icons.Default.AddPhotoAlternate, contentDescription = null, tint = ForgePurpleLight)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (captionBitmap != null) "Change Photo" else "Attach Photo to Analyze",
                                color = ForgePurpleLight,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    OutlinedTextField(
                        value = topic,
                        onValueChange = { viewModel.setCaptionTopic(it) },
                        label = { Text("What is this photo/scene about?") },
                        placeholder = { Text("e.g. Trying to explain tech to parents, exam stress...") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_caption_topic"),
                        shape = RoundedCornerShape(12.dp)
                    )

                    // Styles Chips
                    Text("Caption Style / Tone:", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        styles.forEach { s ->
                            FilterChip(
                                selected = style == s,
                                onClick = { viewModel.setCaptionStyle(s) },
                                label = { Text(s) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = ForgePurplePrimary,
                                    selectedLabelColor = Color.White
                                )
                            )
                        }
                    }

                    // Language Selection
                    Text("Language:", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        languages.forEach { l ->
                            FilterChip(
                                selected = lang == l,
                                onClick = { viewModel.setCaptionLanguage(l) },
                                label = { Text(l, fontSize = 12.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = ForgeCyanLight,
                                    selectedLabelColor = Color.Black
                                )
                            )
                        }
                    }

                    // Prompt Modifiers (Shorter, Funnier, More Desi, Custom)
                    Text("Caption Modifier / Tone Tuning:", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(modifiers) { m ->
                            FilterChip(
                                selected = captionModifier == m,
                                onClick = { viewModel.setCaptionModifier(m) },
                                label = { Text(m) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = ForgeAmberAccent,
                                    selectedLabelColor = Color.Black
                                )
                            )
                        }
                    }

                    // Custom Instruction input
                    AnimatedVisibility(visible = captionModifier == "Custom") {
                        OutlinedTextField(
                            value = customInstruction,
                            onValueChange = { viewModel.setCustomCaptionInstruction(it) },
                            label = { Text("Custom Prompt Instruction") },
                            placeholder = { Text("e.g. Write in gen-z slang with lots of fire emojis") },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp)
                        )
                    }

                    // Action Buttons (Generate, Shorter, Funnier, More Desi)
                    Button(
                        onClick = { viewModel.generateCaptions() },
                        enabled = !isLoading,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("btn_generate_captions"),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = ForgePurplePrimary)
                    ) {
                        if (isLoading) {
                            CircularProgressIndicator(color = Color.White, modifier = Modifier.size(24.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Analyzing & Forging Captions...", fontWeight = FontWeight.Bold)
                        } else {
                            Icon(Icons.Default.AutoAwesome, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("⚡ Generate Viral Captions", fontWeight = FontWeight.Bold)
                        }
                    }

                    // Quick Modifier Refine Bar
                    if (captions.isNotEmpty()) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedButton(
                                onClick = {
                                    viewModel.setCaptionModifier("Shorter")
                                    viewModel.generateCaptions()
                                },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text("Shorter", fontSize = 12.sp)
                            }
                            OutlinedButton(
                                onClick = {
                                    viewModel.setCaptionModifier("Funnier")
                                    viewModel.generateCaptions()
                                },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text("Funnier", fontSize = 12.sp)
                            }
                            OutlinedButton(
                                onClick = {
                                    viewModel.setCaptionModifier("More Desi")
                                    viewModel.generateCaptions()
                                },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text("More Desi", fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }

        // AI CONTENT ASSISTANT SECTION
        item {
            val assistantInput by viewModel.assistantInputText.collectAsState()
            val assistantOutput by viewModel.assistantOutputResult.collectAsState()
            val isAssistantLoading by viewModel.isAssistantLoading.collectAsState()
            val selectedAssistantAction by viewModel.selectedAssistantAction.collectAsState()

            val assistantActions = listOf(
                "Make it Funnier",
                "Make it More Desi",
                "Make it Shorter",
                "Make it More Viral-style",
                "Generate Hook",
                "Generate Caption",
                "Generate Description",
                "Generate Hashtags",
                "Generate Title"
            )

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("card_ai_content_assistant"),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                border = androidx.compose.foundation.BorderStroke(1.dp, ForgeAmberAccent.copy(alpha = 0.4f))
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = ForgeAmberAccent)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "AI Content Assistant",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = ForgeAmberAccent.copy(alpha = 0.2f)
                        ) {
                            Text(
                                text = "CREATOR TOOLS",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = ForgeAmberAccent,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Text(
                        text = "Refine existing text or generate specialized social media copy (Hooks, Titles, Hashtags, Desi comedy).",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    OutlinedTextField(
                        value = assistantInput,
                        onValueChange = { viewModel.setAssistantInputText(it) },
                        label = { Text("Base text or topic to transform") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_assistant_text"),
                        shape = RoundedCornerShape(12.dp)
                    )

                    // 9 Action Buttons
                    Text("Select Assistant Transformation:", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        assistantActions.forEach { action ->
                            val isSelected = selectedAssistantAction == action
                            FilterChip(
                                selected = isSelected,
                                onClick = { viewModel.executeAssistantAction(action) },
                                label = { Text(action, fontSize = 12.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = ForgeAmberAccent,
                                    selectedLabelColor = Color.Black
                                )
                            )
                        }
                    }

                    Text(
                        text = "⚠️ Virality Disclaimer: Content suggestions are optimized for social engagement; audience reactions and reach naturally vary.",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.75f)
                    )

                    if (isAssistantLoading) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            CircularProgressIndicator(color = ForgeAmberAccent, modifier = Modifier.size(24.dp))
                            Spacer(modifier = Modifier.width(10.dp))
                            Text("AI Assistant transforming text...", fontSize = 13.sp)
                        }
                    }

                    if (assistantOutput.isNotBlank()) {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = androidx.compose.foundation.BorderStroke(1.dp, ForgeAmberAccent.copy(alpha = 0.5f))
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Text(
                                    text = "Output: $selectedAssistantAction",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = ForgeAmberAccent
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = assistantOutput,
                                    fontSize = 14.sp,
                                    lineHeight = 20.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Spacer(modifier = Modifier.height(10.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.End,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    IconButton(
                                        onClick = {
                                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                            val clip = ClipData.newPlainText("Assistant Output", assistantOutput)
                                            clipboard.setPrimaryClip(clip)
                                            viewModel.showToast("Copied to clipboard!")
                                        }
                                    ) {
                                        Icon(Icons.Default.ContentCopy, contentDescription = "Copy", modifier = Modifier.size(20.dp))
                                    }

                                    IconButton(
                                        onClick = {
                                            viewModel.setEditorBottomText(assistantOutput)
                                            viewModel.navigateTo("photo_editor")
                                            viewModel.showToast("Loaded into Photo Editor!")
                                        }
                                    ) {
                                        Icon(Icons.Default.Tune, contentDescription = "Send to Editor", modifier = Modifier.size(20.dp))
                                    }

                                    IconButton(
                                        onClick = { viewModel.saveCaptionToCreations(assistantOutput) }
                                    ) {
                                        Icon(Icons.Default.Save, contentDescription = "Save", modifier = Modifier.size(20.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Generated Captions List
        if (captions.isNotEmpty()) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Generated Captions ($style • $lang)",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                    IconButton(onClick = { viewModel.generateCaptions() }) {
                        Icon(Icons.Default.Refresh, contentDescription = "Regenerate")
                    }
                }
            }

            items(captions) { caption ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = caption,
                            fontSize = 14.sp,
                            lineHeight = 20.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(
                                onClick = {
                                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                    val clip = ClipData.newPlainText("Caption", caption)
                                    clipboard.setPrimaryClip(clip)
                                    viewModel.showToast("Copied to clipboard!")
                                }
                            ) {
                                Icon(Icons.Default.ContentCopy, contentDescription = "Copy", modifier = Modifier.size(20.dp))
                            }

                            IconButton(
                                onClick = {
                                    viewModel.setEditorTopText("POV:")
                                    viewModel.setEditorBottomText(caption)
                                    viewModel.navigateTo("photo_editor")
                                    viewModel.showToast("Loaded into Photo Editor!")
                                }
                            ) {
                                Icon(Icons.Default.Tune, contentDescription = "Send to Editor", modifier = Modifier.size(20.dp))
                            }

                            IconButton(
                                onClick = { viewModel.saveCaptionToCreations(caption) }
                            ) {
                                Icon(Icons.Default.Save, contentDescription = "Save", modifier = Modifier.size(20.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}
