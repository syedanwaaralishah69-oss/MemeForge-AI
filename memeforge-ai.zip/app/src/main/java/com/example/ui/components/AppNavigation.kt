package com.example.ui.components

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Collections
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.FormatQuote
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.screens.AiCaptionScreen
import com.example.ui.screens.AiStoryScreen
import com.example.ui.screens.AiVoiceScreen
import com.example.ui.screens.AutoCreateScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.MemeTemplatesScreen
import com.example.ui.screens.MyCreationsScreen
import com.example.ui.screens.PhotoEditorScreen
import com.example.ui.screens.PhotoToVideoScreen
import com.example.ui.screens.VideoEditorScreen
import com.example.ui.theme.ForgeAmberAccent
import com.example.ui.theme.ForgeCyanLight
import com.example.ui.theme.ForgePinkPunch
import com.example.ui.theme.ForgePurpleLight
import com.example.ui.theme.ForgePurplePrimary
import com.example.ui.viewmodel.MemeForgeViewModel

data class CreatorToolItem(
    val title: String,
    val subtitle: String,
    val icon: ImageVector,
    val route: String,
    val color: Color
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppNavigation(
    viewModel: MemeForgeViewModel,
    modifier: Modifier = Modifier
) {
    val currentRoute by viewModel.currentRoute.collectAsState()
    val isDark by viewModel.isDarkTheme.collectAsState()
    var showToolsSheet by remember { mutableStateOf(false) }

    val allCreatorTools = remember {
        listOf(
            CreatorToolItem("HOME", "Creator Dashboard", Icons.Default.Home, "dashboard", ForgePurpleLight),
            CreatorToolItem("AI MEME", "Auto Meme Generator", Icons.Default.AutoAwesome, "auto_create", ForgePurplePrimary),
            CreatorToolItem("AI CAPTION", "Hooks & Hashtags", Icons.Default.FormatQuote, "ai_caption", ForgeCyanLight),
            CreatorToolItem("PHOTO TO VIDEO", "Reels & Slideshows", Icons.Default.Movie, "photo_to_video", ForgePinkPunch),
            CreatorToolItem("AI VOICE", "Voiceover & Subtitles", Icons.Default.RecordVoiceOver, "ai_voice", ForgeAmberAccent),
            CreatorToolItem("VIDEO EDITOR", "Multi-Track Timeline", Icons.Default.VideoLibrary, "video_editor", Color(0xFF6366F1)),
            CreatorToolItem("TEMPLATES", "Vault of Meme Formats", Icons.Default.PhotoLibrary, "meme_templates", Color(0xFF10B981)),
            CreatorToolItem("MY CREATIONS", "Saved Library & Drafts", Icons.Default.Collections, "my_creations", Color(0xFFEC4899))
        )
    }

    // Handle back button on sub-screens
    BackHandler(enabled = currentRoute != "dashboard") {
        viewModel.navigateTo("dashboard")
    }

    BoxWithConstraints(modifier = modifier.fillMaxSize()) {
        val isExpanded = maxWidth >= 600.dp

        if (isExpanded) {
            // Desktop / Tablet Sidebar Navigation Rail
            Row(modifier = Modifier.fillMaxSize()) {
                NavigationRail(
                    containerColor = MaterialTheme.colorScheme.surface,
                    contentColor = MaterialTheme.colorScheme.onSurface,
                    header = {
                        IconButton(onClick = { viewModel.toggleDarkTheme() }) {
                            Icon(
                                imageVector = if (isDark) Icons.Default.LightMode else Icons.Default.DarkMode,
                                contentDescription = "Toggle Theme",
                                tint = ForgePurpleLight
                            )
                        }
                    }
                ) {
                    NavigationRailItem(
                        selected = currentRoute == "dashboard",
                        onClick = { viewModel.navigateTo("dashboard") },
                        icon = { Icon(Icons.Default.Home, contentDescription = "HOME") },
                        label = { Text("HOME", fontSize = 10.sp, fontWeight = FontWeight.Bold) }
                    )
                    NavigationRailItem(
                        selected = currentRoute == "auto_create",
                        onClick = {
                            viewModel.setAutoCreateStep(1)
                            viewModel.navigateTo("auto_create")
                        },
                        icon = { Icon(Icons.Default.AutoAwesome, contentDescription = "AI MEME") },
                        label = { Text("AI MEME", fontSize = 10.sp, fontWeight = FontWeight.Bold) }
                    )
                    NavigationRailItem(
                        selected = currentRoute == "ai_caption",
                        onClick = { viewModel.navigateTo("ai_caption") },
                        icon = { Icon(Icons.Default.FormatQuote, contentDescription = "AI CAPTION") },
                        label = { Text("CAPTION", fontSize = 10.sp, fontWeight = FontWeight.Bold) }
                    )
                    NavigationRailItem(
                        selected = currentRoute == "photo_to_video",
                        onClick = { viewModel.navigateTo("photo_to_video") },
                        icon = { Icon(Icons.Default.Movie, contentDescription = "PHOTO TO VIDEO") },
                        label = { Text("VIDEO", fontSize = 10.sp, fontWeight = FontWeight.Bold) }
                    )
                    NavigationRailItem(
                        selected = currentRoute == "ai_voice",
                        onClick = { viewModel.navigateTo("ai_voice") },
                        icon = { Icon(Icons.Default.RecordVoiceOver, contentDescription = "AI VOICE") },
                        label = { Text("VOICE", fontSize = 10.sp, fontWeight = FontWeight.Bold) }
                    )
                    NavigationRailItem(
                        selected = currentRoute == "video_editor",
                        onClick = { viewModel.navigateTo("video_editor") },
                        icon = { Icon(Icons.Default.VideoLibrary, contentDescription = "VIDEO EDITOR") },
                        label = { Text("EDITOR", fontSize = 10.sp, fontWeight = FontWeight.Bold) }
                    )
                    NavigationRailItem(
                        selected = currentRoute == "meme_templates",
                        onClick = { viewModel.navigateTo("meme_templates") },
                        icon = { Icon(Icons.Default.PhotoLibrary, contentDescription = "TEMPLATES") },
                        label = { Text("TEMPLATES", fontSize = 10.sp, fontWeight = FontWeight.Bold) }
                    )
                    NavigationRailItem(
                        selected = currentRoute == "my_creations",
                        onClick = { viewModel.navigateTo("my_creations") },
                        icon = { Icon(Icons.Default.Collections, contentDescription = "MY CREATIONS") },
                        label = { Text("CREATIONS", fontSize = 10.sp, fontWeight = FontWeight.Bold) }
                    )
                }

                Box(modifier = Modifier.weight(1f).fillMaxSize()) {
                    ScreenContent(currentRoute = currentRoute, viewModel = viewModel)
                }
            }
        } else {
            // Mobile Layout with TopAppBar & Bottom NavigationBar
            Scaffold(
                topBar = {
                    TopAppBar(
                        title = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "MemeForge",
                                    fontWeight = FontWeight.Black,
                                    fontSize = 20.sp,
                                    color = MaterialTheme.colorScheme.onBackground
                                )
                                Text(
                                    text = " AI",
                                    fontWeight = FontWeight.Black,
                                    fontSize = 20.sp,
                                    color = ForgePurpleLight
                                )
                            }
                        },
                        actions = {
                            IconButton(
                                onClick = { showToolsSheet = true },
                                modifier = Modifier.testTag("btn_all_tools")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Apps,
                                    contentDescription = "All Creator Tools",
                                    tint = ForgeCyanLight
                                )
                            }
                            IconButton(
                                onClick = { viewModel.toggleDarkTheme() },
                                modifier = Modifier.testTag("btn_theme_toggle")
                            ) {
                                Icon(
                                    imageVector = if (isDark) Icons.Default.LightMode else Icons.Default.DarkMode,
                                    contentDescription = "Toggle Dark/Light Mode",
                                    tint = ForgePurpleLight
                                )
                            }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = MaterialTheme.colorScheme.background
                        )
                    )
                },
                bottomBar = {
                    NavigationBar(
                        containerColor = MaterialTheme.colorScheme.surface,
                        modifier = Modifier.testTag("bottom_nav_bar")
                    ) {
                        NavigationBarItem(
                            selected = currentRoute == "dashboard",
                            onClick = { viewModel.navigateTo("dashboard") },
                            icon = { Icon(Icons.Default.Home, contentDescription = "HOME") },
                            label = { Text("HOME", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = ForgePurpleLight,
                                selectedTextColor = ForgePurpleLight,
                                indicatorColor = ForgePurplePrimary.copy(alpha = 0.2f)
                            )
                        )
                        NavigationBarItem(
                            selected = currentRoute == "auto_create",
                            onClick = {
                                viewModel.setAutoCreateStep(1)
                                viewModel.navigateTo("auto_create")
                            },
                            icon = { Icon(Icons.Default.AutoAwesome, contentDescription = "AI MEME") },
                            label = { Text("AI MEME", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = ForgePurpleLight,
                                selectedTextColor = ForgePurpleLight,
                                indicatorColor = ForgePurplePrimary.copy(alpha = 0.2f)
                            )
                        )
                        NavigationBarItem(
                            selected = currentRoute == "ai_caption",
                            onClick = { viewModel.navigateTo("ai_caption") },
                            icon = { Icon(Icons.Default.FormatQuote, contentDescription = "AI CAPTION") },
                            label = { Text("CAPTION", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = ForgePurpleLight,
                                selectedTextColor = ForgePurpleLight,
                                indicatorColor = ForgePurplePrimary.copy(alpha = 0.2f)
                            )
                        )
                        NavigationBarItem(
                            selected = currentRoute == "video_editor",
                            onClick = { viewModel.navigateTo("video_editor") },
                            icon = { Icon(Icons.Default.VideoLibrary, contentDescription = "VIDEO EDITOR") },
                            label = { Text("STUDIO", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = ForgePurpleLight,
                                selectedTextColor = ForgePurpleLight,
                                indicatorColor = ForgePurplePrimary.copy(alpha = 0.2f)
                            )
                        )
                        NavigationBarItem(
                            selected = currentRoute == "my_creations",
                            onClick = { viewModel.navigateTo("my_creations") },
                            icon = { Icon(Icons.Default.Collections, contentDescription = "MY CREATIONS") },
                            label = { Text("CREATIONS", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = ForgePurpleLight,
                                selectedTextColor = ForgePurpleLight,
                                indicatorColor = ForgePurplePrimary.copy(alpha = 0.2f)
                            )
                        )
                    }
                }
            ) { innerPadding ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    ScreenContent(currentRoute = currentRoute, viewModel = viewModel)
                }
            }
        }
    }

    // Modal Tools Sheet displaying all 8 Creator Tools
    if (showToolsSheet) {
        ModalBottomSheet(
            onDismissRequest = { showToolsSheet = false },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "MemeForge AI Studio Navigation",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = ForgePurplePrimary.copy(alpha = 0.2f)
                    ) {
                        Text(
                            text = "8 SUITES",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = ForgePurpleLight,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                        )
                    }
                }

                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    contentPadding = PaddingValues(bottom = 32.dp)
                ) {
                    items(allCreatorTools) { tool ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    if (tool.route == "auto_create") {
                                        viewModel.setAutoCreateStep(1)
                                    }
                                    viewModel.navigateTo(tool.route)
                                    showToolsSheet = false
                                },
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (currentRoute == tool.route) tool.color.copy(alpha = 0.25f) else MaterialTheme.colorScheme.surfaceVariant
                            ),
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (currentRoute == tool.route) tool.color else MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)
                            )
                        ) {
                            Column(
                                modifier = Modifier.padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    imageVector = tool.icon,
                                    contentDescription = tool.title,
                                    tint = tool.color,
                                    modifier = Modifier.size(28.dp)
                                )
                                Text(
                                    text = tool.title,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = tool.subtitle,
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ScreenContent(
    currentRoute: String,
    viewModel: MemeForgeViewModel
) {
    AnimatedContent(
        targetState = currentRoute,
        transitionSpec = { fadeIn() togetherWith fadeOut() },
        label = "screen_transition"
    ) { route ->
        when (route) {
            "dashboard" -> DashboardScreen(viewModel = viewModel)
            "auto_create" -> AutoCreateScreen(viewModel = viewModel)
            "ai_story" -> AiStoryScreen(viewModel = viewModel)
            "photo_editor" -> PhotoEditorScreen(viewModel = viewModel)
            "ai_caption" -> AiCaptionScreen(viewModel = viewModel)
            "photo_to_video" -> PhotoToVideoScreen(viewModel = viewModel)
            "ai_voice" -> AiVoiceScreen(viewModel = viewModel)
            "meme_templates" -> MemeTemplatesScreen(viewModel = viewModel)
            "video_editor" -> VideoEditorScreen(viewModel = viewModel)
            "my_creations" -> MyCreationsScreen(viewModel = viewModel)
            else -> DashboardScreen(viewModel = viewModel)
        }
    }
}
